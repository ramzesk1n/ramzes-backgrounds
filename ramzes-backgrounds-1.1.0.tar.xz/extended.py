"""Distinct additional materials and visual metaphors; deterministic code, no runtime filters."""
import math, random

RASTER_IDS=['travertine-surface','oak-veneer-photo','satin-folds-photo','velvet-photo','ceramic-glaze-photo','brushed-aluminum-photo']

def vectors(svg,speckles):
    rng=random.Random(20261014)
    def path(d,stroke='black',width=1,opacity=1,fill='none'):
        return f'<path d="{d}" stroke="{stroke}" stroke-width="{width}" opacity="{opacity}" fill="{fill}"/>'
    def periodic(name,body,w=256,h=256):svg(name,body,w,h)
    # Small mineral chips with wrapped edges, distinct from the microcement dots.
    chips=[]
    for _ in range(65):
        x,y=rng.uniform(0,256),rng.uniform(0,256);r=rng.uniform(2,7)
        pts=[(x+r*math.cos(t),y+r*.65*math.sin(t)) for t in [0,1.1,2.3,3.5,4.8]]
        alpha=rng.uniform(.15,.65)
        for dx in (-256,0,256):
            for dy in (-256,0,256):
                if -r<x+dx<256+r and -r<y+dy<256+r:
                    chips.append(f'<polygon points="'+ ' '.join(f'{a+dx:.1f},{b+dy:.1f}' for a,b in pts)+f'" opacity="{alpha:.2f}"/>')
    periodic('terrazzo-chips',''.join(chips))
    fibers=[]
    for _ in range(140):
        x,y=rng.uniform(0,256),rng.uniform(0,256);dx,dy=rng.uniform(-5,5),rng.uniform(1,8)
        for ox in (-256,0,256):
            for oy in (-256,0,256):
                if -9<x+ox<265 and -9<y+oy<265:fibers.append(path(f'M{x+ox:.1f} {y+oy:.1f}l{dx:.1f} {dy:.1f}',width=.55,opacity=.23))
    periodic('kraft-fibers',''.join(fibers))
    periodic('terracotta-grain',speckles(781,240,'black',.33,2.5))
    pores=[]
    for j in range(20):
        x=rng.uniform(0,256);y=rng.uniform(0,256)
        for dx in (-256,0,256):
            for dy in (-256,0,256):
                if -10<x+dx<266 and -4<y+dy<260:pores.append(f'<ellipse cx="{x+dx:.1f}" cy="{y+dy:.1f}" rx="6" ry="1.5" opacity=".18"/>')
    periodic('limestone-pores',''.join(pores)+speckles(782,160,'black',.13,.5))
    slate=[]
    for y in range(-20,300,21):
        # Both value and tangent agree at the two horizontal edges.
        slate.append(path(f'M0 {y} C64 {y-8} 192 {y+8} 256 {y}',width=.7,opacity=.35))
    # Composition, not a repeat tile; no false seamless label.
    svg('slate-cleavage',''.join(slate))
    periodic('asphalt-grit',speckles(789,480,'black',.52,1.5))
    leather=[]
    for y in range(0,256,16):
        for x in range(0,256,16):
            leather.append(path(f'M{x+2} {y+7}q4 -7 11 -2q4 7 -3 9q-7 4 -8 -7',width=.7,opacity=.42))
    periodic('leather-grain',''.join(leather))
    weave='<defs><pattern id="rattan" width="32" height="32" patternUnits="userSpaceOnUse">'+path('M0 8H32 M0 24H32',width=12,opacity=.18)+path('M8 0V32 M24 0V32',width=12,opacity=.18)+path('M0 8H16 M16 24H32',width=10,opacity=.55)+'</pattern></defs><path d="M0 0H256V256H0z" fill="url(#rattan)"/>'
    periodic('rattan-weave',weave)
    cardboard='<defs><pattern id="flute" width="24" height="24" patternUnits="userSpaceOnUse"><path d="M4 0V24 M20 0V24" stroke="black" opacity=".15"/><path d="M9 0V24 M15 0V24" stroke="black" stroke-width="3" opacity=".42"/></pattern></defs><path d="M0 0H240V240H0z" fill="url(#flute)"/>'
    periodic('corrugated-cardboard',cardboard,240,240)
    holes='<defs><pattern id="hole" width="24" height="24" patternUnits="userSpaceOnUse"><circle cx="6" cy="6" r="3.5"/><circle cx="18" cy="18" r="3.5"/></pattern></defs><path d="M0 0H240V240H0z" fill="url(#hole)"/>'
    periodic('perforated-metal',holes,240,240)
    plate='<defs><pattern id="plate" width="48" height="48" patternUnits="userSpaceOnUse"><path d="M6 10l12 12M30 34l12 12M30 10l12 -12M6 34l12 -12" stroke="black" stroke-width="3" stroke-linecap="round"/></pattern></defs><path d="M0 0H240V240H0z" fill="url(#plate)"/>'
    periodic('diamond-plate',plate,240,240)
    honey='<defs><pattern id="hex" width="48" height="83.1384" patternUnits="userSpaceOnUse"><path d="M0 13.8564L24 0L48 13.8564V41.5692L24 55.4256L0 41.5692Z M0 41.5692L-24 55.4256V83.1384L0 96.9948L24 83.1384V55.4256L48 41.5692" fill="none" stroke="black" stroke-width="1"/></pattern></defs><path d="M0 0H240V415.692H0z" fill="url(#hex)"/>'
    # A composition avoids claiming a fractional-height export as a perfect tile.
    svg('honeycomb-structure',honey,240,416)
    stitches='<defs><pattern id="stitch" width="64" height="64" patternUnits="userSpaceOnUse"><path d="M0 16H64 M0 48H64" fill="none" stroke="black" opacity=".13"/><path d="M0 16H64 M0 48H64" fill="none" stroke="black" stroke-width="1.5" stroke-dasharray="5 3"/></pattern></defs><path d="M0 0H256V256H0z" fill="url(#stitch)"/>'
    periodic('stitch-lines',stitches)
    sound=[]
    for j in range(32):
        x=80+j*25;height=10+180*math.exp(-((j-16)/8)**2)*(.55+.45*math.sin(j*.8)**2)
        sound.append(path(f'M{x} {320-height:.1f}V{320+height:.1f}',width=2,opacity=.8))
    svg('sound-contours',''.join(sound),960,640)
    # Sparse diagram networks; meaningful structure rather than a random particle cloud.
    def network(name,points,links,radius=4):
        body=[]
        for a,b in links:body.append(path(f'M{points[a][0]} {points[a][1]}L{points[b][0]} {points[b][1]}',opacity=.55))
        for x,y in points:body.append(f'<circle cx="{x}" cy="{y}" r="{radius}" fill="black"/>')
        svg(name,''.join(body),960,640)
    network('knowledge-network',[(120,150),(330,110),(550,220),(810,100),(760,420),(480,510),(190,440),(365,325)],[(0,1),(1,2),(2,3),(3,4),(4,5),(5,6),(6,0),(1,7),(7,2),(7,5),(7,6)],6)
    orbits=[]
    for j in range(5):orbits.append(f'<ellipse cx="480" cy="320" rx="{160+j*45}" ry="{55+j*15}" transform="rotate({j*27} 480 320)" fill="none" stroke="black" opacity=".6"/>')
    orbits.append('<circle cx="480" cy="320" r="9"/>')
    svg('orbital-paths',''.join(orbits),960,640)
    pts=[(140,290),(260,220),(380,290),(380,430),(260,500),(140,430),(500,220),(620,290),(740,220),(850,290)]
    network('molecular-bonds',pts,[(0,1),(1,2),(2,3),(3,4),(4,5),(5,0),(2,6),(6,7),(7,8),(8,9)],9)
    roots=[]
    def branch(x,y,length,angle,depth):
        nx=x+length*math.cos(angle);ny=y+length*math.sin(angle)
        roots.append(path(f'M{x:.1f} {y:.1f}Q{x:.1f} {ny:.1f} {nx:.1f} {ny:.1f}',width=max(.4,depth*.35),opacity=.55))
        if depth:
            branch(nx,ny,length*.67,angle-.48,depth-1);branch(nx,ny,length*.68,angle+.5,depth-1)
    branch(900,40,150,2.15,5)
    svg('root-mycelium',''.join(roots),960,640)
    leaves=[]
    for j in range(7):
        x=700+j*26;y=70+j*64
        leaves.append(path(f'M{x} {y}q-130 -25 -150 65q105 45 150 -65 M{x} {y}q-95 65 -135 60',width=1.3,opacity=.75))
    svg('contour-leaves',''.join(leaves),960,640)
    route=path('M60 560C300 580 150 340 400 360S650 120 900 100',width=1.5,opacity=.8)
    for x,y in [(60,560),(400,360),(900,100)]:route+=f'<circle cx="{x}" cy="{y}" r="8" fill="none" stroke="black"/>'
    svg('river-route',route,960,640)
    city=[]
    for x,y,w,h in [(40,60,180,150),(260,60,260,150),(560,60,340,150),(40,250,280,130),(360,250,220,250),(620,250,280,130),(40,420,280,160),(620,420,280,160)]:
        city.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="none" stroke="black"/>')
        city.append(f'<rect x="{x+15}" y="{y+15}" width="{w-30}" height="{h-30}" fill="none" stroke="black" opacity=".2"/>')
    svg('city-blocks',''.join(city),960,640)
    svg('parcel-lines',path('M0 200L180 120L420 180L700 0 M180 120L260 420L0 500 M260 420L550 540L620 260L420 180 M620 260L960 300 M550 540L750 640 M620 260L830 140L960 200 M830 140L800 0',opacity=.6),960,640)
    utilities=path('M0 120H240V360H600V200H960 M0 520H420V420H800V640',width=2,opacity=.7)
    for x,y in [(240,240),(600,280),(420,470),(800,560)]:utilities+=path(f'M{x-12} {y-12}L{x+12} {y+12}V{y-12}L{x-12} {y+12}Z',width=1.5)
    svg('blueprint-utilities',utilities,960,640)
    helix=[]
    for x in range(80,881,25):
        y=320+100*math.sin((x-80)/100);z=320-100*math.sin((x-80)/100)
        helix.append(path(f'M{x} {y:.1f}V{z:.1f}',opacity=.4))
    for sign in (1,-1):
        points=' '.join(f'{x},{320+sign*100*math.sin((x-80)/100):.1f}' for x in range(80,881,10))
        helix.append(f'<polyline points="{points}" fill="none" stroke="black" stroke-width="1.5"/>')
    svg('helix-ribbon',''.join(helix),960,640)
    ice=path('M0 80L200 200L140 440L380 530L600 300L800 350L960 150 M200 200L470 140L600 300 M470 140L550 0 M140 440L0 570 M600 300L700 80L960 50 M380 530L450 640 M800 350L850 640',width=1.2,opacity=.7)
    svg('ice-fractures',ice,960,640)
    drops=['<defs><radialGradient id="drop"><stop stop-color="black" stop-opacity="0"/><stop offset=".72" stop-color="black" stop-opacity=".04"/><stop offset=".94" stop-color="black" stop-opacity=".65"/><stop offset="1" stop-color="black" stop-opacity="0"/></radialGradient></defs>']
    rng2=random.Random(305)
    for _ in range(38):
        x,y=rng2.uniform(12,244),rng2.uniform(12,244);r=rng2.uniform(2,9)
        drops.append(f'<ellipse cx="{x:.1f}" cy="{y:.1f}" rx="{r:.1f}" ry="{r*1.13:.1f}" fill="url(#drop)"/>')
    periodic('condensation-drops',''.join(drops))
    sparks=[]
    for j in range(70):
        angle=rng.uniform(-2.8,-.5);dist=rng.uniform(20,500);x=800+dist*math.cos(angle);y=580+dist*math.sin(angle)
        sparks.append(path(f'M{x:.1f} {y:.1f}l{-math.cos(angle)*rng.uniform(2,14):.1f} {-math.sin(angle)*rng.uniform(2,14):.1f}',width=rng.uniform(.5,1.5),opacity=rng.uniform(.2,.9)))
    svg('spark-scatter',''.join(sparks),960,640)
    steam=[]
    for j in range(8):
        x=500+j*35
        for width,op in [(24,.015),(12,.025),(4,.04)]:steam.append(path(f'M{x} 640C{x-100} 450 {x+90} 400 {x} 250S{x-20} 90 {x+60} 0',width=width,opacity=op))
    svg('steam-ribbons',''.join(steam),960,640)

def catalog(item):
    result=[]
    def add(id,name,family,tech,placement,description,niches,why,avoid,role='primary',intensity=.22,body=None):
        c=item(id,name,family,tech,placement,(id+'.svg' if tech=='SVG' else id+'.webp' if tech=='WebP' else None),description,niches,why,avoid,[], '#f2ece0','#38534a','#a36945',intensity)
        c['ink_role']=role
        if body:c['css_body']=body
        if id in ('isometric-grid','diagonal-hatch','carbon-weave'):c['defaults']['scale']={'isometric-grid':110,'diagonal-hatch':24,'carbon-weave':20}[id]
        c['visual_kind']='photorealistic' if tech=='WebP' else 'code-stylization'
        result.append(c)
    # Each code texture is explicitly described as a graphic interpretation.
    defs=[
      ('terrazzo-chips','Терраццо: минеральная крошка','Материалы','repeat','Небольшие угловатые включения; периодическая стилизация терраццо.',['Недвижимость и интерьер','Рестораны и продукты','Кухни и мебель'],'Разнообразит спокойную минеральную основу без крупной фотографии.','Не заменяет фото конкретного камня.','secondary',.3),
      ('kraft-fibers','Крафтовое волокно','Материалы','repeat','Короткие направленные волокна, более выраженные, чем у гладкой бумаги.',['Рестораны и продукты','Упаковка и печать','Ландшафт и экология'],'Поддерживает переработанную бумагу, упаковку и ремесленный характер.','Не делать волокна контрастными под длинным текстом.','secondary',.4),
      ('terracotta-grain','Терракотовая пористость','Материалы','repeat','Кодовая зернистая поверхность с пористым ритмом. Цвет берётся из токенов.',['Керамика и ремесло','Ландшафт и экология','Рестораны и продукты'],'Передаёт матовую земляную фактуру для предметных и природных брендов.','Рельеф условный; для показа изделия нужен отдельный снимок.','secondary',.5),
      ('limestone-pores','Известняк: вытянутые поры','Материалы','repeat','Небольшие вытянутые поры и минеральная пыль.',['Недвижимость и интерьер','Строительство и ремонт','Туризм и отели'],'Мягкая каменная ассоциация для светлых архитектурных поверхностей.','Не повторять слишком мелко: поры потеряют масштаб.','secondary',.45),
      ('slate-cleavage','Слоистый сланец','Материалы','cover','Тонкие неровные слои; графическая интерпретация расслоения камня.',['Строительство и ремонт','Ландшафт и экология','Производство'],'Даёт горизонтальное направление и материальный характер.','Текущая версия композиционная, не бесшовная.','secondary',.3),
      ('asphalt-grit','Асфальтовая крошка','Материалы','repeat','Частая мелкая зернистость для дорожных и промышленных тем.',['Авто и логистика','Эвакуаторы и переезды','Строительство и ремонт'],'Помогает связать фон с дорогой и рабочей поверхностью.','Сохранять низкий контраст; фотографией асфальта не является.','secondary',.45),
      ('leather-grain','Кожаное зернение','Материалы','repeat','Замкнутые нерегулярные ячейки; графическое тиснение кожи.',['Ювелирка и fashion','Авто и логистика','Барбершопы и мужской уход'],'Ассоциации с аксессуарами и предметным ремеслом.','При крупном масштабе стилизация становится заметной.','secondary',.3),
      ('rattan-weave','Ротанговое плетение','Плетения','repeat','Широкие пересекающиеся полосы с чередованием перекрытия.',['Кухни и мебель','Туризм и отели','Ландшафт и экология'],'Природная конструктивная фактура для мебели и отдыха.','Избегать мелкого масштаба и муара.','secondary',.35),
      ('corrugated-cardboard','Гофрокартон','Материалы','repeat','Ритмичные рёбра гофрированной упаковки.',['Упаковка и печать','Эвакуаторы и переезды','Рестораны и продукты'],'Упаковочная метафора для доставки, коробок и переездов.','Не использовать как доказательство экологичности товара.','secondary',.35),
      ('perforated-metal','Перфорированный лист','Промышленная графика','repeat','Смещённые ряды круглой перфорации; регулярная геометрия.',['Производство','Строительство и ремонт','Авто и логистика'],'Поддерживает детали оборудования и металлических изделий.','Проверить муар; не делать отверстия крупными за текстом.','primary',.2),
      ('diamond-plate','Рифлёный металл','Промышленная графика','repeat','Рельефные диагональные насечки листового металла, векторная условность.',['Производство','Авто и логистика','Спорт и outdoor'],'Уместен для оборудования, рабочих поверхностей и функционального спорта.','Не выдавать за точный стандарт рифления.','secondary',.25),
      ('honeycomb-structure','Сотовая структура','Геометрия','cover','Шестиугольная конструктивная сетка; отдельная композиция.',['Производство','IT и SaaS','Спорт и outdoor'],'Показывает модульность и структурную связь элементов.','Не использовать как символ научного подтверждения.','primary',.17),
      ('stitch-lines','Строчка и швы','Плетения','repeat','Парные ряды стежков с тонкой направляющей.',['Ювелирка и fashion','Керамика и ремесло','Кухни и мебель'],'Подходит для пошива, обивки и ручной работы.','Это декоративная строчка, не схема производства.','secondary',.3),
      ('sound-contours','Звуковая огибающая','Схемы','cover','Сдержанный ритм вертикальных амплитуд.',['Музыка и культура','Образование','Креативные услуги'],'Поддерживает звук, речь, выступления и обучение языку.','График не содержит реальной аудиозаписи.','primary',.22),
      ('knowledge-network','Карта связей','Схемы','cover','Небольшой связный граф без фиктивных подписей и чисел.',['Образование','HR и консалтинг','IT и SaaS'],'Метафора системного знания, команды и обмена.','Не анимировать как бесконечную сеть частиц.','primary',.24),
      ('orbital-paths','Орбитальные траектории','Схемы','cover','Пересекающиеся эллиптические траектории.',['Наука и исследования','Образование','IT и SaaS'],'Метафора исследования, движения и взаимного влияния.','Не является физически точной моделью атома или орбит.','primary',.2),
      ('molecular-bonds','Молекулярные связи','Схемы','cover','Схематическая структура связей и узлов.',['Наука и исследования','Медицина и стоматология','Beauty и wellness'],'Уместна при реальной связи бренда с составами и лабораторной работой.','Не изображает подтверждённую химическую формулу.','primary',.18),
      ('root-mycelium','Корни и мицелий','Природная графика','overlay','Ветвящаяся органическая структура с уменьшающейся толщиной линий.',['Ландшафт и экология','Психология и коучинг','Образование'],'Метафора роста, поддержки и взаимосвязей.','Не подавать как медицинскую схему нервной системы.','secondary',.28),
      ('contour-leaves','Контуры листвы','Природная графика','overlay','Линейная ботаническая композиция у края; без растровой тени.',['Ландшафт и экология','Beauty и wellness','Туризм и отели'],'Подходит натуральным продуктам, уходу и природным пространствам.','Не заменяет ботаническое описание вида.','primary',.25),
      ('river-route','Маршрут и течение','Схемы','cover','Извилистая линия с тремя опорными точками, центр остаётся спокойным.',['Туризм и отели','Эвакуаторы и переезды','Образование'],'Поддерживает маршрут, этапы сервиса и движение к цели.','Не является настоящей картой или маршрутом доставки.','primary',.3),
      ('city-blocks','Городские кварталы','Схемы','cover','Абстрактная планировка кварталов с внутренними контурами.',['Недвижимость и интерьер','Авто и логистика','Юристы и B2B'],'Городская структура для недвижимости и локальных услуг.','Не выдавать за карту конкретного города.','primary',.22),
      ('parcel-lines','Границы участков','Схемы','cover','Нерегулярные соединённые полигоны — метафора земельных границ.',['Недвижимость и интерьер','Ландшафт и экология','Юристы и B2B'],'Привязка к земле, зонированию и территориям.','Это не кадастровые данные и не юридическая схема.','primary',.22),
      ('blueprint-utilities','Инженерные коммуникации','Промышленная графика','cover','Линии трубопроводов и условные клапаны.',['Инженерные системы','Строительство и ремонт','Производство'],'Подходит сантехнике, отоплению и инженерному монтажу.','Декоративная схема не заменяет проект коммуникаций.','primary',.25),
      ('helix-ribbon','Спиральная структура','Схемы','cover','Схематическая двойная лента с перемычками.',['Наука и исследования','Образование','Медицина и стоматология'],'Уместна для исследовательских и образовательных тем.','Не является моделью определённого участка ДНК.','primary',.19),
      ('ice-fractures','Ледяные трещины','Прозрачные слои','overlay','Угловатый рисунок трещин — условная графика льда.',['Рестораны и продукты','Туризм и отели','Спорт и outdoor'],'Холодная оптика для напитков, зимы и охлаждения.','Не использовать как реалистичный ледяной объект.','highlight',.65),
      ('condensation-drops','Капли конденсата','Прозрачные слои','repeat','Мягкие контуры капель на прозрачном слое.',['Клининг и окна','Рестораны и продукты','Beauty и wellness'],'Метафора прохлады, воды и поверхности стекла.','Капли не преломляют фон физически; повтор нужно держать редким.','highlight',.75),
      ('spark-scatter','Искры обработки','Прозрачные слои','overlay','Статичные направленные штрихи с разной длиной и интенсивностью.',['Производство','Авто и логистика','Строительство и ремонт'],'Акцент обработки металла и рабочего процесса.','Не превращать в постоянный фейерверк за текстом.','accent',.65),
      ('steam-ribbons','Пар и дымка','Прозрачные слои','overlay','Слабоконтрастные изогнутые струи без размытия в браузере.',['Рестораны и продукты','Beauty и wellness','Туризм и отели'],'Атмосферный акцент горячих напитков, бани и ухода.','Стилизация, не видеозапись и не фотореалистичный дым.','highlight',1),
    ]
    for row in defs:add(row[0],row[1],row[2],'SVG',*row[3:])
    css=[
      ('isometric-grid','Изометрическая сетка','Геометрия','repeat','Три направления с углами 60° для объёмной модульной структуры.',['Производство','IT и SaaS','Образование'],'Помогает показать сборку и пространственное мышление.','Не применять одновременно с другой технической сеткой.','primary',.13,'background-image:repeating-linear-gradient(30deg,transparent 0 27px,$INK 27px 28px,transparent 28px 55px),repeating-linear-gradient(150deg,transparent 0 27px,$INK 27px 28px,transparent 28px 55px);background-size:var(--rb-scale,110px) calc(var(--rb-scale,110px) * .577350269);'),
      ('diagonal-hatch','Диагональная штриховка','Геометрия','repeat','Один строгий ритм тонких наклонных линий.',['Производство','Строительство и ремонт','Спорт и outdoor'],'Связь с сечением материала, маркировкой и направлением.','Тонкие линии могут давать муар.','secondary',.12,'background-image:linear-gradient(135deg,$INK 0 2%,transparent 2% 48%,$INK 48% 52%,transparent 52% 98%,$INK 98%);background-size:var(--rb-scale,24px) var(--rb-scale,24px);'),
      ('carbon-weave','Карбоновое переплетение','Плетения','repeat','Двухцветная диагональная тканая структура, CSS-стилизация карбона.',['Авто и логистика','Спорт и outdoor','Производство'],'Подходит материалам, экипировке и автомобильным деталям.','Не выдавать за фотографию карбонового изделия.','primary',.22,'background-image:linear-gradient(27deg,$INK 5px,transparent 5px),linear-gradient(207deg,$INK 5px,transparent 5px),linear-gradient(27deg,$SECONDARY 5px,transparent 5px),linear-gradient(207deg,$SECONDARY 5px,transparent 5px);background-position:0 5px,10px 0,0 10px,10px 5px;background-size:var(--rb-scale,20px) var(--rb-scale,20px);'),
      ('holographic-foil','Голографическая фольга','Свет','cover','Мягкое поле спектральных отражений из токенов бренда.',['Упаковка и печать','Ювелирка и fashion','Креативные услуги'],'Передаёт оптический характер фольги в цифровой стилизации.','Это не точное воспроизведение печатного материала.','primary',.5,'background-image:conic-gradient(from 35deg at 35% 45%,$HIGHLIGHT,$ACCENT,$SECONDARY,$HIGHLIGHT,$INK,$ACCENT,$HIGHLIGHT);'),
      ('pearl-sheen','Перламутровая поверхность','Свет','cover','Несколько светлых отражений с мягкой цветной глубиной.',['Ювелирка и fashion','Beauty и wellness','Свадьбы и события'],'Сдержанная оптика для жемчуга, ухода и подарков.','Не заменяет фотографию реального жемчуга.','primary',.6,'background-image:radial-gradient(ellipse at 35% 30%,$HIGHLIGHT,transparent 50%),radial-gradient(ellipse at 75% 70%,$ACCENT,transparent 55%),linear-gradient(125deg,transparent,$SECONDARY,transparent);'),
      ('blind-shadows','Тени жалюзи','Свет','cover','Несколько широких диагональных полос дневной тени.',['Клининг и окна','Недвижимость и интерьер','Beauty и wellness'],'Ассоциация с окнами, интерьером и спокойным дневным светом.','Не класть тёмную полосу прямо за мелким текстом.','secondary',.18,'background-image:repeating-linear-gradient(115deg,transparent 0 70px,$INK 95px 128px,transparent 150px 220px);'),
      ('mist-layers','Слои тумана','Свет','overlay','Длинные низкоконтрастные световые слои; без живых частиц.',['Туризм и отели','Психология и коучинг','Beauty и wellness'],'Создаёт ощущение воздуха и спокойной дистанции.','Не снижать контраст текста ради атмосферы.','highlight',.45,'background-image:radial-gradient(ellipse 90% 13% at 20% 25%,$INK,transparent),radial-gradient(ellipse 95% 12% at 80% 65%,$INK,transparent);'),
      ('folded-paper','Грани сложенной бумаги','Геометрия','cover','Крупные полупрозрачные плоскости, напоминающие сгибы листа.',['Упаковка и печать','Образование','Креативные услуги'],'Метафора конструкции, идеи и аккуратной ручной сборки.','Это композиция, не бесшовная текстура.','secondary',.22,'background-image:conic-gradient(from 20deg at 65% 40%,transparent 0deg 70deg,$INK 70deg 130deg,transparent 130deg 240deg,$HIGHLIGHT 240deg 310deg,transparent 310deg);'),
      ('heatmap-field','Поле интенсивности','Данные','cover','Статичное градиентное поле с несколькими зонами интенсивности.',['Финансы и аналитика','IT и SaaS','Наука и исследования'],'Метафора измерений и концентрации данных.','Декор не содержит настоящих аналитических результатов.','primary',.35,'background-image:radial-gradient(ellipse at 22% 70%,$ACCENT,transparent 35%),radial-gradient(ellipse at 70% 25%,$INK,transparent 40%),linear-gradient(90deg,$SECONDARY,transparent);'),
      ('speed-trails','Следы движения','Свет','overlay','Узкие параллельные световые полосы с диагональным направлением.',['Авто и логистика','Эвакуаторы и переезды','Спорт и outdoor'],'Передаёт скорость и направленность без видео и анимации.','Для спокойных доверительных услуг может быть слишком динамично.','accent',.35,'background-image:linear-gradient(165deg,transparent 40%,$INK 40.2%,transparent 40.6%),linear-gradient(165deg,transparent 52%,$SECONDARY 52.2%,transparent 52.6%),linear-gradient(165deg,transparent 60%,$HIGHLIGHT 60.2%,transparent 60.5%);'),
    ]
    for row in css:
        if row[0]=='heatmap-field':
            rows=[]
            for y in range(6):
                colors=[]
                for x in range(8):
                    token=['$SECONDARY','$INK','$ACCENT','$HIGHLIGHT'][(x*x+y*3+x*y)%4]
                    colors.append(f'{token} {x*12.5:g}% {(x+1)*12.5:g}%')
                rows.append('linear-gradient(90deg,'+','.join(colors)+')')
            row=list(row);row[-1]='background-image:'+','.join(rows)+';background-size:100% 16.666667%;background-position:'+','.join('0 '+str(y*20)+'%' for y in range(6))+';background-repeat:no-repeat;'
            row[4]='Статичная матрица цветовых ячеек; графическая метафора тепловой карты без чисел.'
        add(row[0],row[1],row[2],'CSS',*row[3:])
    photos=[
      ('travertine-surface','Травертин: натуральный камень',['Недвижимость и интерьер','Beauty и wellness','Туризм и отели'],'Светлый пористый камень с естественным осадочным рисунком.','Тёплая материальная основа для архитектуры и спокойного ухода.'),
      ('oak-veneer-photo','Дубовый шпон',['Кухни и мебель','Рестораны и продукты','Туризм и отели'],'Натуральная древесина с ровным мелким волокном.','Сопоставляет сайт с мебелью, столярным делом и тёплым интерьером.'),
      ('satin-folds-photo','Сатин: мягкие складки',['Beauty и wellness','Свадьбы и события','Ювелирка и fashion'],'Фотореалистичная гладкая ткань с широкими неглубокими складками.','Мягкая предметная ассоциация для красоты, одежды и событий.'),
      ('velvet-photo','Графитовый бархат',['Ювелирка и fashion','Музыка и культура','Туризм и отели'],'Тёмный ворс и крупные спокойные складки.','Сценическая и предметная основа для украшений, музыки и вечерних пространств.'),
      ('ceramic-glaze-photo','Глазурованная керамика',['Керамика и ремесло','Рестораны и продукты','Недвижимость и интерьер'],'Светлая глазурь с мягким нерегулярным краплением.','Связывает цифровую поверхность с посудой, материалом и мастерской.'),
      ('brushed-aluminum-photo','Шлифованный алюминий',['Производство','Авто и логистика','IT и SaaS'],'Ровный холодный металл с направленными микроцарапинами.','Подходит оборудованию, технике и предметной инженерии.'),
    ]
    for id,name,niches,description,why in photos:
        add(id,name,'Фотореалистичные материалы','WebP','cover',description,niches,why,'Сгенерированная композиция без гарантии бесшовности. Не повторять; рисунок материала не перекрашивается токенами.',intensity=.75)
    assert len(result)==44
    return result
