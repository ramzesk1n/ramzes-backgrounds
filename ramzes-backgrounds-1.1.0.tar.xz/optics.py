"""PDF-inspired optical metaphors. Static geometry, transparent gaps, no runtime JS."""
import math
import random


def vectors(svg):
    def line(d, width=1, opacity=1):
        return f'<path d="{d}" fill="none" stroke="black" stroke-width="{width}" opacity="{opacity}" stroke-linecap="round" stroke-linejoin="round"/>'

    # Hexagonal bonds, three neighbours per atom. Integer cell, exact periodic clipping.
    graphene='<defs><pattern id="g" width="32" height="48" patternUnits="userSpaceOnUse">'+line('M0 8L16 0L32 8V24L16 32L0 24Z M16 32V48',.65,.55)
    for x,y in [(0,8),(16,0),(32,8),(0,24),(16,32),(32,24)]:
        graphene+=f'<circle cx="{x}" cy="{y}" r="1.25"/>'
    graphene+='</pattern></defs><path d="M0 0H256V240H0z" fill="url(#g)"/>'
    svg('graphene-lattice',graphene,256,240)
    tubes=[]
    for j in range(-1,5):
        for n in range(5):
            y=j*64+n*2.5+9
            tubes.append(line(f'M0 {y:.1f}C64 {y-15:.1f} 192 {y+15:.1f} 256 {y:.1f}',.8,.35+n*.1))
    svg('nanotube-bundle',''.join(tubes))
    rng=random.Random(7401);inclusions=[]
    for _ in range(44):
        x,y=rng.uniform(0,256),rng.uniform(0,256);angle=rng.uniform(-70,70)
        for dx in (-256,0,256):
            for dy in (-256,0,256):
                if -17<x+dx<273 and -17<y+dy<273:
                    inclusions.append(f'<g transform="translate({x+dx:.2f} {y+dy:.2f}) rotate({angle:.2f})"><path d="M-10 -2L8 -3L12 1L-7 3Z" opacity=".45"/>'+line('M-14 6H14',.4,.18)+'</g>')
    svg('nanocomposite-inclusions',''.join(inclusions))
    rings='<defs><pattern id="m" width="64" height="64" patternUnits="userSpaceOnUse">'+line('M47 19A21 21 0 1 0 47 45 M42 24A14 14 0 1 0 42 40',1.4,.7)+'<path d="M52 29H57V35H52Z" opacity=".45"/></pattern></defs><path d="M0 0H256V256H0z" fill="url(#m)"/>'
    svg('metasurface-resonators',rings)

    lightning=[[(820,-10),(784,82),(823,112),(748,205),(785,235),(706,331),(743,359),(656,485),(692,502),(614,645)],
               [(796,136),(866,165),(842,240),(904,276),(875,339)],[(754,269),(675,275),(658,340),(596,377)],
               [(728,399),(808,446),(781,502),(842,555)]]
    bolts=[]
    for points in lightning:
        d='M'+'L'.join(f'{x} {y}' for x,y in points)
        for w,a in [(16,.035),(7,.10),(2,.85)]:bolts.append(line(d,w,a))
    svg('branch-lightning',''.join(bolts),960,640)
    corona=[]
    for j in range(19):
        a=-math.pi*.93+j*.055;length=120+75*math.sin(j*1.4)**2
        x,y=800+length*math.cos(a),560+length*math.sin(a)
        d=f'M800 560Q{760-j*3} {440-j*3} {x:.1f} {y:.1f}'
        corona+= [line(d,9,.04),line(d,1,.7)]
    corona.append(line('M800 640V560',2,.7))
    svg('corona-streamers',''.join(corona),960,640)
    tracks=[]
    for j in range(7):
        y=100+j*61
        d=f'M470 {y}H{575+j*15}Q{620+j*15} {y} {645+j*15} {y+35}L{760+j*13} {y+130}H970'
        tracks.append(line(d,1,.2))
        for k in range(4):tracks.append(f'<circle cx="{490+k*29}" cy="{y}" r="{1.5+k*.4}" opacity="{.15+k*.18}"/>')
    svg('ion-tracks',''.join(tracks),960,640)
    frost=[]
    def twig(x,y,length,angle,depth):
        ex,ey=x+length*math.cos(angle),y+length*math.sin(angle)
        frost.append(line(f'M{x:.1f} {y:.1f}L{ex:.1f} {ey:.1f}',max(.45,depth*.3),.45+depth*.08))
        if depth:
            for t in (.48,.75):
                xx,yy=x+(ex-x)*t,y+(ey-y)*t
                for sign in (-1,1):twig(xx,yy,length*.29,angle+sign*.65,depth-1)
    for angle in (1.9,2.4,2.9):twig(955,8,330,angle,2)
    svg('frost-dendrites',''.join(frost),960,640)
    cracks=[]
    for d in ['M510 -20L620 90L578 178L708 240L660 365L735 465L698 660','M620 90L795 75L880 155L975 130','M578 178L455 300L500 405L410 500','M708 240L851 293L835 425L970 470','M660 365L560 480L610 640','M735 465L870 540L915 660']:
        for w,a in [(22,.025),(11,.09),(3,.8)]:cracks.append(line(d,w,a))
    svg('magma-channels',''.join(cracks),960,640)
    meteors=['<defs><linearGradient id="tail"><stop stop-opacity="0"/><stop offset="1" stop-opacity="1"/></linearGradient></defs>']
    for x,y,length in [(760,95,160),(875,320,210),(670,485,100)]:
        meteors.append(f'<path d="M{x-length} {y+length*.56}L{x} {y}" fill="none" stroke="url(#tail)" stroke-width="2"/><circle cx="{x}" cy="{y}" r="2.4"/>')
    svg('meteor-streaks',''.join(meteors),960,640)
    wake=[];rng=random.Random(7402)
    for _ in range(130):
        x=rng.uniform(0,960);y=480+34*math.sin(x/125)+rng.gauss(0,16);r=rng.uniform(.7,2.1)
        wake.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{r:.1f}" opacity="{rng.uniform(.2,.8):.2f}"/>')
    svg('bioluminescent-wake',''.join(wake),960,640)


def catalog(item):
    out=[]
    # id, title, placement, description, niches, reason, caution, ink role, strength, mechanism, PDF ref
    vectors=[
      ('graphene-lattice','Графеновая сетка','repeat','Мелкая углеродная решётка: связи и узлы образуют лёгкий периодический орнамент.',['Наука и исследования','Электроника и сенсоры','Производство'],'Связывает визуальный язык с тонкими проводящими структурами.','Увеличенная условная сетка, не микрофотография и не точная атомная модель.','primary',.24,'Геометрия углеродной сетки; оптические свойства не моделируются.','M:2–3'),
      ('nanotube-bundle','Пучки нанотрубок','repeat','Группы тонких параллельных волокон с плавным периодическим изгибом.',['Наука и исследования','Производство','Спорт и экипировка'],'Подходит темам армирования, направленной проводимости и лёгкой структуры.','Не путать с фотографией нанотрубок; рисунок не подтверждает состав продукта.','secondary',.24,'Метафора волокнистой морфологии, без симуляции поглощения.','M:3–4'),
      ('nanocomposite-inclusions','Включения нанокомпозита','repeat','Продолговатые пластинки-наполнители в редком поле. Плитка с завёрнутыми краями.',['Наука и исследования','Производство','Строительство и ремонт'],'Отличается от минеральной крошки направленными пластинчатыми включениями.','Размеры увеличены для дизайна; оттенок реального композита зависит от состава.','secondary',.23,'Метафора распределённых пластинчатых включений.','M:4–5'),
      ('metasurface-resonators','Резонаторы метаповерхности','repeat','Ритм разомкнутых двойных колец и небольших контактных площадок.',['Наука и исследования','Электроника и сенсоры','Оптика и фотоника'],'Передаёт идею спроектированной микрогеометрии.','Не обещает отрицательное преломление или невидимость; это условный орнамент.','primary',.25,'Метафора повторяющихся резонаторов, без расчёта частот.','M:6–7,10–11'),
      ('branch-lightning','Разветвлённая молния','overlay','Статичный разряд справа: тонкое ядро и два слабых широких контура создают ореол.',['Энергетика','IT и SaaS','Игры и мероприятия'],'Выразительный единичный акцент для темы энергии и вычислений.','Не добавлять резкие вспышки; слева оставлено больше места под текст.','accent',.7,'Образ электрического разряда; свечение построено шириной штрихов.','L:1'),
      ('corona-streamers','Коронные стримеры','overlay','Веер тонких расходящихся каналов над условным электродом в правом нижнем углу.',['Энергетика','Электроника и сенсоры','Наука и исследования'],'Более локальный электрический акцент, чем крупная молния.','Стилизованный коронный разряд; не схема безопасного оборудования.','accent',.55,'Образ стримеров коронного разряда у острия.','L:1'),
      ('ion-tracks','Ионные дорожки','cover','Упорядоченные угловые трассы с последовательностями точек справа. Статичный срез потока.',['Электроника и сенсоры','IT и SaaS','Наука и исследования'],'Подходит электронике и данным; движение передаётся расположением элементов.','Это визуальная метафора: электроны не видны как светящиеся шарики такого масштаба.','primary',.38,'Метафора направленного потока частиц, без физического расчёта.','L:1,3'),
      ('frost-dendrites','Инеевые дендриты','overlay','Тонкие древовидные ответвления растут из правого верхнего угла.',['Холод и климат','Туризм и отели','Оптика и фотоника'],'Холодная природная структура для климата, зимних услуг и чистой оптики.','Не повторять плиткой; это художественный рост кристаллов, не минералогическая схема.','highlight',.6,'Образ ветвящегося кристаллического роста.','L:2'),
      ('magma-channels','Раскалённые прожилки','cover','Сеть крупных трещин в правой части с тонким ярким ядром и полупрозрачным ореолом.',['Энергетика','Игры и мероприятия','Производство'],'Даёт образ внутреннего жара и мощности без растровой видеопетли.','Цвет берётся из accent; для огненного образа нужен тёплый акцент сайта. Не размножать.','accent',.66,'Образ раскалённых каналов между тёмными плитами.','L:2'),
      ('meteor-streaks','Метеорные следы','overlay','Три диагональных затухающих штриха с компактной яркой головкой.',['Космос и технологии','Игры и мероприятия','Образование'],'Лёгкий знак скорости и направления, оставляющий свободной левую часть.','Штрихи неподвижны; не изображают траектории реальных небесных тел.','highlight',.75,'Образ светящегося следа метеора, без анимации.','L:2'),
      ('bioluminescent-wake','Биолюминесцентный след','cover','Узкая полоса разреженных светящихся точек у нижнего края композиции.',['Туризм и отели','Beauty и wellness','Ландшафт и экология'],'Природная ночная атмосфера для воды и путешествий.','Это не фотография конкретного пляжа и не обещание сезонного природного явления.','accent',.65,'Художественный образ биологического свечения в воде.','L:2'),
    ]
    materials={'graphene-lattice','nanotube-bundle','nanocomposite-inclusions','metasurface-resonators'}
    for id,name,placement,desc,ns,why,avoid,role,strength,mechanism,ref in vectors:
        c=item(id,name,'Наноматериалы' if id in materials else 'Энергия и оптика','SVG',placement,id+'.svg',desc,ns,why,avoid,[], '#edf0eb','#38534a','#a36945',strength)
        c.update(ink_role=role,mechanism=mechanism,pdf_refs=[ref],fidelity='Художественная кодовая стилизация; не физическая симуляция.')
        out.append(c)
    css=[
      ('quantum-dot-emission','Свечение квантовых точек','repeat','Три размера мягких световых точек с отдельными цветовыми ролями; периодическая плоскость.',['Электроника и сенсоры','Оптика и фотоника','Наука и исследования'],'Образ излучающих нанокристаллов для дисплеев и фотоники.','Цвета подчинены бренду, поэтому не кодируют физический размер или длину волны.',.62,'Флуоресценция; стилизация без привязки к спектральным данным.','M:5–6','background-image:radial-gradient(circle at 16% 25%,$ACCENT 0 1px,transparent 5px),radial-gradient(circle at 68% 63%,$INK 0 2px,transparent 7px),radial-gradient(circle at 84% 18%,$SECONDARY 0 1px,transparent 4px);background-size:var(--rb-scale,96px) var(--rb-scale,96px);'),
      ('aerogel-cloud','Дымчатый аэрогель','cover','Молочные вытянутые поля с прозрачными промежутками и тонкими светлыми гранями.',['Строительство и ремонт','Космос и технологии','Наука и исследования'],'Лёгкая полупрозрачная поверхность для тем изоляции и пористой структуры.','Не фотореалистичный аэрогель; молочная глубина условна. Не использовать как образец товара.',.56,'Образ рассеяния в пористой среде; палитра задаётся токенами.','M:7–8','background-image:radial-gradient(ellipse 42% 65% at 75% 48%,$HIGHLIGHT,transparent 75%),radial-gradient(ellipse 34% 60% at 63% 52%,$SECONDARY,transparent 76%),linear-gradient(110deg,transparent 48%,$INK 64%,transparent 85%);'),
      ('opal-domains','Опаловые домены','cover','Несколько широких локальных цветовых доменов с мягкими границами, без общего радужного градиента.',['Ювелирка и fashion','Оптика и фотоника','Креативные услуги'],'Образ игры цвета в структурированных материалах.','Это условный опал; цвет не меняется от угла и не соответствует спектру реального камня.',.5,'Метафора структурного цвета в локальных доменах.','M:7','background-image:radial-gradient(ellipse 25% 34% at 70% 25%,$ACCENT,transparent 80%),radial-gradient(ellipse 22% 30% at 88% 58%,$INK,transparent 80%),radial-gradient(ellipse 30% 24% at 52% 80%,$SECONDARY,transparent 80%),radial-gradient(ellipse 18% 28% at 45% 43%,$HIGHLIGHT,transparent 80%);'),
      ('electrochromic-pane','Электрохромная панель','cover','Три статичные зоны: почти прозрачная, тонированная и более плотная. Мягкий свет вдоль края.',['Клининг и окна','Строительство и ремонт','Электроника и сенсоры'],'Объясняет управляемую прозрачность окон через состояние поверхности.','Без датчиков и реакции на солнце; тема сайта лишь меняет цвет токенов. Преломление не рассчитывается.',.38,'Образ состояния электрохромного слоя; без электрического управления.','M:9–10','background-image:linear-gradient(90deg,transparent 0 33%,$SECONDARY 33% 66%,$INK 66%),linear-gradient(115deg,transparent 20%,$HIGHLIGHT 48%,transparent 54%);'),
      ('plasma-orb','Плазменная сфера','cover','Компактный световой диск справа: яркое ядро, кольцевая оболочка и мягкий ореол.',['IT и SaaS','Энергетика','Игры и мероприятия'],'Центральный энергетический объект для hero без 3D-движка.','Не подтверждённая модель шаровой молнии; без реакции на курсор. Не помещать текст на ядро.',.75,'Художественная плазменная сфера, не научная модель шаровой молнии.','L:1','background-image:radial-gradient(circle at 76% 50%,$HIGHLIGHT 0 1%,transparent 4%),radial-gradient(circle at 76% 50%,transparent 8%,$ACCENT 11%,transparent 14%),radial-gradient(circle at 76% 50%,$INK,transparent 28%);'),
      ('halo-rings','Световое гало','overlay','Одно тонкое световое кольцо справа с широким слабым ореолом.',['Оптика и фотоника','Ювелирка и fashion','Туризм и отели'],'Подходит локальному акценту вокруг предмета или логотипа.','Декоративное кольцо не воспроизводит угловой размер атмосферного гало.',.65,'Образ атмосферного светового кольца; не расчёт ледяных кристаллов.','L:2','background-image:radial-gradient(circle at 76% 48%,transparent 20%,$ACCENT 20.4%,transparent 21.2%),radial-gradient(circle at 76% 48%,transparent 17%,$HIGHLIGHT 20.5%,transparent 25%);'),
      ('sun-pillars','Световые столбы','overlay','Два узких вертикальных световых столба с затухающими концами.',['Оптика и фотоника','Энергетика','Космос и технологии'],'Вертикальный акцент для объектов, оптики и энергетических продуктов.','Не использовать как сплошную вертикальную засветку текста.',.55,'Образ отражения света ледяными кристаллами; без физического расчёта.','L:2','background-image:radial-gradient(ellipse 1% 45% at 80% 40%,$HIGHLIGHT,transparent 100%),radial-gradient(ellipse 5% 48% at 80% 40%,$ACCENT,transparent 100%),radial-gradient(ellipse 1% 30% at 65% 70%,$INK,transparent 100%);'),
      ('nebula-cloud','Туманность','cover','Асимметричное широкое облако цвета справа с тёмными полостями; статичные градиенты без blur.',['Космос и технологии','Игры и мероприятия','Креативные услуги'],'Даёт глубину большой космической композиции без фотографии и видео.','Не снимок конкретной туманности; слишком высокая интенсивность мешает тексту.',.64,'Образ рассеянного газа и пыли, без астрофизической симуляции.','L:3','background-image:radial-gradient(ellipse 15% 28% at 75% 45%,var(--rb-bg,var(--background,#edf0eb)),transparent 100%),radial-gradient(ellipse 40% 20% at 70% 35%,$ACCENT,transparent 90%),radial-gradient(ellipse 25% 42% at 85% 65%,$SECONDARY,transparent 90%),radial-gradient(ellipse 28% 18% at 55% 75%,$INK,transparent 95%);'),
      ('accretion-disk','Аккреционный диск','cover','Вытянутое кольцо справа с тёмным центром и слабой внешней засветкой.',['Космос и технологии','Игры и мероприятия','Образование'],'Узнаваемая космическая форма с простым CSS и свободным местом слева.','Не моделирует гравитационное линзирование или вид настоящей чёрной дыры.',.8,'Художественный аккреционный диск; без общей теории относительности.','L:3','background-image:radial-gradient(ellipse 23% 7% at 74% 54%,transparent 47%,$HIGHLIGHT 50%,$ACCENT 58%,transparent 72%),radial-gradient(ellipse 26% 10% at 74% 54%,transparent 45%,$INK 60%,transparent 95%);'),
    ]
    for id,name,placement,desc,ns,why,avoid,strength,mechanism,ref,body in css:
        c=item(id,name,'Наноматериалы' if id in {'quantum-dot-emission','aerogel-cloud','opal-domains','electrochromic-pane'} else 'Энергия и оптика','CSS',placement,None,desc,ns,why,avoid,[], '#edf0eb','#38534a','#a36945',strength,96 if placement=='repeat' else 256)
        c.update(css_body=body,mechanism=mechanism,pdf_refs=[ref],fidelity='Художественная кодовая стилизация; не физическая симуляция.')
        out.append(c)
    return out


def enrich(cards):
    extra={
      'quiet-aurora':(['L:2–3'],['северное сияние','аврора','aurora']),
      'water-caustics':(['L:2'],['каустика','рябь','caustics']),
      'spark-scatter':(['L:2'],['искры','сварка','sparks']),
      'ice-fractures':(['L:2'],['лёд','кристалл','ice']),
      'holographic-foil':(['M:1,7','L:2'],['дифракция','интерференция','иридесценция']),
      'pearl-sheen':(['M:7','L:2'],['перламутр','структурный цвет']),
      'ceramic-glaze-photo':(['M:8–9'],['керамика','нанокерамика']),
      'glass-surface':(['M:9–10'],['прозрачная керамика','фотохромный','самовосстанавливающийся']),
      'orbital-paths':(['L:3'],['орбиты','космос','электроны']),
      'steam-ribbons':(['L:2'],['пар','дым','огонь']),
    }
    for c in cards:
        if c['id'] in extra:
            refs,keywords=extra[c['id']]
            c.setdefault('pdf_refs',[]).extend(refs)
            c['keywords']=list(dict.fromkeys(c.get('keywords',[])+keywords))
        if c.get('pdf_refs'):
            c.setdefault('fidelity','Визуальная ассоциация; не подтверждает физический состав или свойства материала.')
            c['alpha_note']='Прозрачные промежутки в декоративном слое; фон секции задаётся отдельно.' if c['tech']!='WebP' else 'Непрозрачное изображение; снижение opacity смешивает его с фоном, но не вырезает материал.'
