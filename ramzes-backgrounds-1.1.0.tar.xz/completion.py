"""Static original surface generators for the final hundred recipes."""
import hashlib
import math
import random
import re
from completion_data import rows, photos, RASTER_IDS

TAU=math.tau

def path(d,width=.7,alpha=.55,fill='none'):
    return f'<path d="{d}" fill="{fill}" stroke="black" stroke-width="{width:.3f}" opacity="{alpha:.3f}" stroke-linecap="round" stroke-linejoin="round"/>'

def line(points,width=.7,alpha=.55,close=False,fill='none'):
    return path('M'+'L'.join(f'{x:.2f} {y:.2f}' for x,y in points)+('Z' if close else ''),width,alpha,fill)

def ellipse(x,y,rx,ry=None,width=.6,alpha=.5,fill='none'):
    return f'<ellipse cx="{x:.2f}" cy="{y:.2f}" rx="{rx:.2f}" ry="{(ry if ry is not None else rx):.2f}" stroke="black" stroke-width="{width:.2f}" opacity="{alpha:.3f}" fill="{fill}"/>'

def wrapped(fragment,x,y,margin=40):
    places=[(x+dx,y+dy) for dx in (-256,0,256) for dy in (-256,0,256) if -margin<x+dx<256+margin and -margin<y+dy<256+margin]
    if len(places)>1 and len(fragment)>230:
        key='w'+hashlib.sha256((fragment+str(x)+str(y)).encode()).hexdigest()[:12]
        return f'<defs><g id="{key}">{fragment}</g></defs>'+''.join(f'<use href="#{key}" x="{xx:.2f}" y="{yy:.2f}"/>' for xx,yy in places)
    return ''.join(f'<g transform="translate({xx:.2f} {yy:.2f})">{fragment}</g>' for xx,yy in places)

def grain(rng,count=180,radius=1):
    return ''.join(wrapped(ellipse(0,0,rng.uniform(.2,radius),width=0,alpha=rng.uniform(.12,.48),fill='black'),rng.random()*256,rng.random()*256,radius+1) for _ in range(count))

def wave_lines(count=20,amp=4,freq=2,width=.65,phase=1):
    out=[]
    for j in range(-2,count+3):
        points=[(x,j*256/count+amp*math.sin(TAU*x/256*freq+j*TAU/count*phase)) for x in range(0,257,4)]
        out.append(line(points,width,.35+(j%3)*.1))
    return ''.join(out)

def halfplane(poly,a,b,c):
    out=[]
    for i,p in enumerate(poly):
        q=poly[(i+1)%len(poly)];vp=a*p[0]+b*p[1]-c;vq=a*q[0]+b*q[1]-c
        if vp<=1e-7:out.append(p)
        if (vp<0)!=(vq<0):
            t=vp/(vp-vq);out.append((p[0]+t*(q[0]-p[0]),p[1]+t*(q[1]-p[1])))
    return out

def cells(rng,side=7):
    """Periodic Voronoi cells from jittered sites and their nearest torus copies."""
    step=256/side
    seeds=[((x+.5+rng.uniform(-.34,.34))*step,(y+.5+rng.uniform(-.34,.34))*step) for y in range(side) for x in range(side)]
    copies=[(x+dx,y+dy) for x,y in seeds for dx in (-256,0,256) for dy in (-256,0,256)]
    out=[]
    for x,y in seeds:
        poly=[(x-256,y-256),(x+256,y-256),(x+256,y+256),(x-256,y+256)]
        neighbours=sorted((p for p in copies if abs(p[0]-x)+abs(p[1]-y)>1e-7),key=lambda p:(p[0]-x)**2+(p[1]-y)**2)[:20]
        for qx,qy in neighbours:
            poly=halfplane(poly,2*(qx-x),2*(qy-y),qx*qx+qy*qy-x*x-y*y)
            if not poly:break
        out.append((x,y,[(px-x,py-y) for px,py in poly]))
    return out

def rounded(points,factor=.2,width=.7,alpha=.55,fill='none'):
    if len(points)<3:return ''
    starts=[];ends=[]
    for i,p in enumerate(points):
        before=points[i-1];after=points[(i+1)%len(points)]
        starts.append((p[0]+factor*(before[0]-p[0]),p[1]+factor*(before[1]-p[1])))
        ends.append((p[0]+factor*(after[0]-p[0]),p[1]+factor*(after[1]-p[1])))
    d=f'M{ends[-1][0]:.2f} {ends[-1][1]:.2f}'
    for start,p,end in zip(starts,points,ends):d+=f'L{start[0]:.2f} {start[1]:.2f}Q{p[0]:.2f} {p[1]:.2f} {end[0]:.2f} {end[1]:.2f}'
    return path(d+'Z',width,alpha,fill)

def cellular(id,rng):
    side={'watermelon-cell-field':10,'beef-fat-veins':5,'chocolate-snap-field':6,'zinc-etch-pits':11,'nickel-nodule-field':9,'soil-aggregate-field':7,'quartz-sorted-grains':13,'river-cobble-mosaic':5,'pebbled-leather-large':9,'acrylic-crazing':7,'polyethylene-film-creases':4,'lichen-islands-field':6,'pressed-powder-relief':7}[id]
    out=[]
    for x,y,pts in cells(rng,side):
        factor=.92 if id not in {'beef-fat-veins','acrylic-crazing','polyethylene-film-creases'} else 1
        shrunk=[(px*factor,py*factor) for px,py in pts]
        body=''
        if id=='watermelon-cell-field':body=rounded(shrunk,.35,.55,.48)+rounded([(px*.83,py*.83) for px,py in pts],.35,.3,.18)
        elif id=='beef-fat-veins':
            body=rounded(pts,.13,rng.uniform(2,4),.6)
            body+=''.join(path(f'M{-9+k*4} -9q-4 8 1 17',.45,.26) for k in range(5))
        elif id=='chocolate-snap-field':body=line(pts,.9,.58,True)+line([(px*.78,py*.78) for px,py in pts],.4,.25,True)+path('M-5 -2L5 2L8 -2',.4,.4)
        elif id=='zinc-etch-pits':body=line([(px*.5,py*.4) for px,py in pts],.3,.25,True,'black')+path('M-3 -1l3 -3 4 1',.5,.6)
        elif id=='nickel-nodule-field':body=rounded(shrunk,.8,.65,.6)+rounded([(px*.57,py*.57) for px,py in pts],.8,.35,.23)
        elif id=='soil-aggregate-field':
            body=rounded(shrunk,.12,.75,.65,fill='none')
            for _ in range(5):body+=ellipse(rng.uniform(-8,8),rng.uniform(-8,8),rng.uniform(.4,2),width=0,alpha=.35,fill='black')
        elif id=='quartz-sorted-grains':body=rounded(shrunk,.2,.45,.6)+path('M-3 1L1 -4L4 -2',.35,.3)
        elif id=='river-cobble-mosaic':body=rounded(shrunk,.65,1,.62)+rounded([(px*.72,py*.72) for px,py in pts],.65,.4,.2)
        elif id=='pebbled-leather-large':body=rounded(shrunk,.6,.75,.55)+path('M-4 -2l3 -2m2 0l3 2',.4,.3)
        elif id=='acrylic-crazing':body=line(pts,.5,.6,True)+path('M0 0L5 -6L7 -12 M5 -6L13 -4',.3,.38)
        elif id=='polyethylene-film-creases':body=line(pts,.65,.65,True)+''.join(line([(0,0),p],.35,.22) for p in pts)
        elif id=='lichen-islands-field':
            scallop=[]
            for k in range(36):
                t=k*TAU/36;r=(16+3*math.sin(t*7)+2*math.sin(t*3))
                scallop.append((r*math.cos(t),r*.8*math.sin(t)))
            body=rounded(scallop,.1,.7,.5)+''.join(ellipse(px,py,2.7,width=.5,alpha=.5) for px,py in [(-6,-3),(5,-7),(3,6)])
        elif id=='pressed-powder-relief':body=line(shrunk,.7,.48,True)+line([(px*.7,py*.7) for px,py in pts],.4,.3,True)+ellipse(0,0,.7,width=0,alpha=.3,fill='black')
        margin=max(max(abs(px),abs(py)) for px,py in pts)+4
        out.append(wrapped(body,x,y,max(21,margin)))
    return ''.join(out)

def angular_scatter(id,rng):
    count={'honey-crystal-field':140,'recycled-plastic-flakes':95,'volcanic-ash-field':210,'permanganate-facet-field':115,'cosmetic-mica-platelets':120}[id]
    out=[]
    for _ in range(count):
        x,y=rng.random()*256,rng.random()*256
        rx=rng.uniform(2,9);ry=rx*rng.uniform(.5,1.8)
        if id=='permanganate-facet-field':rx=rng.uniform(2,4);ry=rng.uniform(7,17)
        if id=='cosmetic-mica-platelets':ry*=.4
        pts=[(math.cos(t)*rx*rng.uniform(.75,1.1),math.sin(t)*ry*rng.uniform(.75,1.1)) for t in [k*TAU/6 for k in range(6)]]
        body=line(pts,.45,.45,True,fill='black' if id in {'recycled-plastic-flakes','volcanic-ash-field'} else 'none')
        if id in {'permanganate-facet-field','honey-crystal-field'}:body+=path(f'M{-rx:.2f} 0L0 {-ry*.65:.2f}L{rx:.2f} 0L0 {ry*.65:.2f}Z',.4,.35)
        if id=='cosmetic-mica-platelets':body+=path(f'M{-rx*.7:.2f} -1H{rx*.7:.2f} M{-rx*.5:.2f} 1H{rx*.5:.2f}',.3,.4)
        out.append(wrapped(f'<g transform="rotate({rng.uniform(0,180):.2f})">{body}</g>',x,y,30))
    return ''.join(out)

def web_field(id,rng):
    side=7 if id=='cobweb-fine-sheet' else 5;step=256/side
    nodes={(i,j):((i+.5)*step+rng.uniform(-step*.2,step*.2),(j+.5)*step+rng.uniform(-step*.18,step*.18)) for j in range(side) for i in range(side)}
    def node(i,j):
        x,y=nodes[i%side,j%side];return x+(i//side)*256,y+(j//side)*256
    out=[]
    for j in range(-1,side+1):
        for i in range(-1,side+1):
            x,y=node(i,j);xx,yy=node(i+1,j);vx,vy=node(i,j+1)
            sag=step*(.15 if id=='cobweb-fine-sheet' else .5)
            out.append(path(f'M{x:.2f} {y:.2f}Q{(x+xx)/2:.2f} {(y+yy)/2+sag:.2f} {xx:.2f} {yy:.2f}',.42,.55))
            out.append(path(f'M{x:.2f} {y:.2f}Q{(x+vx)/2+3:.2f} {(y+vy)/2:.2f} {vx:.2f} {vy:.2f}',.32,.4))
            if id=='cobweb-fine-sheet' and (i+j)%2==0:out.append(line([(xx,yy),(vx,vy)],.28,.28))
    return ''.join(out)

def draw(id):
    rng=random.Random(int.from_bytes(hashlib.sha256(id.encode()).digest()[:8],'big'))
    cellular_ids={'watermelon-cell-field','beef-fat-veins','chocolate-snap-field','zinc-etch-pits','nickel-nodule-field','soil-aggregate-field','quartz-sorted-grains','river-cobble-mosaic','pebbled-leather-large','acrylic-crazing','polyethylene-film-creases','lichen-islands-field','pressed-powder-relief'}
    if id in cellular_ids:return cellular(id,rng)
    if id in {'honey-crystal-field','recycled-plastic-flakes','volcanic-ash-field','permanganate-facet-field','cosmetic-mica-platelets'}:return angular_scatter(id,rng)
    if id in {'cobweb-fine-sheet','cobweb-draped-field'}:return web_field(id,rng)
    out=[]
    if id=='grill-sear-field':
        for j in range(-6,13):
            y=j*32;out.append(path(f'M-256 {y-256}L512 {y+512}',6,.42))
            out.append(path(f'M-256 {y+256}L512 {y-512}',2,.3))
        out.append(wave_lines(40,2,3,.32))
    elif id in {'mango-fibre-pulp','coconut-lamellae-field','woods-eutectic-field','vinyl-calandering','saddle-creased-leather','silt-lamination','waterjet-striation-field'}:
        args={'mango-fibre-pulp':(48,3,2,.45),'coconut-lamellae-field':(26,1.5,3,.5),'woods-eutectic-field':(38,9,4,.8),'vinyl-calandering':(40,1,2,.35),'saddle-creased-leather':(8,12,1,.8),'silt-lamination':(45,1.8,4,.45),'waterjet-striation-field':(47,8,1,.6)}[id]
        out.append(wave_lines(*args))
        if id in {'mango-fibre-pulp','woods-eutectic-field','waterjet-striation-field'}:out=['<g transform="rotate(90 128 128)">'+''.join(out)+'</g>']
        if id=='coconut-lamellae-field':
            for j in range(8):
                for i in range(8):out.append(path(f'M{i*32+5} {j*32+8}v5',.5,.3))
        elif id=='woods-eutectic-field':
            for j in range(8):out.append(path(f'M0 {j*32}Q128 {j*32+18} 256 {j*32}',1.6,.28))
        elif id in {'vinyl-calandering','saddle-creased-leather'}:out.append(grain(rng,130,.8))
        elif id=='silt-lamination':
            for _ in range(45):out.append(wrapped(ellipse(0,0,rng.uniform(2,8),.55,width=0,alpha=.25,fill='black'),rng.random()*256,rng.random()*256,10))
    elif id=='latte-microfoam-field':
        dots=[]
        for y in range(64):
            for x in range(64):
                if (x*17+y*23)%7==0:dots.append(f'M{x*4+1.45:g} {y*4+2}a.55 .55 0 1 0 1.1 0a.55 .55 0 1 0-1.1 0Z')
        out.append(path(''.join(dots),.22,.28))
    elif id=='vanadium-polish-field':
        fragment=''.join(path(f'M-14 {j*3}H14',.45,.35) for j in range(-3,4));out.append(f'<defs><g id="polish">{fragment}</g></defs>')
        for y in range(8):
            for x in range(8):
                angle=rng.uniform(-75,75)
                out.append(wrapped(f'<use href="#polish" transform="rotate({angle:.2f})"/>',x*32+16,y*32+16,23))
    elif id=='shot-peened-steel-field':
        for _ in range(150):
            r=rng.uniform(3,9);body=ellipse(0,0,r,width=.6,alpha=.4)+path(f'M{-r*.8:.2f} {-r*.3:.2f}Q0 {-r*1.1:.2f} {r*.8:.2f} {-r*.3:.2f}',.4,.3)
            out.append(wrapped(body,rng.random()*256,rng.random()*256,13))
    elif id=='metal-powder-sinter-field':
        for y in range(-1,10):
            for x in range(-1,10):
                cx=x*32+(y%2)*16;cy=y*32;out.append(ellipse(cx,cy,8+((x%8)*7+(y%8)*11)%4,width=.7,alpha=.55))
                out.append(path(f'M{cx+9} {cy}h14 M{cx+5} {cy+9}l7 14',3,.22))
    elif id=='polycarbonate-twinwall':
        for x in range(-1,9):
            xx=x*32;out.append(path(f'M{xx} 0V256 M{xx+4} 0V256 M{xx+28} 0V256',.7,.55))
            for y in range(0,256,32):out.append(path(f'M{xx+4} {y}h24',.45,.3))
    elif id=='injection-gate-flow':
        for y in range(4):
            for x in range(4):
                fragment=''.join(path(f'M{-r} 0Q0 {-r*1.8:.1f} {r} 0',.55,.48) for r in range(6,40,5))
                out.append(wrapped(f'<g transform="rotate({90*((x+y)%4)})">{fragment}</g>',x*64+32,y*64+32,45))
    elif id=='silicone-grip-microdots':
        for y in range(-1,17):
            for x in range(-1,17):
                cx=x*16+(y%2)*8;cy=y*16;out.append(ellipse(cx,cy,4,2.5,width=1,alpha=.48)+path(f'M{cx-3} {cy+5}h6',.4,.25))
    elif id=='loam-root-section':
        out.append(grain(rng,150,2.5))
        for x in range(8):
            xx=x*32;out.append(path(f'M{xx} 0C{xx+17} 75 {xx-17} 181 {xx} 256',1.4,.48))
            for y in range(4):out.append(path(f'M{xx} {y*64+15}q-18 18 -21 40 M{xx+4} {y*64+32}q18 7 23 25',.6,.4))
    elif id=='saffiano-crosshatch':
        for y in range(-1,17):
            for x in range(-1,17):
                xx=x*16;yy=y*16;out.append(path(f'M{xx} {yy}l13 13 M{xx+3} {yy}l13 13 M{xx} {yy+13}l13 -13',.8,.48))
    elif id=='stitched-leather-panels':
        for y in range(-1,5):
            yy=y*64;offset=(y%2)*64;out.append(path(f'M0 {yy}H256',1,.6))
            for x in range(-1,3):out.append(path(f'M{x*128+offset} {yy}v64',1,.6))
            for x in range(-1,33):out.append(path(f'M{x*8} {yy+4}h4 M{x*8} {yy-4}h4',.65,.5))
            for x in range(-1,3):
                for k in range(7):out.append(path(f'M{x*128+offset+4} {yy+k*8+6}v4 M{x*128+offset-4} {yy+k*8+6}v4',.65,.5))
    elif id=='perforated-upholstery-leather':
        out.append(grain(rng,220,.8))
        for y in range(-1,17):
            for x in range(-1,17):out.append(ellipse(x*16+(y%2)*8,y*16,1.9,width=1,alpha=.7))
    elif id=='tooled-leather-scrollwork':
        for y in range(-1,5):
            for x in range(-1,5):
                xx=x*64;yy=y*64;fragment=path('M0 64C35 38 -12 22 16 6C45 -10 65 24 39 32C17 39 30 13 38 21',1,.55)+path('M23 46q-25 -17 -18 -26q20 -2 18 26 M41 36q28 -6 19 -21q-21 -5 -19 21',.75,.4)
                out.append(f'<g transform="translate({xx} {yy})">{fragment}</g>')
    elif id=='dendritic-solidification':
        for x in range(-1,9):
            xx=x*32;out.append(path(f'M{xx} 0l64 256',.9,.55))
            for y in range(-2,18):
                yy=y*16;xx2=xx+yy/4;out.append(path(f'M{xx2} {yy}l-12 -16 M{xx2} {yy}l10 -14',.55,.4))
    elif id in {'dandelion-pappus-field','moss-cushion-field','fern-sporangia-field','terry-loop-pile'}:
        count=100 if id=='moss-cushion-field' else 36 if id=='dandelion-pappus-field' else 25 if id=='fern-sporangia-field' else 169
        side=round(math.sqrt(count));step=256/side
        for k in range(count):
            x=((k%side)+.5+rng.uniform(-.22,.22))*step;y=((k//side)+.5+rng.uniform(-.22,.22))*step;body=''
            if id=='dandelion-pappus-field':
                body=path('M0 0L2 27',.45,.4)+''.join(line([(0,0),(math.cos(t)*16,math.sin(t)*9-13)],.3,.4) for t in [j*TAU/12 for j in range(12)])
            elif id=='moss-cushion-field':body=path('M0 15V-13 M0 -10L-6 -14 M0 -5L7 -10 M0 2L-8 -4 M0 9L7 2',.65,.55)+path('M-6 13L-11 -3 M6 13L12 -1',.4,.35)
            elif id=='fern-sporangia-field':
                body=path('M0 -28V28 M0 -12L-18 -23 M0 0L18 -10 M0 12L-18 4 M0 24L17 14',.6,.4)
                body+=''.join(ellipse(px,py,1.4,width=.4,alpha=.6) for px,py in [(-6,-17),(-12,-21),(6,-5),(12,-9),(-6,8),(-12,4),(6,20),(12,16)])
            else:body=path('M-4 7C-16 -12 13 -17 7 1S-8 13 -4 7',.8,.5)
            out.append(wrapped(f'<g transform="rotate({rng.uniform(0,360):.1f})">{body}</g>',x,y,40))
    elif id=='corduroy-nap-ribs':
        hairs=[]
        for x in range(-1,17):
            xx=x*16;out.append(path(f'M{xx+2} 0V256 M{xx+5} 0V256 M{xx+12} 0V256',1.5,.35))
            for y in range(0,256,4):hairs.append(f'M{xx+5} {y}l5 2M{xx+6} {y+2}l4-1')
        out.append(path(''.join(hairs),.45,.45))
    elif id=='rib-knit-columns':
        for y in range(-1,17):
            for x in range(-1,17):
                xx=x*16;yy=y*16;out.append(path(f'M{xx} {yy}q-8 -18 -4 -18q8 0 4 18q8 -18 4 -18q-8 0 -4 18',1,.5))
    elif id=='woven-wire-cloth':
        for y in range(-1,17):
            for x in range(-1,17):
                xx=x*16;yy=y*16;out.append(path(f'M{xx} {yy}h16 M{xx} {yy}v16',1.8,.3))
                if (x+y)%2:out.append(path(f'M{xx-3} {yy}h6',2.8,.6))
                else:out.append(path(f'M{xx} {yy-3}v6',2.8,.6))
    elif id=='laser-crosshatch-field':
        body=''.join(path(f'M-14 {j*4}H14',.5,.48) for j in range(-3,4));out.append(f'<defs><g id="laser">{body}</g></defs>')
        for y in range(8):
            for x in range(8):
                out.append(f'<use href="#laser" transform="translate({x*32+16} {y*32+16}) rotate({90*((x+y)%2)})"/>')
    elif id=='stamped-rosette-dimples':
        for y in range(-1,9):
            for x in range(-1,9):
                xx=x*32;yy=y*32;body=ellipse(0,0,9,width=.55,alpha=.4)
                body+=''.join(ellipse(math.cos(t)*6,math.sin(t)*6,2.2,width=.45,alpha=.55) for t in [j*TAU/6 for j in range(6)])
                out.append(f'<g transform="translate({xx} {yy})">{body}</g>')
    elif id=='milled-pocket-array':
        for y in range(-1,9):
            for x in range(-1,5):
                xx=x*64;yy=y*32
                for inset in (0,3,6):out.append(f'<rect x="{xx+3+inset}" y="{yy+3+inset}" width="{58-inset*2}" height="{26-inset*2}" rx="{max(1,7-inset)}" fill="none" stroke="black" stroke-width=".6" opacity=".5"/>')
    elif id in {'braided-data-streams','merge-branch-lanes'}:
        for j in range(-1,9):
            for k in range(3):
                if id=='braided-data-streams':points=[(x,j*32+k*3+10*math.sin(x*TAU/128+(j%2)*math.pi)) for x in range(0,257,4)]
                else:points=[(x,j*32+k*4*math.cos(x*TAU/128)) for x in range(0,257,4)]
                out.append(line(points,.6,.5))
    elif id=='node-weight-matrix':
        for y in range(-1,17):
            for x in range(-1,17):
                xx=x*16;yy=y*16;r=.7+2*(.5+.5*math.sin(x*TAU/16)*math.cos(y*TAU/16))
                out.append(path(f'M{xx} {yy}h16',.3,.22)+ellipse(xx,yy,r,width=0,alpha=.55,fill='black'))
    elif id=='adaptive-cell-map':
        for y in range(4):
            for x in range(4):
                splits=1+(x+2*y)%4;step=64/splits
                for j in range(splits):
                    for i in range(splits):out.append(f'<rect x="{x*64+i*step:.2f}" y="{y*64+j*step:.2f}" width="{step:.2f}" height="{step:.2f}" fill="none" stroke="black" stroke-width=".55" opacity=".55"/>')
    elif id=='variable-density-bars':
        for y in range(8):
            for x in range(32):
                h=5+(x*7+y*11)%17;out.append(path(f'M{x*8+3} {y*32+24}v{-h}',1+(x+y)%3,.5))
    elif id=='geodesic-connection-field':
        for y in range(-1,5):
            for x in range(-1,5):
                xx=x*64;yy=y*64;out.append(path(f'M{xx} {yy+32}Q{xx+32} {yy-32} {xx+64} {yy+32} M{xx+32} {yy}Q{xx-32} {yy+32} {xx+32} {yy+64}',.55,.5)+ellipse(xx+32,yy,1.5,width=.5,alpha=.6))
    elif id=='quantized-isoline-map':
        for y in range(4):
            for x in range(4):
                fragment=''.join(path(f'M{-s} {-s}H{s//2}V{-s//2}H{s}V{s}H{-s//2}V{s//2}H{-s}Z',.55,.5) for s in (8,15,23,31))
                out.append(wrapped(f'<g transform="rotate({90*((x+y)%4)})">{fragment}</g>',x*64+32,y*64+32,40))
    elif id=='hydraulic-channel-field':
        for y in range(-1,9):
            yy=y*32;out.append(path(f'M0 {yy}H256',3,.28))
            for x in range(-1,5):
                xx=x*64+(y%2)*32;out.append(ellipse(xx,yy,6,width=2,alpha=.5)+path(f'M{xx+32} {yy}v32',1.4,.45))
    elif id=='microfluidic-labyrinth':
        for y in range(-1,5):
            yy=y*64;out.append(path(f'M0 {yy+8}H24V{yy+48}H48V{yy+8}H88V{yy+48}H112V{yy+8}H152V{yy+48}H176V{yy+8}H216V{yy+48}H240V{yy+8}H256',2.4,.35))
            for x in (8,136):out.append(ellipse(x,yy+8,4,width=1,alpha=.5))
    elif id=='section-hatching-cells':
        hatch=path('M-4 4L4-4M0 8L8 0M4 12L12 4',.55,.45)
        out.append(f'<defs><pattern id="hatch" width="8" height="8" patternUnits="userSpaceOnUse">{hatch}</pattern></defs>')
        for y in range(4):
            for x in range(4):
                xx=x*64;yy=y*64
                out.append(f'<rect x="{xx+5}" y="{yy+5}" width="54" height="54" fill="url(#hatch)" transform="rotate({90*((x+y)%2)} {xx+32} {yy+32})"/>'+path(f'M{xx+5} {yy+5}h54v54h-54Z',.8,.6))
    elif id=='assembly-exploded-rhythm':
        for y in range(4):
            for x in range(4):
                fragment=''.join(path(f'M-24 {yy}l24 -8 24 8 -24 8Z',.65,.5) for yy in (-17,0,17))+path('M0 -25V25 M-24 -17V17 M24 -17V17',.4,.28)
                out.append(wrapped(fragment,x*64+32,y*64+32,40))
    elif id=='mechanical-linkage-field':
        for y in range(-1,9):
            for x in range(-1,9):
                xx=x*32;yy=y*32;out.append(ellipse(xx,yy,4,width=.65,alpha=.6)+ellipse(xx,yy,1.5,width=.4,alpha=.5)+path(f'M{xx+4} {yy-1}h24m-24 2h24 M{xx-1} {yy+4}v24m2 -24v24',.65,.4))
    elif id=='optical-path-matrix':
        for y in range(-1,9):
            for x in range(-1,5):
                xx=x*64;yy=y*32;out.append(path(f'M{xx} {yy}h64 M{xx+32} {yy-10}Q{xx+41} {yy} {xx+32} {yy+10}Q{xx+23} {yy} {xx+32} {yy-10}',.55,.5)+path(f'M{xx+58} {yy-6}l12 12 M{xx+64} {yy}v32',.65,.4))
    elif id=='truchet-double-arc-field':
        for y in range(8):
            for x in range(8):
                body=path('M0 12A12 12 0 0 0 12 0 M0 20A20 20 0 0 0 20 0 M12 32A20 20 0 0 1 32 12 M20 32A12 12 0 0 1 32 20',.8,.55)
                out.append(f'<g transform="translate({x*32} {y*32}) rotate({90*((x*11+y*7)%2)} 16 16)">{body}</g>')
    elif id=='chevron-channel-grid':
        for j in range(-4,13):
            yy=j*32;points=[(k*16,yy+(k%2)*16) for k in range(17)];out.append(line(points,.8,.6))
            for k in range(16):out.append(path(f'M{k*16+8} {yy+8}v16',.45,.3))
    elif id=='triangular-stipple-tiles':
        dots=[]
        for y in range(32):
            for x in range(32):
                lx=x%8;ly=y%8;dense=(lx>ly)==((x//8+y//8)%2==0)
                if dense or (x+y)%3==0:dots.append(f'M{x*8+1.5:g} {y*8+2}a.5 .5 0 1 0 1 0a.5 .5 0 1 0-1 0Z')
        out.append(path(''.join(dots),0,.45,'black'))
    elif id=='superellipse-interlock':
        pts=[]
        for k in range(48):
            t=k*TAU/48;cs=math.cos(t);sn=math.sin(t);pts.append((math.copysign(abs(cs)**.42,cs)*28,math.copysign(abs(sn)**.42,sn)*28))
        body=line(pts,.75,.55,True)+path('M-28 0H-36 M28 0H36 M0 -28V-36 M0 28V36',.7,.45)
        out.append(f'<defs><g id="superellipse">{body}</g></defs>')
        for y in range(-1,5):
            for x in range(-1,5):
                out.append(f'<use href="#superellipse" x="{x*64+32}" y="{y*64+32}"/>')
    else:raise KeyError('No geometry for '+id)
    return ''.join(out)

CSS={
 'polymer-flow-lines':'background-image:repeating-radial-gradient(ellipse 120% 45% at 20% 40%,transparent 0 12%,$INK 13%,transparent 17% 23%,$HIGHLIGHT 24%,transparent 27% 34%),linear-gradient(120deg,$SECONDARY,transparent 65%);',
 'permanganate-diffusion':'background-image:radial-gradient(ellipse at 10% 20%,$INK,transparent 55%),radial-gradient(ellipse at 80% 15%,$ACCENT,transparent 60%),radial-gradient(ellipse at 35% 90%,$SECONDARY,transparent 60%),radial-gradient(ellipse at 95% 80%,$INK,transparent 55%);',
 'chromatographic-bands':'background-image:linear-gradient(0deg,transparent 0 3%,$INK 7%,transparent 14% 20%,$SECONDARY 23% 30%,transparent 38% 45%,$ACCENT 49% 55%,transparent 63% 70%,$HIGHLIGHT 77%,transparent 87%,$INK 95%);',
 'matte-enamel-speckle':'background-image:radial-gradient(circle at 25% 25%,$INK .5px,transparent 1px),radial-gradient(circle at 75% 75%,$HIGHLIGHT .6px,transparent 1.2px);background-size:calc(var(--rb-scale,64px)/16) calc(var(--rb-scale,64px)/16);',
 'soft-touch-surface':'background-image:repeating-linear-gradient(90deg,transparent 0 1.8%,$INK 1.8% 2%,transparent 2% 4%),linear-gradient(90deg,transparent 0 15%,$SECONDARY 50%,transparent 85% 100%);background-size:var(--rb-scale,128px) var(--rb-scale,128px);',
 'frosted-acrylic-ridges':'background-image:repeating-linear-gradient(90deg,transparent 0 4%,$HIGHLIGHT 4.3%,$INK 4.7%,transparent 5.5% 6.25%),repeating-linear-gradient(0deg,transparent 0 12%,$SECONDARY 12% 12.5%);background-size:var(--rb-scale,128px) var(--rb-scale,128px);',
 'milky-polymer-surface':'background-image:radial-gradient(ellipse at 15% 10%,$HIGHLIGHT,transparent 70%),radial-gradient(ellipse at 85% 70%,$INK,transparent 60%),radial-gradient(ellipse at 10% 85%,$SECONDARY,transparent 65%),linear-gradient(130deg,transparent,$ACCENT,transparent);',
 'gloss-laminate-folds':'background-image:linear-gradient(90deg,transparent 0 15%,$INK 17%,transparent 23% 29%,$HIGHLIGHT 30% 31%,transparent 34% 52%,$SECONDARY 55%,transparent 62% 77%,$HIGHLIGHT 78%,transparent 82% 100%);background-size:var(--rb-scale,256px) var(--rb-scale,256px);',
 'fresnel-ring-field':'background-image:repeating-radial-gradient(circle at 50% 50%,transparent 0 8px,$HIGHLIGHT 8px 8.7px,transparent 9px 16px,$INK 16px 17px);background-size:var(--rb-scale,128px) var(--rb-scale,128px);',
 'window-caustic-grid':'background-image:repeating-linear-gradient(80deg,transparent 0 12%,$HIGHLIGHT 13% 15%,transparent 17% 28%,$INK 30%,transparent 34% 40%),repeating-linear-gradient(10deg,transparent 0 23%,$SECONDARY 25%,$HIGHLIGHT 27%,transparent 31% 45%);',
 'stripbox-reflection-field':'background-image:linear-gradient(90deg,$INK,transparent 8% 15%,$HIGHLIGHT 17% 21%,transparent 24% 45%,$SECONDARY 48%,transparent 53% 67%,$HIGHLIGHT 69% 71%,transparent 75%,$INK 97%),linear-gradient(0deg,transparent,$ACCENT,transparent);',
 'crossed-light-gratings':'background-image:repeating-linear-gradient(35deg,transparent 0 13px,$HIGHLIGHT 13px 13.6px,transparent 14px 28px),repeating-linear-gradient(145deg,transparent 0 19px,$INK 19px 19.8px,transparent 20px 40px);',
}
REPEATING_CSS={'matte-enamel-speckle','soft-touch-surface','frosted-acrylic-ridges','gloss-laminate-folds','fresnel-ring-field'}

def vectors(svg):
    for r in rows():
        if r['id'] not in CSS:svg(r['id'],compact(draw(r['id'])))

def compact(body):
    """Reuse static presentation styles; no filters, scripts or runtime dependencies."""
    styles={}
    def name(fill,width,alpha):
        key=(fill,round(float(width),2),round(float(alpha),2))
        if key not in styles:styles[key]='s'+str(len(styles))
        return styles[key]
    body=re.sub(r'<path d="([^"]*)" fill="([^"]*)" stroke="black" stroke-width="([^"]*)" opacity="([^"]*)" stroke-linecap="round" stroke-linejoin="round"/>',lambda m:f'<path class="{name(m[2],m[3],m[4])}" d="{m[1]}"/>',body)
    body=re.sub(r'<ellipse (cx="[^"]*" cy="[^"]*" rx="[^"]*" ry="[^"]*") stroke="black" stroke-width="([^"]*)" opacity="([^"]*)" fill="([^"]*)"/>',lambda m:f'<ellipse class="{name(m[4],m[2],m[3])}" {m[1]}/>',body)
    css='path,ellipse{fill:none;stroke:#000}path{stroke-linecap:round;stroke-linejoin:round}'+''.join('.'+n+'{fill:'+f+';stroke-width:'+str(w)+';opacity:'+str(a)+'}' for (f,w,a),n in styles.items())
    return '<style>'+css+'</style>'+re.sub(r'(-?\d+)\.00\b',r'\1',body)

def catalog(item):
    out=[]
    for r in rows():
        id=r['id'];css=id in CSS;tech='CSS' if css else 'SVG';placement='repeat' if not css or id in REPEATING_CSS else 'cover'
        c=item(id,r['name'],r['family'],tech,placement,None if css else id+'.svg',r['description'],r['niches'],r['rationale'],r['avoid'],[], '#f2ece0','#74816d','#a36a47',.22 if not css else .36,256)
        c.update(era='Вне эпохи',style='Материальная графика' if r['group'] not in {'data','scheme','geometry','light'} else 'Абстрактная графика',coverage='field',keywords=[r['group'],r['name']],ink_role='secondary' if r['group'] in {'leather','food','earth','weave','nature'} else 'primary',fidelity='Собственная кодовая стилизация; не микрофотография, измерение или физическая симуляция.',alpha_note='Прозрачные промежутки декоративного слоя; базовый цвет задаётся отдельно.',concept_group=id,release_added='1.1.0')
        if css:c['css_body']=CSS[id]
        if id.startswith('cobweb-'):c['keywords']+=['паутина','паутинка','spider web','cobweb','svg']
        if id.startswith('permanganate-'):c['keywords']+=['марганцовка','kmn04','kmno4','перманганат']
        if id.startswith('zinc-'):c['keywords']+=['цинк','zn','zinc']
        if id.startswith('woods-'):c['keywords']+=['сплав вуда','wood alloy','woods metal']
        out.append(c)
    for r in photos():
        c=item(r['id'],r['name'],r['family'],'WebP','cover',r['id']+'.webp',r['description']+' Сгенерированная композиция на всю площадь, варианты 1440/800 px.',r['niches'],'Материал крупным планом для визуальной истории бренда и состава продукта.','Не выдавать за фото реального товара, блюда или образца. Не повторять плиткой; исходные цвета материала не заменяются токенами сайта.',[], '#f2ece0','#74816d','#a36a47',.8)
        c.update(era='Вне эпохи',style='Реалистичный материал',coverage='field',keywords=r['keywords'],fidelity='Сгенерированная художественная поверхность, не документальная фотография или научная микроскопия.',alpha_note='Непрозрачный WebP; интенсивность управляет смешением с базовым фоном.',concept_group=r['id'],release_added='1.1.0')
        out.append(c)
    return out
