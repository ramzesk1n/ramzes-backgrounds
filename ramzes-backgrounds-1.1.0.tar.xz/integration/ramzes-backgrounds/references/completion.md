# Материалы и структуры коллекции 500

Для реалистичной еды выбирать готовые cover-изображения: grilled-meat-photo, marbled-beef-photo, seedless-watermelon-photo, mango-flesh-photo, coconut-flesh-photo, latte-uniform-photo, crystallized-honey-photo. Для уже имевшегося жидкого мёда — honey-fluid-photo. Не подменять мякоть изображением кожуры или волокон скорлупы. Кодовые варианты в той же теме являются условными фактурами.

Для кожгалантереи сравнить full-grain-leather-photo, suede-nap-photo и saffiano-leather-photo; для перекрашиваемого фона — saffiano-crosshatch, stitched-leather-panels или pebbled-leather-large. Для песка, гальки и грунта — sand-grains-photo, river-pebbles-photo и garden-soil-photo, либо кодовые варианты семейства «Песок, грунт и галька».

Для Zn использовать zinc-etched-photo/zinc-etch-pits или прежний zinc-spangle. Для ванадия — vanadium-metal-photo/vanadium-polish-field, для сплава Вуда — woods-alloy-photo/woods-eutectic-field. Это собственная материальная стилизация, не проверенная металлография; не делать выводы о составе и свойствах.

Для пластика выбирать matte-plastic-photo, translucent-resin-photo, polymer-flow-lines или семейство «Пластики и эластомеры». Для разреза доски — endgrain-board-photo; прежний endgrain-ring-field остаётся лёгкой условной альтернативой.

Для «kmn04»/«KMnO4»/«марганцовка» использовать правильное обозначение KMnO₄: permanganate-crystals-photo, permanganate-facet-field или permanganate-diffusion. Полноцветные кристаллы сохраняют цвет; CSS-облака и SVG-грани следуют токенам сайта и не моделируют реакцию.

Для тонкой перекрашиваемой паутинки на всю площадь — cobweb-fine-sheet или cobweb-draped-field. Они являются repeat/field. Не добавлять паука, одиночную радиальную розетку или JS. Сравнить 3×3 и 5×5 при реальном масштабе.

Новые нишевые маршруты: steakhouses, leather-goods, soil-materials, polymers, laboratory-reagents, milk-coffee, tropical-flesh, foundry-alloys. Данные и схемы считать декоративными, без реальных показателей или инженерной достоверности.
