# Поля, материалы и стили

## Выбирать композицию

coverage=field означает распределение рисунка по всей площади. Это может быть связная фактура или поле повторяемых иллюстративных мотивов. coverage=accent означает локальный объект или край. placement=repeat/cover/overlay описывает способ размещения и не заменяет coverage.

Начать с list --coverage field. У foundation-swipe, lipstick-strokes, brush-paint, graffiti-drips, paint-splatter, spray-plume, silver-tarnish, steam-ribbons, botanical-shadows, contour-leaves, root-mycelium, ice-fractures сплошная фактура — основной вариант. Исходный локальный акцент доступен через --composition accent. Не запрашивать такую композицию у карточки без accent_variant.

Для фоновой поверхности с мазками экспортировать обычный brush-paint или gouache-overlap-field. Для точного реализма использовать соответствующий WebP, если его пиксели подходят палитре. Масштаб и интенсивность не превращают один акцент в заполняющую фактуру.

## Искать по задаче

- Нефть и масла: viscosity-streams, oil-slick-spectrum, crude-oil-photo, amber-oil-photo. Газ: gas-pressure-bands, gas-flame-field, gas-condensate-photo; последние изображения — стилизация, не универсальная окраска природного газа.
- Фрукты: orange-peel-photo, citrus-slices-photo, fruit-mosaic-photo; контурные варианты citrus-segment-field, fruit-cutout-field, kiwi-seed-rings.
- Волокна: rope-twist-field, hemp-tow-lines, jute-mesh, rope-fiber-photo, hemp-tow-photo; сетки: spider-silk-mesh, radial-web-field, spider-silk-photo.
- Снег: snowflake-field, snow-needle-field, snow-crystals-photo; зимняя подборка guide winter-projects.
- Вино: guide winery; игристые и события: guide champagne-events. Шампанское — champagne-effervescence, champagne-foam-raft, champagne-photo; вино — wine-lacing-field, wine-tannin-ring-field, red-wine-photo, rose-wine-photo. Для живого цвета брать SVG/CSS, для реализма — WebP.
- Эпохи: list --style Ретро --era 1950. Другие фильтры: 1890, 1920, 1940, 1960, 1970, 1980, 1990, 2000. Это стилизационные ориентиры, не датировки исторических произведений.
- Иллюстрация, Комиксы, Кинематографичное, Футуристичное — значения --style. Все новые поля статичны. Муар, ЭЛТ, VHS и кино не означают анимацию или реальную обработку изображения.

Использовать list/guide и show, чтобы проверить актуальные описания, роли, alpha_note, fidelity и вес. Не читать все 500 карточек в контекст. Предпочитать существующий подходящий материал новой генерации.

## Внедрять с палитрой

Экспортировать с --tokens из дизайн-системы. SVG-маски перекрашивать через --rb-ink, а не currentColor внешнего img. Прозрачные участки SVG показывают фон секции. PNG/WebP с полной поверхностью обычно непрозрачны; уменьшение общей opacity не делает настоящий вырезанный прозрачный материал.

Для repeat проверить 3×3/5×5 и муар. Реалистичные cover не размножать. Если ::before/::after заняты, использовать отдельный aria-hidden декоративный слой с адаптацией селекторов. Не менять существующий псевдоэлемент контента ради подложки.
