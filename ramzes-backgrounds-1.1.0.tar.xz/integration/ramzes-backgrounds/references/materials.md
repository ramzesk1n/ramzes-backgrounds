# Beauty, краски, металлы, жидкости

Курируемые guides: nail-studio, makeup-artists, skincare, decorative-paint, metal-finishes, smoothies, dairy, fluid-lab. Сначала guide, затем show только 2–3 кандидатов. При поиске доступны русские слова, Au/Ag/Cu/Mg/Ti/Zn/Cr и английские имена.

Реалистичные материалы: lacquer-liquid-photo, makeup-skin-photo, cream-swirl-photo, berry-smoothie-photo, green-smoothie-photo, oil-water-suspension-photo, microfoam-photo, spray-paint-photo, liquid-chrome-photo, copper-patina-photo. Все они cover; не размножать и не обещать перекраску пикселей. Измеренный вес смотреть в карточке, выбирать минимально достаточный материал. Экспорт переносит только две WebP-версии, PNG-мастер остаётся в библиотеке.

Кодовые фактуры перекрашиваются через token_roles. При перекраске золота или меди сохраняется геометрия отражений, но не природный тон. Название металла не является анализом состава; поталь не обязательно золото, потемнение Ag не обозначать как оксид. Для натурального цвета выбирать подходящий растр.

Условная кодовая кожа — микрорельеф; makeup-skin-photo — сгенерированный фрагмент взрослой щеки. Не представлять его как реального клиента, результат процедуры или работу визажиста. Сгенерированную еду не выдавать за фотографию товара заказчика.

Для крема есть milk-folds (лёгкая стилизация) и cream-swirl-photo (реализм); для лака — lacquer-pools и lacquer-liquid-photo; для распыления — spray-stipple/spray-plume и spray-paint-photo; для пены — foam-cells и microfoam-photo. Выбор зависит от роли материала и допустимого веса.

Прозрачные foundation-swipe, lipstick-strokes, spray-plume, graffiti-drips, paint-splatter, soap-bubbles, carbonated-stream применять локально. Не повторять overlay/cover. Белые контуры пены/пузырьков проверять на background сайта; при необходимости использовать уже существующую более контрастную роль. Не менять палитру проекта без задачи.
