#!/usr/bin/env python3
"""Portable entrypoint for the bundled background library."""
from pathlib import Path
import runpy, sys
sys.dont_write_bytecode=True

script=Path(__file__).resolve().parents[1]/'assets/library/scripts/backgrounds.py'
sys.path.insert(0,str(script.parent))
runpy.run_path(str(script),run_name='__main__')
