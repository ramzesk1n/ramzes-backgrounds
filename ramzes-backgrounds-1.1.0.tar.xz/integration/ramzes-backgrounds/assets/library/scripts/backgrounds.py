#!/usr/bin/env python3
"""Query and export selected static backgrounds. Python standard library only."""
import argparse, hashlib, json, re, shutil
from pathlib import Path
from theme import DEFAULTS, BINDINGS, read_theme, declarations, example_theme

ROOT=Path(__file__).resolve().parents[1]
NICHE_ALIASES={
    'юрист':'Юристы и B2B','юрид':'Юристы и B2B','адвокат':'Юристы и B2B','банкрот':'Юристы и B2B','legal':'Юристы и B2B',
    'стомат':'Медицина и стоматология','клиник':'Медицина и стоматология','dental':'Медицина и стоматология',
    'кухн':'Кухни и мебель','мебел':'Кухни и мебель','окн':'Клининг и окна','клининг':'Клининг и окна',
    'ремонт':'Строительство и ремонт','потол':'Строительство и ремонт','строит':'Строительство и ремонт',
    'эвакуат':'Авто и логистика','переезд':'Авто и логистика','логист':'Авто и логистика',
    'обуч':'Образование','курс':'Образование','школ':'Образование','education':'Образование',
    'космет':'Beauty и wellness','салон':'Beauty и wellness','wellness':'Beauty и wellness',
    'ювелир':'Ювелирка и fashion','jewelry':'Ювелирка и fashion','кафе':'Рестораны и продукты',
    'ресторан':'Рестораны и продукты','отел':'Туризм и отели','туризм':'Туризм и отели',
    'ландшафт':'Ландшафт и экология','эко':'Ландшафт и экология','saas':'IT и SaaS','it':'IT и SaaS'
}

def load():
    return json.loads((ROOT/'catalog.json').read_text())

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='command',required=True)
    ls=sub.add_parser('list');ls.add_argument('--niche');ls.add_argument('--tech',choices=['CSS','SVG','WebP']);ls.add_argument('--seamless',action='store_true')
    ls.add_argument('--query');ls.add_argument('--family');ls.add_argument('--placement',choices=['repeat','cover','overlay']);ls.add_argument('--kind',choices=['photorealistic','code-stylization'])
    ls.add_argument('--neon',action='store_true',help='Only cards with an optional neon layer')
    ls.add_argument('--coverage',choices=['field','accent'])
    ls.add_argument('--style');ls.add_argument('--era')
    show=sub.add_parser('show');show.add_argument('id')
    ng=sub.add_parser('niches');ng.add_argument('--query')
    guide=sub.add_parser('guide');guide.add_argument('id')
    ex=sub.add_parser('export');ex.add_argument('id');ex.add_argument('--out',type=Path,required=True)
    ex.add_argument('--tokens',type=Path,help='JSON semantic colors and optional CSS variable bindings')
    for name in ['bg','ink','accent']:ex.add_argument('--'+name,type=color)
    ex.add_argument('--intensity',type=opacity);ex.add_argument('--scale',type=positive)
    ex.add_argument('--neon',action='store_true',help='Enable optional static neon layer on supported cards')
    ex.add_argument('--neon-intensity',type=opacity)
    ex.add_argument('--neon-color',type=color,help='Optional fixed halo HEX; omit to inherit accent')
    ex.add_argument('--neon-core',type=color,help='Optional fixed SVG core HEX; omit to inherit highlight')
    ex.add_argument('--neon-color-role',choices=list(DEFAULTS),help='Live semantic role for the halo')
    ex.add_argument('--neon-core-role',choices=list(DEFAULTS),help='Live semantic role for the SVG core')
    ex.add_argument('--composition',choices=['surface','accent'],default='surface',help='Use the full surface or an available original accent variant')
    args=parser.parse_args();data=load()
    guides=data.get('niche_guides',[])
    if args.command=='niches':
        for g in guides:
            if not args.query or args.query.casefold() in ' '.join([g['id'],g['name'],*g['aliases']]).casefold():print(g['id']+' / '+g['name'])
        return
    if args.command=='guide':
        g=next((g for g in guides if g['id']==args.id),None)
        if not g:parser.error('Unknown niche ID; use niches')
        print(json.dumps(g,ensure_ascii=False,indent=2));return
    if args.command=='list':
        query=args.niche.casefold() if args.niche else None
        expanded={target.casefold() for key,target in NICHE_ALIASES.items() if query and key in query}
        recommended={id for g in guides if query and (query==g['id'] or query in g['name'].casefold() or any(a.casefold() in query or query in a.casefold() for a in g['aliases'])) for id in g['recommended']}
        for c in data['cards']:
            if query and c['id'] not in recommended and not any(query in n.casefold() or n.casefold() in expanded for n in c['niches']):continue
            if args.tech and c['tech']!=args.tech:continue
            if args.seamless and not c['seamless']:continue
            if args.family and args.family.casefold() not in c['family'].casefold():continue
            if args.placement and args.placement!=c['placement']:continue
            if args.kind and args.kind!=c['visual_kind']:continue
            if args.neon and not c.get('neon'):continue
            if args.coverage and c.get('coverage')!=args.coverage:continue
            if args.style and args.style.casefold() not in c.get('style','').casefold():continue
            if args.era and args.era.casefold() not in c.get('era','').casefold():continue
            if args.query and args.query.casefold() not in ' '.join([c['id'],c['name'],c['description'],c['family'],*c['niches'],*c.get('keywords',[])]).casefold():continue
            print(f"{c['id']:24} {c['tech']:4} {c['placement']:7} {c['name']} / {'; '.join(c['niches'])}")
        return
    c=next((c for c in data['cards'] if c['id']==args.id),None)
    if c is None:parser.error('Unknown ID; use list')
    if args.command=='show':print(json.dumps(c,ensure_ascii=False,indent=2));return
    if args.composition=='accent':
        if not c.get('accent_variant'):parser.error('No separate accent variant for this card')
        c={**c,**c['accent_variant']}
    try:tokens,bindings=read_theme(args.tokens.expanduser()) if args.tokens else (DEFAULTS.copy(),BINDINGS.copy())
    except (OSError,ValueError) as e:parser.error(str(e))
    neon_settings={key:getattr(args,'neon_'+key) for key in ('intensity','color','core') if getattr(args,'neon_'+key) is not None}
    for slot in ('color','core'):
        role=getattr(args,'neon_'+slot+'_role')
        if role:
            if slot in neon_settings:parser.error('Choose a fixed '+slot+' or its live role, not both')
            neon_settings[slot+'_role']=role
    if neon_settings and not args.neon:parser.error('Use --neon with neon settings')
    if args.neon and not c.get('neon'):parser.error('This card has no neon layer; choose a supported light or bubble effect')
    out=args.out.expanduser().resolve()
    # A new directory keeps exports reviewable and prevents overwriting project code.
    if out.exists() and (not out.is_dir() or any(out.iterdir())):parser.error('Output path must be a new or empty directory')
    if out==ROOT or ROOT in out.parents:parser.error('Export outside the library directory')
    out.mkdir(parents=True,exist_ok=True)
    values=c['defaults'].copy()
    overrides={}
    for key in ['bg','ink','accent','intensity','scale']:
        value=getattr(args,key)
        if value is not None:values[key]=value;overrides[key]=value
    css=c['css']+'\n.rb-surface { '+declarations(c,tokens,bindings,overrides)+' }\n'
    if args.neon:
        neon_declarations=[]
        for key,value in neon_settings.items():
            if key.endswith('_role'):
                neon_declarations.append(f'--rb-neon-{key[:-5]}:var({bindings[value]}, {tokens[value]});')
            else:neon_declarations.append(f'--rb-neon-{key}:{value};')
        css+=c['neon']['css']+'\n.rb-surface {'+''.join(neon_declarations)+'}\n'
    (out/'background.css').write_text(css)
    (out/'theme-example.css').write_text('/* Standalone preview only. On the site use its existing design-system tokens. */\n'+example_theme(tokens,bindings))
    shutil.copy2(ROOT/'LICENSE',out/'LICENSE')
    used=sorted(set(re.findall(r'url\("assets/([^"\)]+)"\)',css)))
    for filename in used:
        (out/'assets').mkdir(exist_ok=True);shutil.copy2(ROOT/'assets'/filename,out/'assets'/filename)
    text='var(--rb-image-text)' if c.get('text_role')=='on-image' else 'var(--rb-text)'
    (out/'example.html').write_text(f'''<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{c['name']}</title><link rel="stylesheet" href="theme-example.css"><link rel="stylesheet" href="background.css"><style>body{{margin:0;font:18px/1.6 system-ui}}.rb-surface{{color:var(--sample-text,{text});min-height:100svh;padding:clamp(24px,8vw,128px)}}h1{{font:400 clamp(36px,6vw,80px)/1.1 Georgia,serif;max-width:15ch}}p{{max-width:55ch}}</style><section class="rb-surface"><p>RAMZES BACKGROUNDS</p><h1>Пространство для главного.</h1><p>Замени текст и проверь читаемость, масштаб и кадрирование.</p></section></html>''')
    hashes={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file()}
    metadata=dict(id=c['id'],version=data['version'],composition=args.composition,coverage=c.get('coverage'),placement=c['placement'],seamless=c['seamless'],parameters=values,tokens=tokens,bindings=bindings,color_mode='live-css-variables',overrides=overrides,neon=dict(enabled=args.neon,settings=neon_settings),origin=c['origin'],files=hashes,client_js_bytes=0,asset_bytes=sum((out/'assets'/f).stat().st_size for f in used))
    (out/'background.lock.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(output=str(out),id=c['id'],files=sum(p.is_file() for p in out.rglob('*')),client_js_bytes=0),ensure_ascii=False))

def color(v):
    if not re.fullmatch(r'#[0-9a-fA-F]{6}',v):raise argparse.ArgumentTypeError('Use a six-digit HEX color, e.g. #eee8dd')
    return v
def opacity(v):
    f=float(v)
    if not 0<=f<=1:raise argparse.ArgumentTypeError('Intensity must be 0..1')
    return f
def positive(v):
    f=float(v)
    if not 4<=f<=4096:raise argparse.ArgumentTypeError('Scale must be 4..4096 px')
    return f

if __name__=='__main__':main()
