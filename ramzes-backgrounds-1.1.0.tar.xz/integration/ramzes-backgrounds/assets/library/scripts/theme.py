"""Semantic colors and live bindings to an existing site's CSS custom properties."""
import json, re

DEFAULTS={
    'primary':'#38534a','secondary':'#75816c','accent':'#a36945',
    'background':'#f2ece0','surface':'#e5e2d8','text':'#243128',
    'muted':'#68745f','border':'#c1c9b8','highlight':'#ffffff','on-image':'#fffaf0'
}
BINDINGS={key:'--'+key for key in DEFAULTS}
ROLES={'bg':'background','ink':'primary','secondary':'secondary','accent':'accent',
       'surface-color':'surface','text':'text','muted':'muted','border':'border',
       'highlight':'highlight','image-text':'on-image'}
ALIASES={'acsent':'accent','bg':'background','foreground':'text','onImage':'on-image'}

def css_color(value):
    if not isinstance(value,str):raise ValueError('Color must be a string')
    if re.fullmatch(r'#[0-9a-fA-F]{3,8}',value) and len(value) in (4,5,7,9):return value
    if re.fullmatch(r'[A-Za-z]+',value):return value
    if re.fullmatch(r'(?:rgb|rgba|hsl|hsla|oklch|oklab|lab|lch|color|color-mix)\([A-Za-z0-9#.,%+\-()/\s]+\)',value):return value
    raise ValueError('Use a CSS color; keep CSS variable references in bindings')

def read_theme(path):
    raw=json.loads(path.read_text())
    if not isinstance(raw,dict):raise ValueError('Theme must be a JSON object')
    values=raw.get('tokens',raw if 'bindings' not in raw else {})
    bindings=raw.get('bindings',{})
    if not isinstance(values,dict) or not isinstance(bindings,dict):raise ValueError('tokens and bindings must be objects')
    tokens=DEFAULTS.copy();bound=BINDINGS.copy()
    for key,value in values.items():
        key=ALIASES.get(key,key)
        if key not in DEFAULTS:raise ValueError('Unknown token: '+key)
        tokens[key]=css_color(value)
    for key,value in bindings.items():
        key=ALIASES.get(key,key)
        if key not in DEFAULTS or not isinstance(value,str) or not re.fullmatch(r'--[A-Za-z_][A-Za-z0-9_-]*',value):
            raise ValueError('Use bindings such as primary: --color-brand-primary')
        bound[key]=value
    if len(set(bound.values()))!=len(bound):raise ValueError('Each semantic token needs a distinct binding')
    return tokens,bound

def declarations(card,tokens,bindings,overrides=None):
    roles=card.get('token_roles',ROLES)
    lines=[f'--rb-{slot}:var({bindings[role]}, {tokens[role]});' for slot,role in roles.items()]
    for key,value in (overrides or {}).items():
        lines.append(f'--rb-{key}:{value}{"px" if key=="scale" else ""};')
    return ''.join(lines)

def example_theme(tokens,bindings):
    return ':root {\n'+''.join(f'  {bindings[key]}: {value};\n' for key,value in tokens.items())+'}\n'
