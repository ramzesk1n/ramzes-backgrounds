# GitHub distribution

Repository: https://github.com/ramzesk1n/ramzes-backgrounds

The public Git checkout contains all runtime assets, all 500 recipes, the English README, the retained Russian documentation, and self-contained skills for Claude Code and Codex. Original PNG masters remain in the separate archival package.

Use `python3 scripts/build_gallery.py` to create the standalone offline HTML catalog from the existing files. This requires only Python 3; it does not regenerate any images or require source PNG files.

Use `python3 scripts/install_skill.py --target claude --user` or the corresponding `--target codex` command to install once for your projects. The installed skill and exported backgrounds work independently of the checkout.

Validation covers all 500 standard exports, 12 accent variants, 16 neon variants, token bindings, asset isolation, checksums, overwrite protection, and gallery JavaScript syntax. See QA.md for the limits of these checks. Local lookup, export and installation timings are in BENCHMARK.md; agent integration estimates are not measured model benchmarks.
