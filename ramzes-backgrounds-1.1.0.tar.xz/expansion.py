"""Original static surface artwork. All generation happens at build time."""
import hashlib
import math
import random
from expansion_data import rows, photos, RASTER_IDS
from surface_fields import draw as connected_field

T=math.tau

def P(d,w=1,a=.7,fill='none'):
    return f'<path d="{d}" fill="{fill}" stroke="black" stroke-width="{w}" opacity="{a}" stroke-linecap="round" stroke-linejoin="round"/>'
def C(x,y,r,a=.7,fill='none',w=1):
    return f'<circle cx="{x:.2f}" cy="{y:.2f}" r="{r:.2f}" opacity="{a}" fill="{fill}" stroke="black" stroke-width="{w}"/>'
def E(x,y,rx,ry,a=.6,fill='none',w=1):
    return f'<ellipse cx="{x:.2f}" cy="{y:.2f}" rx="{rx:.2f}" ry="{ry:.2f}" opacity="{a}" fill="{fill}" stroke="black" stroke-width="{w}"/>'
def poly(points,a=.5,fill='none',w=1):
    return P('M'+'L'.join(f'{x:.2f} {y:.2f}' for x,y in points)+'Z',w,a,fill)
def star(n=5,r=25,inner=11,a=.7):
    return poly([(math.cos(i*T/(2*n))*([r,inner][i%2]),math.sin(i*T/(2*n))*([r,inner][i%2])) for i in range(n*2)],a)
def rays(n=12,r=28,start=8,w=1):
    return ''.join(P(f'M{math.cos(t)*start:.2f} {math.sin(t)*start:.2f}L{math.cos(t)*r:.2f} {math.sin(t)*r:.2f}',w) for t in [i*T/n for i in range(n)])
def rings(n=5,rx=27,ry=23,jitter=0):
    out=[]
    for j in range(1,n+1):
        pts=[((rx*j/n)*(1+jitter*math.sin(t*5+j*.5))*math.cos(t),(ry*j/n)*(1+jitter*math.cos(t*3+j*.4))*math.sin(t)) for t in [k*T/48 for k in range(48)]]
        out.append(poly(pts,.45,w=.65))
    return ''.join(out)
def leaf():
    return P('M0 27Q-28 -4 0 -28Q28 -4 0 27Z',.8)+P('M0 -25V25 M0 -15L-10 -9 M0 -5L-15 3 M0 5L-10 14 M0 -13L10 -7 M0 -2L14 7 M0 8L8 16',.6,.5)
def flower(n=6,r=23):
    return ''.join(f'<g transform="rotate({360*j/n})">'+E(0,-r*.55,r*.24,r*.55,.5)+'</g>' for j in range(n))+C(0,0,4)
def snow(n=6):
    return ''.join(f'<g transform="rotate({360*j/n})">'+P('M0 0V-28 M0 -12L-6 -18 M0 -12L6 -18 M0 -21L-5 -26 M0 -21L5 -26',.9)+'</g>' for j in range(n))
def wave(n=16,amp=5,frequency=1,slope=0,secondary=False):
    body=[]
    for j in range(n):
        pts=[]
        for k in range(65):
            x=k*4;y=j*256/n+amp*math.sin(x*T/256*frequency+j*T/n)+slope*x
            pts.append((x,y))
        d='M'+'L'.join(f'{x:.1f} {y:.1f}' for x,y in pts)
        lo=min(y for x,y in pts);hi=max(y for x,y in pts)
        for dy in (-256,0,256):
            if hi+dy>=-1 and lo+dy<=257:body.append(f'<g transform="translate(0 {dy})">'+P(d,.6+(j%3)*.25,.45)+'</g>')
    if secondary:body.append('<g transform="rotate(90 128 128)">'+wave(n,amp*.6,frequency,0,False)+'</g>')
    return ''.join(body)

def scatter(fragment,seed,count=16,rotate=True,regular=False):
    rng=random.Random(seed);out=[f'<defs><g id="motif">{fragment}</g></defs>'];side=round(math.sqrt(count));step=256/side
    for y in range(side):
        for x in range(side):
            cx=(x+.5)*step+(0 if regular else rng.uniform(-step*.15,step*.15));cy=(y+.5)*step+(0 if regular else rng.uniform(-step*.15,step*.15))
            angle=rng.uniform(-180,180) if rotate else 0;size=rng.uniform(.7,1) if not regular else 1
            for dx in (-256,0,256):
                for dy in (-256,0,256):
                    if -50<cx+dx<306 and -50<cy+dy<306:out.append(f'<use href="#motif" transform="translate({cx+dx:.2f} {cy+dy:.2f}) rotate({angle:.2f}) scale({size:.3f})"/>')
    return ''.join(out)

def motifs():
    d={}
    d['flames']=P('M-15 26Q-28 5 -6 -10Q4 -21 2 -29Q26 -8 13 10Q25 20 8 28Z')+P('M-2 24Q-11 8 6 -2Q2 13 7 21',.6,.4)
    d['veins']=P('M-30 -20L-10 -4L-15 8L5 13L21 30 M-10 -4L4 -19L27 -24 M5 13L23 5L29 -9',1.6,.5)
    d['capillary']=P('M-28 24L-14 12H0L11 0V-17H27 M0 12V-2H-20V-21 M11 -4H26V-23',1,.65)+C(11,0,2)+C(-20,-2,2)
    d['columns']=P('M-18 -28H-2V28H-18Z M8 -20H23V28H8Z M-18 -20H-2 M-18 -8H-2 M-18 4H-2 M-18 16H-2 M8 -9H23 M8 3H23 M8 15H23',.8)
    d['chains']=P('M-31 16L-20 9L-9 16L2 9L13 16 M-9 16V30 M-20 9V-6')+poly([(2,-18),(13,-25),(25,-18),(25,-5),(13,2),(2,-5)],.5)
    d['pulp']=''.join(E(x,y,3,12,.4) for x,y in [(-18,-12),(-10,10),(0,-10),(10,13),(20,-8)])
    d['citrus']=P('M-26 -10Q0 34 26 -10L0 -25Z',1.3)+P('M-22 -8Q0 25 22 -8 M0 -21L-15 4 M0 -21L0 13 M0 -21L15 4',.7,.55)
    d['fruitmix']=d['citrus']+f'<g transform="translate(19 18) scale(.5)">{leaf()}</g>'+C(-20,21,7)+C(-9,27,5)
    d['grapes']=''.join(C(x,y,7,.5) for x,y in [(-14,-13),(0,-17),(14,-13),(-8,0),(8,0),(0,13)])+P('M0 -23Q12 -36 22 -22Q12 -14 12 -27',.8)
    d['kiwi']=E(0,0,27,21)+E(0,0,10,7)+''.join(E(16*math.cos(t),12*math.sin(t),1,2,.7,'black',0) for t in [j*T/16 for j in range(16)])
    d['achenes']=P('M0 -8Q-7 0 0 8Q7 0 0 -8Z',.6)+P('M0 -4V4',.6,.5)
    d['arils']=poly([(-10,-12),(7,-14),(14,3),(4,13),(-11,9),(-15,-3)],.55)+P('M-7 -7L4 -9 M-10 2L-6 7',.5,.4)
    d['pineapple']=poly([(0,-30),(22,0),(0,30),(-22,0)],.55)+star(5,9,4)+P('M-12 0L0 -17L12 0 M-12 2L0 18L12 2',.5)
    d['beans']=E(0,0,16,25)+P('M2 -22Q-8 -5 3 7Q9 18 -2 23',1.3,.65)
    d['cacao']=P('M0 -30Q-29 -12 -14 18Q-6 30 0 32Q30 8 14 -18Q7 -28 0 -30Z')+P('M0 -26Q-9 0 0 27 M5 -25Q20 0 4 27 M-5 -25Q-20 0 -4 27',.6,.45)
    d['tow']=''.join(P(f'M{-28+j*4} -30Q{18-j*3} -3 {-22+j*5} 30',.45,.4) for j in range(12))
    d['felt']=''.join(P(f'M{-28+j*5} {-20+(j*13)%41}q{15-j%5} {-12+j%7} 23 8',.65,.4) for j in range(10))
    d['boucle']=''.join(P(f'M{x} {y}c-13 -15 15 -19 10 -2s-14 9 -10 -4',.8,.6) for x,y in [(-15,-15),(8,-18),(-15,8),(10,10)])
    d['braid']=P('M-23 -29L18 0L-23 29 M-6 -29L30 -3L-11 29 M23 -29L-18 0L23 29 M6 -29L-30 -3L11 29',3.3,.45)
    d['macrame']=poly([(0,-28),(24,0),(0,28),(-24,0)],.4)+''.join(P(f'M{x-3} {y-3}l6 6m-6 0l6 -6',2,.6) for x,y in [(0,-28),(24,0),(0,28),(-24,0)])
    d['crochet']=P('M-28 -8c0 -22 22 -22 22 0s22 22 22 0s22 -22 22 0 M-28 8c0 -22 22 -22 22 0s22 22 22 0s22 -22 22 0',1.2,.6)
    d['lace']=rings(2,24,24)+''.join(f'<g transform="rotate({j*30})">'+E(0,-19,4,9)+'</g>' for j in range(12))+star(6,12,6)
    d['silkmesh']=P('M-31 -20L-12 -10L9 -25L27 -11L19 10L31 28 M-12 -10L-21 14L-5 27L19 10L9 -25 M-21 14L-31 3 M-12 -10L5 5L19 10 M5 5L-5 27',.5,.5)
    d['web']=rays(12,29,0,.45)+rings(4,27,27,.08)
    d['leafveins']=leaf()
    d['fern']=P('M0 30Q-9 -5 4 -30',.9)+''.join(P(f'M0 {y}Q{-17-abs(y)/8:.1f} {y-13} -23 {y-7} M0 {y}Q{17+abs(y)/8:.1f} {y-13} 23 {y-7}',.7,.55) for y in range(-19,25,6))
    d['needles']=''.join(P(f'M0 25L{x} {-27+abs(x)*.3}',.65,.6) for x in range(-25,26,5))
    d['coral']=P('M0 30V8L-15 -5L-25 -24 M-15 -5L-27 -5 M0 8L15 -8L26 -13 M15 -8L13 -26 M0 10V-20L-10 -28',2.8,.55)
    d['capillarynet']=d['veins']+f'<g transform="rotate(90) scale(.62)">{d["veins"]}</g>'
    d['wing']=P('M-30 -24Q-4 -9 30 -25 M-30 -8Q0 5 30 -8 M-30 12Q0 24 30 10 M-30 28H30',.6)+''.join(P(f'M{x} -24L{x-8} -8L{x+4} 13L{x-4} 28',.45,.5) for x in range(-22,30,10))
    d['diatom']=E(0,0,16,29)+E(0,0,10,24)+''.join(C(12*math.cos(t),24*math.sin(t),1,.6,'black',0) for t in [j*T/24 for j in range(24)])+P('M0 -22V22',.5)
    d['fishscales']=P('M-26 -25Q0 32 26 -25 M-21 -25Q0 21 21 -25 M-16 -25Q0 11 16 -25',.65,.6)
    d['snowflakes']=snow()
    d['ice-needles']=rays(6,30,0,.55)+P('M-20 -23L20 23 M-12 -29L12 29',.5)
    d['graupel']=''.join(poly([(x+math.cos(t)*r,y+math.sin(t)*r) for t in [j*T/7 for j in range(7)]],.25,'black',.4) for x,y,r in [(-13,-14,10),(9,-7,12),(0,14,10),(22,17,6)])
    d['icicles']=poly([(-18,-30),(-9,23),(-4,-30),(4,-30),(13,31),(23,-30)],.5)+P('M-14 -21L-10 7 M11 -21L13 13',.45)
    d['rain']=P('M-20 -28l-8 27 M-3 -12l-12 40 M20 -26L8 11 M25 14l-4 17',.75,.45)
    d['rainrings']=rings(3,28,11)
    d['hail']=rings(2,22,18,.22)+P('M-14 8L-7 10 M8 -11L16 -5',.65)
    d['isobars']=rings(6,29,25,.17)
    d['clay']=poly([(-28,-24),(-1,-29),(25,-17),(29,10),(10,28),(-24,24)],.7,w=2)+P('M-25 -22L-8 -13L0 -25 M25 -13L14 -7L26 10 M9 25L0 15L-20 22',.7,.4)
    d['basalt']=poly([(math.cos(t)*28,math.sin(t)*28) for t in [j*T/6 for j in range(6)]],.7)+poly([(0,0),(28,0),(14,24),(0,0)],.15,'black',0)+P('M0 0L-14 -24 M0 0L-14 24',.6)
    d['geode']=rings(7,29,24,.2)+poly([(math.cos(t)*9,math.sin(t)*7) for t in [j*T/7 for j in range(7)]],.3,'black',0)
    d['salt']=''.join(f'<g transform="translate({x} {y}) rotate({a})">'+poly([(-6,-7),(7,-7),(8,6),(-7,8)],.45)+P('M-6 -7L2 0L8 6 M2 0L7 -7',.5)+'</g>' for x,y,a in [(-18,-15,10),(0,-4,-20),(18,10,35),(-16,19,45),(17,-21,5)])
    d['pumice']=''.join(E(x,y,rx,ry,.5) for x,y,rx,ry in [(-17,-17,9,5),(5,-20,6,8),(19,-4,8,5),(-14,3,5,9),(3,16,12,7),(24,23,4,5)])
    d['fossils']=P('M0 0c14 -25 30 9 0 17c-29 7 -30 -30 -5 -38c24 -8 40 23 13 42',.8)+rays(10,28,19,.5)
    d['paperbits']=P('M-25 -18L-4 -22L0 -17L-22 -14Z M7 -4L30 1L27 5L6 0Z M-20 22L1 12L4 16L-17 25Z',0,.3,'black')
    d['letterpress']=poly([(-23,-23),(5,-23),(5,5),(-23,5)],.4)+poly([(-21,-21),(7,-21),(7,7),(-21,7)],.15)+C(17,18,12,.4)+C(19,20,12,.15)
    d['riso']=poly([(-25,0),(0,-25),(25,0),(0,25)],.5)+poly([(-22,3),(3,-22),(28,3),(3,28)],.3)+C(-12,16,4,.4,'black',0)
    d['rosette']=rings(4,25,25)+rays(24,28,8,.35)+''.join(C(16*math.cos(t),16*math.sin(t),1.2,.6,'black',0) for t in [j*T/17 for j in range(17)])
    d['pulpclumps']=poly([(-28,-2),(-12,-20),(6,-16),(25,-8),(17,4),(25,23),(2,18),(-15,27),(-18,8)],.18,'black',0)+d['felt']
    d['flutes']=P('M-32 -24H32 M-32 24H32 M-32 0Q-24 -28 -16 0T0 0T16 0T32 0',1.2,.65)+P('M-32 -20H32 M-32 20H32',.45,.3)
    d['cyanotype']=f'<g transform="rotate(-25) scale(.75)">{leaf()}</g>'+P('M0 22Q15 10 25 26',.7)+f'<g transform="translate(24 13) rotate(50) scale(.4)">{leaf()}</g>'
    d['tornpaper']=poly([(-32,-18),(-20,-16),(-13,-22),(1,-17),(11,-20),(20,-16),(32,-19),(32,12),(20,16),(10,12),(-3,18),(-16,12),(-32,17)],.3,'black',.5)+P('M-28 -10L24 -12',.6,.3)
    d['nouveau']=P('M0 30C-35 12 -22 -28 -7 -20C9 -10 -24 -8 -12 -24C2 -45 27 -9 0 4C-20 12 20 16 0 30 M0 30C35 12 22 -28 7 -20',.9)+E(0,12,5,8)
    d['artcraft']=leaf()+f'<g transform="translate(-18 12) rotate(-55) scale(.5)">{leaf()}</g>'+f'<g transform="translate(18 12) rotate(55) scale(.5)">{leaf()}</g>'
    d['secession']=poly([(-25,-25),(25,-25),(25,25),(-25,25)],.5)+P('M-13 24V-8 M0 24V-17 M13 24V-8',.8)+C(-13,-14,5)+C(0,-22,5)+C(13,-14,5)
    d['decofans']=P('M-30 25Q0 -42 30 25Z',1)+''.join(P(f'M{(-30+6*j):.1f} 25Q0 {-34+j%2*5} {(30-6*j):.1f} 25',.65) for j in range(1,5))
    d['decosteps']=P('M-28 28V-5H-18V-16H-8V-28H8V-16H18V-5H28V28 M-20 28V2H-10V-8H10V2H20V28 M0 -20V28',.9)
    d['bauhaus']=C(0,0,26,.5)+P('M-26 0H26 M0 -26V26',.9)+poly([(-26,0),(0,0),(0,26)],.22,'black',0)+E(0,0,12,26,.45)
    d['construct']=poly([(-25,-17),(20,18),(26,9),(-19,-26)],.5,'black',0)+C(13,-14,11,.6)+poly([(-27,15),(-5,15),(-5,26),(-27,26)],.3,'black',0)
    d['guilloche']=''.join(P('M'+'L'.join(f'{(23+5*math.sin(5*t+j)) * math.cos(t):.2f} {(23+5*math.sin(5*t+j))*math.sin(t):.2f}' for t in [k*T/96 for k in range(97)]),.4,.5) for j in range(6))
    d['damask']=leaf()+flower(4,27)+P('M-20 24Q0 13 20 24 M-18 29Q0 20 18 29',.6,.5)
    d['newsprint']=''.join(P(f'M-27 {y}H{-4 if y%3 else -11} M4 {y}H{28 if y%4 else 18}',.7,.45) for y in range(-25,28,3))
    d['boomerang']=P('M-27 21Q-22 -30 -4 -22Q2 -12 29 19Q3 5 -7 -1Q-13 7 -27 21Z',.8,.5,'black')+C(25,-23,2)
    d['atomic']=E(0,0,27,8)+f'<g transform="rotate(60)">{E(0,0,27,8)}</g>'+f'<g transform="rotate(120)">{E(0,0,27,8)}</g>'+C(0,0,3,.8,'black',0)
    d['kitchentile']=P('M-25 -25H25V25H-25Z M-18 -18H18V18H-18Z',.7)+poly([(0,-9),(9,0),(0,9),(-9,0)],.4,'black',0)
    d['psychedelic']=''.join(f'<g transform="rotate({j*60})">'+P('M0 0C-30 -18 -4 -45 12 -20Q24 0 0 0Z',.75)+'</g>' for j in range(6))
    d['seventiesarches']=''.join(P(f'M{-28+j*5} 28V0A{28-j*5} {28-j*5} 0 0 1 {28-j*5} 0V28',2.1,.5) for j in range(5))
    d['flowerpower']=flower(5,26)+C(0,0,9,.2,'black',0)
    d['memphis']=P('M-28 -18q5 -12 10 0t10 0t10 0 M-20 21l8 -12l9 12l8 -12 M13 6h14v-14',1.4)+C(-26,4,2,.5,'black',0)+C(22,25,3,.5,'black',0)
    d['shards']=poly([(-30,-24),(8,-13),(-13,18)],.3,'black',0)+poly([(9,-22),(30,-8),(17,2)],.6)+poly([(-6,5),(25,10),(28,26),(-18,24)],.45)
    d['pixelcheck']=''.join(poly([(x,y),(x+7,y),(x+7,y+7),(x,y+7)],.35,'black',0) for y in range(-28,29,8) for x in range(-28,29,8) if ((x//8+y//8)%3==0 or (x//8-y//8)%5==0))
    d['dither']=''.join(C(x,y,.6+((x+28)%16)/10,.7,'black',0) for y in range(-26,29,7) for x in range(-26,29,7) if (x+y)%3)
    d['y2kstars']=star(4,30,5)+star(4,20,3,.3)
    d['wirebubbles']=C(0,0,28)+''.join(E(0,0,r,28,.5,w=.5) for r in (8,18))+''.join(E(0,y,math.sqrt(28*28-y*y),4,.4,w=.5) for y in (-19,-8,8,19))
    d['woodcut']=P('M-28 -22l13 6m-2 -10l17 11m-31 8l22 5m-6 -11l23 9m-31 9l18 7m-5 -12l18 9m-28 4l9 7',1.8,.55)
    d['etching']=''.join(P(f'M-29 {y}l58 22 M-29 {y+22}l58 -22',.45,.5) for y in range(-35,28,6))
    d['drypoint']=P('M-23 -30L-18 30 M-7 -30L-4 30 M13 -30L6 30 M25 -30L23 30',.5)+P('M-20 -12l5 8 M-5 4l5 7 M10 -15l6 -5 M24 14l-7 4',.4,.5)
    d['inkhatch']=''.join(P(f'M{-28+j*6} -27q{j%3*3} 26 {-2+j%4} 56',.6+j%2*.4,.5) for j in range(10))
    d['pastel']=''.join(P(f'M{-27+j*6} {-20+j%4*9}l{14-j%4} 15',3,.35) for j in range(9))
    d['chalk']=P('M-28 13c-18 -26 33 -47 30 -10s-35 25 -19 3s40 -24 44 -2',1.5,.5)+P('M-20 25l6 3m4 -5l8 2m4 -6l6 1',.7,.5)
    d['gouache']=P('M-29 -21l47 6 M-19 4l46 -4 M-27 25l42 -8',12,.28)
    d['watercolor']=rings(4,29,24,.24)
    d['screentone']=d['etching']+C(-14,-11,3,.4,'black',0)+C(17,16,2,.5,'black',0)
    d['mangaspeed']=P('M-30 -20L30 7 M-30 -11L29 12 M-29 -2L30 17 M-30 18L28 26',.7)+P('M-13 -23L27 -4',1.6,.4)
    d['impact']=rays(17,31,14,.8)
    d['bursts']=star(11,29,19)
    d['actionarcs']=''.join(P(f'M{-30+j*5} 24Q-25 -20 {26-j*2} {-20+j*3}',.8) for j in range(5))+P('M14 -27l5 10 M23 -22l2 9',.6)
    d['panels']=poly([(-28,-25),(-4,-23),(-8,0),(-28,3)],.65)+poly([(3,-25),(28,-27),(25,10),(-2,3)],.65)+poly([(-27,11),(23,18),(29,27),(-28,26)],.65)
    d['speech']=P('M-24 -20Q-34 3 -13 14L-18 26L-3 17Q31 20 29 -5Q29 -29 0 -27Q-15 -27 -24 -20Z',.85)
    d['comicrosette']=rays(9,27,10,.5)+''.join(C(17*math.cos(t),17*math.sin(t),2,.4,'black',0) for t in [j*T/13 for j in range(13)])+star(4,9,3)
    d['comictears']=d['tornpaper']+P('M-26 -8l7 8m0 -9l7 8m0 -9l7 8m0 -9l7 8',.9,.4)
    d['inkclouds']=P('M-23 17q-18 -9 -5 -20q-7 -20 10 -18q8 -22 22 -8q21 -8 22 11q18 8 5 24q5 20 -16 20Z',1.2)+P('M-17 13l8 8 M-11 12l8 9 M-5 11l8 10',.7)
    d['comiczigzag']=P('M-29 -21L-6 -12L-16 1L17 8L7 24L31 18',2.5,.5)+P('M-24 12l7 8 M-19 9l7 8',.6)
    d['filmgate']=P('M-29 -20H29V20H-29Z M-25 -16H25V16H-25Z M-31 -24h8 M23 -24h8 M-31 24h8 M23 24h8',.7)
    d['sprocket']=P('M-25 -32V32 M25 -32V32 M-16 -24H16V24H-16Z',.8)+''.join(P(f'M-23 {y}h4v7h-4Z M19 {y}h4v7h-4Z',.65) for y in (-25,-11,3,17))
    d['graintrails']=P('M-21 -17l3 7 M-11 16l4 3 M3 -27l1 6 M16 -10l-2 9 M25 15l-1 6 M-25 26l2 3',1.8,.4)
    d['projectordust']=P('M-18 -28l2 17 M2 -16l-3 25 M24 -26l-4 18 M-24 12l4 17 M12 15l3 11',.7,.5)+C(22,28,1.5,.5,'black',0)
    d['diopter']=P('M-29 -20A37 37 0 0 1 29 20 M-29 -11A28 28 0 0 1 20 24 M-22 -26A37 37 0 0 1 28 12',.65,.5)
    d['newton']=rings(11,29,25,.025)
    d['triangles']=poly([(-30,-25),(0,-18),(-14,9)],.6)+poly([(0,-18),(28,-28),(25,7),(-14,9)],.4)+P('M-14 9L1 28L25 7 M-30 -25L-30 26L1 28 M-14 9L25 7',.6)
    d['voxels']=P('M-24 -12L-9 -20L6 -12V5L-9 13L-24 5Z M-9 -3V13 M-24 -12L-9 -3L6 -12 M-2 10L13 2L28 10V26L13 34L-2 26Z M13 18V34 M-2 10L13 18L28 10',.75)
    d['photonic']=poly([(math.cos(t)*28,math.sin(t)*28) for t in [j*T/3 for j in range(3)]],.4)+C(0,0,13,.6)+C(0,0,7,.3)
    d['origami']=d['triangles']+poly([(-30,-25),(0,-18),(-14,9)],.13,'black',0)+poly([(0,-18),(25,7),(-14,9)],.08,'black',0)
    d['topoloops']=P('M-27 0C-27 -35 27 35 27 0S-27 -35 -27 0 M-27 5C-27 -30 27 40 27 5',1.3,.6)
    d['scifipanels']=P('M-30 -28H7L14 -19H30V10L19 12L15 29H-15L-21 19H-30Z M-22 -21H-3 M21 0V7 M-8 22H8',.8)+C(24,-13,1.5)+C(-24,10,1.5)
    d['truchet']=P('M-32 0A32 32 0 0 1 0 32 M0 -32A32 32 0 0 0 32 0',3,.45)
    d['pinwheel']=poly([(0,0),(-28,-28),(28,-28)],.25,'black',0)+poly([(0,0),(28,-28),(28,28)],.5,'black',0)+poly([(0,0),(28,28),(-28,28)],.15,'black',0)+poly([(0,0),(-28,28),(-28,-28)],.65)
    d['rhombi']=poly([(0,-30),(25,-15),(0,0),(-25,-15)],.3)+poly([(0,0),(25,-15),(25,15),(0,30)],.5)+poly([(0,0),(-25,-15),(-25,15),(0,30)],.2)
    d['eightstar']=star(8,27,18)+C(0,0,5,.35)+rays(8,32,28,.6)
    d['seigaiha']=''.join(P(f'M{-r} 25A{r} {r} 0 0 1 {r} 25',.65) for r in (29,22,15,8))
    d['asanoha']=poly([(math.cos(t)*30,math.sin(t)*30) for t in [j*T/6 for j in range(6)]],.5)+rays(6,30,0,.6)+''.join(poly([(0,0),(math.cos(t)*30,math.sin(t)*30),(math.cos(t+.52)*17,math.sin(t+.52)*17)],.4,w=.55) for t in [j*T/6 for j in range(6)])
    d['kumiko']=P('M-28 -28H28V28H-28Z M-28 0H28 M0 -28V28 M-28 -28L28 28 M-28 28L28 -28 M-14 -28L28 14 M-28 -14L14 28',.6)
    d['meander']=P('M-32 -24H22V20H-18V-13H10V9H-7V0',2,.65)+P('M-32 28H28V-28',.7,.4)
    d['herringbone']=P('M-28 -14L0 -28L14 0L-14 14Z M0 14L28 0L14 -28L-14 -14 M-14 14L0 42L28 28L14 0',.75)
    d['cubes']=d['rhombi']+poly([(0,0),(25,-15),(25,15),(0,30)],.14,'black',0)
    d['scallops']=P('M-28 -5Q0 35 28 -5Q0 -34 -28 -5Z',.7)+rays(7,23,4,.4)
    d['zellige']=poly([(-27,-25),(25,-28),(29,25),(-24,28)],.5)+P('M-22 -21L19 -22 M22 -16L24 17',.45,.35)
    d['craquelure']=P('M-30 -26L-12 -17L8 -26L29 -10L18 7L29 30 M-12 -17L-21 2L-5 16L18 7 M-21 2L-30 12 M-5 16L-12 30 M8 -26L4 -5L18 7',.5,.6)
    d['mosaic']=poly([(-28,-26),(-3,-28),(-7,-2),(-25,0)],.55)+poly([(4,-25),(27,-22),(29,2),(2,-2)],.4)+poly([(-28,7),(-6,5),(-1,27),(-26,28)],.35)+poly([(5,8),(28,10),(24,28),(7,25)],.65)
    d['majolica']=flower(4,20)+poly([(-28,-28),(-16,-23),(-23,-16)],.4,'black',0)+poly([(28,28),(16,23),(23,16)],.4,'black',0)
    d['pebbles']=E(-15,-14,12,9)+E(13,-15,12,13)+E(-14,13,14,12)+E(16,17,10,8)
    d['chisel']=P('M-28 -22L-13 -27L-4 -20L-18 -12Z M4 -8L22 -16L29 -9L11 -1Z M-24 12L-7 6L1 14L-15 23Z',.6,.45)
    d['inlay']=star(8,24,16)+poly([(-29,-29),(29,-29),(29,29),(-29,29)],.5)+poly([(-9,-9),(9,-9),(9,9),(-9,9)],.25,'black',0)
    d['endgrain']=rings(8,28,25,.1)+P('M0 2L19 25 M-15 -22L-5 -7',.6,.5)
    d['burl']=rings(6,27,18,.15)+E(-5,-1,3,2,.5,'black',0)
    d['bamboo']=P('M-18 -32V32 M18 -32V32 M-18 -10Q0 -6 18 -10 M-18 -5Q0 -1 18 -5',1.1,.6)+P('M-9 -29V-13 M-4 2V29 M8 -29V-14 M12 1V28',.4,.3)
    d['corkcells']=d['mosaic']+P('M-23 -18l6 3m5 -6l2 6m17 -1l5 3m-38 30l8 -5m20 -4l4 6',.5,.4)
    d['wovenleather']=P('M-30 -18L30 18 M-30 18L30 -18',14,.28)+P('M-30 -24L30 12 M-30 24L30 -12',.7,.6)
    d['croc']=P('M-28 -26H-3V-1H-28Z M3 -26H28V-1H3Z M-28 5H3V28H-28Z M9 5H28V28H9Z',1.6,.4)+P('M-24 -20h14m19 3h14m-43 32h20m16 0h9',.4,.3)
    d['straw']=P('M-27 -32V32 M-19 -32V32 M-11 -32V32 M-3 -32V32 M5 -32V32 M13 -32V32 M21 -32V32 M29 -32V32',1.4,.4)+P('M-32 -18Q0 -10 32 -18 M-32 -13Q0 -5 32 -13 M-32 18Q0 10 32 18',.65,.7)
    d['pcb']=P('M-30 -24H-12V-8H10V14H30 M-30 8H-15V27H8 M-2 -30V-15H22V-4H32',.85)+''.join(C(x,y,3) for x,y in [(-30,-24),(10,-8),(8,27),(-2,-30)])
    d['cablesection']=C(0,0,29)+''.join(C(x,y,9,.5) for x,y in [(0,0),(-17,-10),(0,-19),(17,-10),(-17,10),(0,19),(17,10)])+''.join(C(x,y,2,.4,'black',0) for x,y in [(0,0),(-17,-10),(0,-19),(17,-10),(-17,10),(0,19),(17,10)])
    d['tiretread']=P('M-26 -32L-5 -17L-20 -2L2 12L-13 27 M4 -32L25 -17L10 -2L30 12L15 27',5,.5)+P('M-28 4l10 6 M-1 -20l10 6 M3 20l10 6',.7)
    d['rubber']=P('M-28 -24H-4 M4 -24H28 M-28 -12H28 M-28 0H10 M18 0H28 M-28 12H28 M-28 24H-12 M-4 24H28',3,.45)
    d['weld']=''.join(P(f'M-13 {y}q13 -15 26 0q-13 15 -26 0Z',.8,.5) for y in range(-26,30,9))
    d['turning']=''.join(P(f'M{-r} 25A{r} {r} 0 1 1 {r} 25',.45,.5) for r in range(8,31,3))
    d['knurl']=P('M-32 -24L24 32 M-32 -8L8 32 M-24 -32L32 24 M-8 -32L32 8 M-32 24L24 -32 M-32 8L8 -32 M-24 32L32 -24 M-8 32L32 -8',1.3,.45)
    d['chainmail']=E(-13,-12,16,22)+E(13,12,16,22)+E(-13,-12,12,18,.25)+E(13,12,12,18,.25)
    d['expanded']=poly([(0,-31),(13,0),(0,31),(-13,0)],.65)+poly([(0,-21),(8,0),(0,21),(-8,0)],.25)
    d['slots']=P('M-18 -27Q-23 -27 -23 -20V20Q-23 27 -18 27Q-13 27 -13 20V-20Q-13 -27 -18 -27Z M8 -27Q3 -27 3 -20V20Q3 27 8 27Q13 27 13 20V-20Q13 -27 8 -27Z',.8)
    d['confetti']=poly([(-25,-22),(-10,-18),(-13,-8),(-28,-12)],.5,'black',0)+P('M4 -23q16 5 13 18 M-18 12l15 10 M9 12l19 7',3,.55)
    d['serpentine']=P('M-29 24C-44 -19 30 -34 22 -11S-21 -6 -12 13S29 33 31 3',1.3,.6)
    d['glitter']=star(4,20,4)+f'<g transform="translate(24 -25) scale(.25)">{star(4,20,4)}</g>'
    d['ribbonloops']=P('M0 4C-36 -28 -30 23 0 4C32 -28 30 23 0 4L-13 30 M0 4L18 28',1,.6)
    d['balloons']=E(0,-9,20,25)+P('M-3 17L0 12L4 18Z M0 18q-12 10 -3 20',.75)
    d['giftfolds']=poly([(-29,-28),(27,-20),(23,26),(-26,29)],.4)+P('M-29 -28L-2 -3L27 -20 M-2 -3L23 26 M-26 29L-2 -3 M-18 -15L18 10',.7)
    d['embossedstars']=star(5,26,12,.6)+f'<g transform="translate(1.5 1.5)">{star(5,26,12,.2)}</g>'
    d['postcard']=poly([(-27,-22),(27,-22),(27,22),(-27,22)],.5)+''.join(C(x,y,2,.6) for x,y in [(x,-27) for x in range(-24,25,8)]+[(x,27) for x in range(-24,25,8)])+P('M-21 -16H21V16H-21Z',.45)
    d['doilies']=rings(2,22,22)+flower(12,29)+star(6,16,7,.5)
    d['fireworks']=rays(19,29,5,.7)+''.join(C(29*math.cos(t),29*math.sin(t),1.2,.5,'black',0) for t in [j*T/19 for j in range(19)])
    d['cells']=E(0,0,28,23)+C(-5,3,7,.45)+C(-6,2,3,.2,'black',0)
    d['neurons']=rays(7,30,8,.6)+star(7,12,7,.5)+''.join(f'<g transform="rotate({j*360/7})">'+P('M20 0L27 -7 M23 0L29 7',.5)+'</g>' for j in range(7))
    d['pollen']=C(0,0,19)+rays(24,26,19,.65)+''.join(C(x,y,2,.5) for x,y in [(-7,-6),(8,-7),(0,4),(-7,11),(10,10)])
    d['biofilm']=''.join(E(x,y,10,7,.35) for x,y in [(-18,-15),(-2,-19),(15,-10),(-12,0),(7,4),(-19,17),(2,20),(22,16)])
    d['fingerprint']=rings(8,25,29,.03)+P('M-5 -26L-3 -11 M5 28L7 13',1.5,.5)
    d['protein']=P('M-28 20C-32 -20 12 -32 5 -8S-28 5 -9 18S29 27 27 -2 M-24 20C-28 -16 15 -28 9 -8S-24 1 -5 14S25 23 23 -2',1.2,.6)
    d['stomata']=P('M-2 -26C-32 -28 -32 28 -2 26Q-15 0 -2 -26Z M2 -26C32 -28 32 28 2 26Q15 0 2 -26Z',.85)
    d['myelin']=rings(6,28,22,.07)+C(0,0,3,.35,'black',0)
    d['spicules']=rays(3,31,0,.75)+rays(4,18,0,.4)
    d['champagne']=''.join(C(x,y,r,.5) for x,y,r in [(-23,-20,3),(-8,-8,1.5),(13,-24,2.2),(25,0,4),(-18,18,2),(2,9,3.1),(14,25,1)])
    d['winelacing']=P('M-30 -10Q-15 -26 0 -10Q15 -26 30 -10 M-30 -10Q-25 14 -28 31 M0 -10Q-6 10 -2 30 M30 -10Q24 9 27 25',.75)
    d['tannin']=rings(2,27,24,.2)+P('M-18 21q11 5 23 -1 M-25 -8l3 -7',1.5,.3)
    d['vineleaf']=poly([(0,-29),(8,-13),(24,-20),(20,-4),(29,6),(13,11),(11,28),(0,19),(-16,27),(-14,10),(-28,4),(-18,-8),(-23,-22),(-6,-15)],.6)+P('M0 -22V24 M0 1L-19 -9 M0 1L18 -8 M0 8L-13 18 M0 8L13 17',.5)
    d['grapeseeds']=P('M0 -18Q-20 -2 -5 16Q10 22 13 9Q20 -7 0 -18Z',.75)+P('M0 -11Q-5 0 3 12',.5)
    d['barrel']=P('M-25 -32Q-29 0 -25 32 M-5 -32Q-9 0 -5 32 M15 -32Q11 0 15 32 M30 -32Q26 0 30 32 M-30 -15H32 M-30 19H32',.8)+P('M-19 -22q5 9 -1 18 M1 0q5 9 -1 18',.45,.4)
    d['corkstamp']=rings(2,25,25)+P('M-20 -5q20 -10 40 0 M-20 5q20 10 40 0',.7,.45)+C(0,0,5,.4)
    d['bubbleraft']=''.join(C(x,y,3+(x+y)%4,.5) for y in (-13,-5,4,12) for x in range(-28,29,10))
    d['tartar']=poly([(-24,-15),(-6,-28),(14,-20),(28,1),(8,26),(-16,19)],.5)+P('M-6 -28L-2 -2L14 -20 M-2 -2L28 1 M-2 -2L8 26 M-2 -2L-16 19',.6)
    d['ocean']=''.join(P(f'M-30 {y}Q-10 {y-12} 5 {y}T30 {y}',.6,.5) for y in (-22,-13,-4,6,17,27))
    d['beachfoam']=P('M-32 -15Q-12 -26 4 -13T32 -15 M-32 18Q-10 3 8 18T32 18',.85)+''.join(C(x,y,3+(x%3),.4) for x,y in [(-20,-10),(-10,-16),(0,-9),(10,-9),(21,-12),(-19,14),(-6,15),(5,20),(19,19)])
    d['kelp']=P('M-5 31Q-31 12 -8 -6Q11 -20 -1 -30Q29 -4 11 12Q0 22 7 31Z',.85)+P('M0 -25Q17 -2 0 28',.5,.4)
    d['shells']=P('M0 23Q-40 5 -24 -18Q0 -36 24 -18Q40 5 0 23Z',.8)+''.join(P(f'M0 23Q{x} -9 {x} {-24+abs(x)*.25}',.5,.5) for x in range(-24,25,6))
    d['sanddollar']=C(0,0,28)+flower(5,20)+C(0,0,3)
    d['eddies']=P('M-28 0C-25 -30 28 -28 26 0S-20 27 -20 0S20 -23 20 0S-14 18 -14 0S12 -15 12 0S-5 12 -5 0',.75,.5)
    d['delta']=P('M0 30V8L-13 -3L-29 -16 M-13 -3L-16 -25 M0 8L14 -4L30 -8 M14 -4L19 -27 M0 9L2 -29 M0 19L-21 12L-30 5',.8,.6)
    d['islands']=rings(3,28,25,.24)
    d['mountains']=poly([(-29,23),(-5,-28),(29,23)],.6)+P('M-5 -28L2 23 M-17 -3L-2 6 M-20 5L-2 14 M-23 13L-2 22 M8 -8L2 3 M13 1L2 12 M19 11L2 22',.5,.4)
    d['zebra']=P('M-28 -27Q-7 -10 -23 1L-8 15L-15 29 M-11 -30Q12 -13 -3 0L12 18L8 30 M13 -29Q30 -9 15 2L29 23',4,.5)
    d['tiger']=poly([(-31,-25),(-3,-19),(11,-8),(-11,-13),(-30,-13)],.5,'black',0)+poly([(31,-3),(0,4),(-16,18),(8,12),(31,10)],.5,'black',0)+poly([(-30,23),(-9,25),(9,32),(-28,30)],.4,'black',0)
    d['leopard']=P('M-24 -2Q-29 -21 -9 -24 M-1 -25Q23 -25 25 -4 M24 8Q24 27 5 26 M-8 25Q-25 21 -25 12',5,.5)+C(2,2,4,.35,'black',0)
    d['giraffe']=poly([(-24,-22),(-3,-28),(24,-13),(20,13),(5,27),(-23,18)],.35,'black',.5)
    d['cow']=P('M-23 -23C2 -40 -6 -12 15 -15S40 17 17 24S-17 40 -24 17S-42 -3 -23 -23Z',0,.4,'black')
    d['dalmatian']=poly([(-13,-24),(2,-25),(11,-14),(9,-2),(-5,5),(-17,-5)],.55,'black',0)+poly([(5,14),(16,8),(26,17),(22,27),(9,28)],.45,'black',0)
    d['peacock']=P('M0 31Q-38 -3 -19 -24Q0 -39 19 -24Q38 -3 0 31Z',.65)+E(0,-5,12,18)+E(0,-6,7,11)+C(0,-5,3,.4,'black',0)+P('M0 2V32',.5)
    d['feather']=P('M0 -31V31',.8)+''.join(P(f'M0 {y}L-23 {y-12} M0 {y}L23 {y-12}',.5,.5) for y in range(-16,30,5))
    d['elytra']=P('M0 -30Q-30 -19 -23 19Q-12 31 0 31Q30 27 23 -14Q15 -30 0 -30Z M0 -28V30',.8)+''.join(P(f'M{x} -21Q{x+5} 0 {x} 24',.5,.5) for x in (-16,-9,9,16))
    d['snakescale']=poly([(0,-30),(16,-5),(12,12),(0,28),(-12,12),(-16,-5)],.6)+P('M0 -22V21 M-7 3L0 12L7 3',.45,.4)
    d['paisley']=P('M8 -30C-28 -26 -35 11 -15 24C13 42 36 13 16 -2C6 -9 7 -17 8 -30Z',.8)+P('M3 -20C-23 -15 -25 9 -10 18C9 30 26 12 10 3',.55)+''.join(C(-5+9*math.cos(t),6+9*math.sin(t),1.2,.5,'black',0) for t in [j*T/10 for j in range(10)])
    d['sashiko']=poly([(0,-29),(29,0),(0,29),(-29,0)],.5)+''.join(P(f'M{x} -15h5 M{x} 15h5',.7) for x in range(-21,22,9))+P('M-28 0Q0 -30 28 0Q0 30 -28 0',.7,.5)
    d['bandhani']=''.join(C(19*math.cos(t),19*math.sin(t),2.6,.6) for t in [j*T/12 for j in range(12)])+C(0,0,3,.3)
    d['ikat']=poly([(0,-30),(6,-23),(3,-18),(13,-14),(10,-8),(25,-3),(18,4),(23,11),(10,14),(13,21),(3,25),(0,32),(-7,23),(-4,17),(-16,12),(-12,5),(-25,1),(-17,-7),(-21,-13),(-9,-17),(-11,-23)],.45)+P('M0 -18L12 0L0 19L-11 0Z',.6)
    d['batik']=flower(5,24)+P('M-29 -20L-20 -14L-25 -5 M29 12L19 8L23 20 M-20 27L-15 19L-7 25',.6,.6)
    d['argyle']=poly([(0,-30),(24,0),(0,30),(-24,0)],.2,'black',0)+P('M-30 -30L30 30 M-30 30L30 -30 M-30 0L0 -30L30 0L0 30Z',.65,.55)
    d['houndstooth']=poly([(-24,-24),(-8,-24),(-8,-8),(8,-24),(24,-24),(8,-8),(24,8),(24,24),(8,24),(8,8),(-8,24),(-24,24),(-8,8),(-24,-8)],.45,'black',0)
    d['toile']=d['fern']+f'<g transform="translate(16 -14) scale(.45)">{flower(5,20)}</g>'
    d['bread']=E(-17,-13,8,13)+E(10,-20,11,5)+E(13,10,10,15)+E(-16,18,12,6)+P('M-29 1L-6 -2 M-5 25L6 29',.5,.3)
    d['pastry']=''.join(P(f'M-28 {y}Q0 {y-16} 28 {y+3}',.6,.55) for y in range(-23,27,5))
    d['chocolate']=P('M-27 -27H27V27H-27Z M-22 -22H22V22H-22Z M-17 -17H17V17H-17Z',.75,.5)+P('M-27 -27L-17 -17 M27 -27L17 -17 M27 27L17 17 M-27 27L-17 17',.55,.4)
    d['sugar']=d['salt']+P('M-26 3L-15 -2L-7 7L-14 17Z',.5,.45)
    d['tea']=P('M-23 22Q-24 -19 18 -27Q32 12 -23 22Z M-20 19L17 -24 M-7 5L-13 -8 M2 -5L17 -4',.75,.6)
    d['rice']=E(0,0,5,18,.5)+P('M-1 -13Q-4 0 -1 12',.45,.3)
    d['oats']=poly([(-19,-9),(-6,-19),(14,-16),(23,-3),(16,14),(-5,19),(-21,8)],.5)+P('M-11 -9L-6 11 M-2 -14L2 14 M8 -11L12 9',.45,.4)
    d['waffle']=P('M-30 -30H30V30H-30Z M-23 -23H23V23H-23Z M-16 -16H16V16H-16Z',1.4,.4)
    d['coconut']=P('M-28 -20q15 -7 33 7 M-22 -6q15 -7 33 7 M-10 15q15 -7 33 7 M3 -27q7 17 17 23 M-28 25q7 -17 17 -23',.55,.5)
    return d

CSS={
 'tartan':'background-image:repeating-linear-gradient(0deg,transparent 0 28px,$INK 28px 38px,transparent 38px 48px,$ACCENT 48px 51px,transparent 51px 64px),repeating-linear-gradient(90deg,transparent 0 28px,$SECONDARY 28px 38px,transparent 38px 48px,$HIGHLIGHT 48px 51px,transparent 51px 64px);',
 'gingham':'background-image:repeating-linear-gradient(0deg,transparent 0 24px,$INK 24px 48px),repeating-linear-gradient(90deg,transparent 0 24px,$SECONDARY 24px 48px);',
 'chocolate':'background-image:repeating-radial-gradient(ellipse 70% 22% at 45% 40%,transparent 0 18%,$INK 24%,$HIGHLIGHT 27%,$ACCENT 29%,transparent 35%);',
 'slick':'background-image:repeating-radial-gradient(ellipse at 44% 45%,transparent 0 12%,$INK 14%,$SECONDARY 18%,$ACCENT 21%,transparent 24%);',
 'synth':'background-image:linear-gradient(transparent 44%,$ACCENT 46%,transparent 50%),repeating-conic-gradient(from 57deg at 50% 42%,transparent 0 8deg,$INK 8deg 8.3deg,transparent 8.3deg 16deg),repeating-linear-gradient(0deg,transparent 0 29px,$SECONDARY 29px 30px);',
 'vhs':'background-image:repeating-linear-gradient(0deg,transparent 0 13px,$INK 13px 13.5px,transparent 13.5px 27px),linear-gradient(90deg,$SECONDARY,transparent 15% 60%,$ACCENT 70%,transparent);',
 'crt':'background-image:repeating-linear-gradient(90deg,$INK 0 1px,transparent 1px 3px,$ACCENT 3px 4px,transparent 4px 6px,$SECONDARY 6px 7px,transparent 7px 9px),repeating-linear-gradient(0deg,transparent 0 3px,$HIGHLIGHT 3px 3.4px);',
 'aero':'background-image:repeating-linear-gradient(0deg,transparent 0 40px,$HIGHLIGHT 42px,$SECONDARY 45px,transparent 58px 80px),linear-gradient(115deg,$INK,transparent,$ACCENT);',
 'anamorphic':'background-image:radial-gradient(ellipse 90% 1% at 45% 23%,$HIGHLIGHT,transparent 85%),radial-gradient(ellipse 75% 3% at 70% 63%,$ACCENT,transparent 90%),radial-gradient(ellipse 100% 1% at 35% 82%,$SECONDARY,transparent 90%);',
 'leaks':'background-image:linear-gradient(100deg,$ACCENT,transparent 27% 42%,$SECONDARY 65%,transparent 85%),linear-gradient(10deg,transparent 10%,$HIGHLIGHT 55%,transparent 88%);',
 'halation':'background-image:radial-gradient(ellipse 28% 10% at 25% 35%,$HIGHLIGHT 10%,$ACCENT 35%,transparent 90%),radial-gradient(ellipse 23% 16% at 78% 68%,$HIGHLIGHT 10%,$SECONDARY 35%,transparent 90%);',
 'flare':'background-image:repeating-linear-gradient(125deg,transparent 0 14%,$INK 17%,transparent 20% 30%,$ACCENT 34%,transparent 39% 50%,$SECONDARY 54%,transparent 60%);',
 'noir':'background-image:repeating-linear-gradient(105deg,transparent 0 20px,$INK 20px 20.6px,transparent 21px 45px),linear-gradient(120deg,$SECONDARY,transparent 33% 60%,$HIGHLIGHT 80%,transparent);',
 'chromatic':'background-image:linear-gradient(90deg,$ACCENT 1px,transparent 1px),linear-gradient($INK 1px,transparent 1px),linear-gradient(90deg,transparent 2px,$SECONDARY 2px 3px,transparent 3px);background-size:var(--rb-scale,48px) var(--rb-scale,48px);',
 'prismtiles':'background-image:conic-gradient(from 30deg,$INK 0 60deg,$SECONDARY 60deg 180deg,$HIGHLIGHT 180deg 240deg,$ACCENT 240deg 360deg);background-size:var(--rb-scale,96px) var(--rb-scale,96px);',
 'decanter':'background-image:repeating-radial-gradient(ellipse 70% 35% at 50% 50%,transparent 0 20%,$HIGHLIGHT 21%,$SECONDARY 25%,transparent 30%),linear-gradient(110deg,$ACCENT,transparent 55%);',
}

def draw(motif,seed):
    field=connected_field(motif,seed)
    if field is not None:return field
    fragments=motifs()
    if motif in fragments:
        regular=motif in {'secession','decosteps','kitchentile','seventiesarches','seigaiha','asanoha','kumiko','meander','herringbone','cubes','scallops','zellige','mosaic','inlay','pcb','expanded','slots','croc','straw','flutes'}
        count=100 if motif=='achenes' else 36 if motif in {'arils','rice','oats'} else 16
        if motif in {'achenes','rice','oats'}:fragments[motif]='<g transform="scale(.65)">'+fragments[motif]+'</g>'
        if motif=='arils':fragments[motif]='<g transform="scale(1.25)">'+fragments[motif]+'</g>'
        return scatter(fragments[motif],seed,count,not regular,regular)
    # Global fields use periodic analytical paths; complete surface coverage.
    waves={'viscous':(18,12,1,False),'pressure':(12,18,2,True),'strata':(23,3,2,False),'crossbeds':(15,13,3,True),'rind':(14,8,3,False),'banana':(28,3,1,False),'rope':(24,9,2,False),'slub':(32,1.5,3,False),'jute':(15,2,2,True),'fishnet':(6,0,1,True),'twill':(24,0,1,True),'drifts':(13,10,1,False),'wind':(19,17,2,False),'sand':(32,4,2,False),'dunes':(12,22,1,False),'sediment':(27,8,3,True),'agate':(36,11,2,False),'xerox':(36,.6,7,False),'bookedge':(42,8,5,False),'streamline':(11,7,1,False),'opwaves':(42,17,2,False),'warpcheck':(22,22,1,True),'seventiesribbons':(8,20,2,False),'linocut':(24,9,4,False),'graphiteshade':(26,2,2,True),'charcoal':(30,2,5,True),'pointcloud':(14,13,2,False),'moire':(45,7,3,True),'grating':(45,1.5,1,False),'gyroid':(13,23,2,True),'nanowire':(23,3,2,True),'basketwave':(10,12,2,True),'fluted':(24,1,1,False),'suede':(34,1.3,3,False),'tissue':(28,7,2,False),'waveinterference':(20,13,2,True)}
    if motif in waves:
        n,a,f,cross=waves[motif];body=wave(n,a,f,0,cross)
        if motif in {'rope','twill','nanowire','graphiteshade','sediment'}:body='<g transform="rotate(90 128 128)">'+body+'</g>'
        if motif=='rope':body+=wave(8,9,2,0,False)
        if motif=='pointcloud':
            body=''
            for y in range(0,256,16):
                for x in range(0,256,16):
                    yy=y+8*math.sin(x*T/256)+5*math.sin(y*T/256);r=.5+1.3*(.5+.5*math.sin((x+y)*T/256))
                    for dx in (-256,0,256):
                        for dy in (-256,0,256):
                            if -r<x+dx<256+r and -r<yy+dy<256+r:body+=C(x+dx,yy+dy,r,.5,'black',0)
        if motif=='charcoal':body+=scatter(P('M-7 -4l12 7 M-2 -7l8 5',2,.1),seed,64)
        return body
    if motif in {'stipple','halftone'}:
        return ''.join(C(x,y,.3+(2.8 if motif=='halftone' else 1.6)*(.5+.5*math.sin(x*T/256)*math.cos(y*T/256)),.6,'black',0) for y in range(4,256,8) for x in range(4,256,8))
    raise ValueError('Missing original artwork for '+motif)

def vectors(svg):
    for r in rows():
        if r['motif'].startswith('css:'):continue
        seed=int(hashlib.sha256(r['id'].encode()).hexdigest()[:8],16)
        svg(r['id'],draw(r['motif'],seed))

def catalog(item):
    out=[]
    for r in rows():
        css=r['motif'].startswith('css:');tech='CSS' if css else 'SVG';mode=r['motif'][4:] if css else None
        repeat=not css or mode in {'crt','chromatic','prismtiles','tartan','gingham'}
        c=item(r['id'],r['name'],r['family'],tech,'repeat' if repeat else 'cover',None if css else r['id']+'.svg',r['description'],r['niches'],r['rationale'],r['avoid'],[], '#f2ece0','#75816c','#a36945',.20 if not css else .40,256 if not css else 64)
        c.update(era=r['era'],style=r['style'],coverage='field',keywords=[r['group'],r['motif'],r['style'],r['era']],ink_role='secondary' if r['group'] in {'fibers','earth','wood','illustration'} else 'primary',fidelity='Собственная кодовая стилизация; не фотография, исторический оригинал или научная симуляция.',alpha_note='Прозрачные участки декоративного рисунка; фон задаётся отдельно.',concept_group=r['id'])
        if r['group']=='retroearly':
            c['era']='1890–1910-е' if r['motif'] in {'nouveau','artcraft','secession'} else '1920–1930-е' if r['motif'] in {'decofans','decosteps','bauhaus','construct','streamline'} else 'Исторический мотив'
        if r['group']=='retromid':c['era']='1940-е' if r['motif']=='newsprint' else '1950-е' if r['motif'] in {'boomerang','atomic','kitchentile'} else '1960-е' if r['motif'] in {'opwaves','warpcheck','psychedelic'} else '1970-е'
        if r['group']=='retrolate':c['era']='1980-е' if r['motif'] in {'memphis','shards','css:synth','css:vhs'} else '1990-е' if r['motif'] in {'css:crt','pixelcheck','dither'} else '2000-е'
        c['keywords'].append(c['era'])
        if r['id'].startswith('champagne-'):c['keywords']+=['шампанское','игристое','пузырьки','champagne']
        if css:c['css_body']=CSS[mode]
        out.append(c)
    for r in photos():
        c=item(r['id'],r['name'],r['family'],'WebP','cover',r['id']+'.webp','Полноформатная сгенерированная поверхность. Рисунок распределён по всей площади; версии 1440/800 px.',r['niches'],r['rationale'],r['avoid']+' Не размножать без отдельной проверки швов. Пиксели не перекрашиваются палитрой сайта.',[], '#f2ece0','#75816c','#a36945',.75)
        c.update(era='Вне эпохи',style='Реалистичный материал',coverage='field',keywords=[r['group'],r['name']],fidelity='Сгенерированная поверхность, не фото реального товара или места.',alpha_note='Непрозрачный WebP; смешивание с фоном не создаёт вырезанный объект.',concept_group=r['id'])
        if r['id']=='champagne-photo':c['keywords']+=['шампанское','игристое','пузырьки','champagne']
        out.append(c)
    return out
