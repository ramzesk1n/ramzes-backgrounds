"""Promote local paint/organic motifs to complete periodic surface fields."""
import math
import random
import re

# Bounds describe the existing motif, never a raster crop or an invented new asset.
FIELDS={
 'foundation-swipe':(520,120,380,390),'lipstick-strokes':(580,125,330,185),
 'brush-paint':(480,120,460,360),'graffiti-drips':(530,0,410,420),
 'paint-splatter':(500,0,460,640),'spray-plume':(450,0,510,640),
 'silver-tarnish':(480,30,700,550),'steam-ribbons':(400,0,560,640),
 'botanical-shadows':(400,0,560,640),'contour-leaves':(390,0,570,640),
 'root-mycelium':(350,0,610,640),'ice-fractures':(0,0,960,640),
}

def prepare(cards,assets,svg):
    for c in cards:
        if c['id'] not in FIELDS:continue
        x,y,w,h=FIELDS[c['id']]
        source=(assets/c['asset']).read_text();body=re.search(r'<svg[^>]*>(.*)</svg>',source,re.S).group(1)
        rng=random.Random(c['id']);parts=[f'<defs><g id="source">{body}</g></defs>']
        for j in range(4):
            for k in range(4):
                cx=(k+.5)*128+rng.uniform(-14,14);cy=(j+.5)*128+rng.uniform(-14,14);angle=rng.uniform(-180,180)
                factor=190/max(w,h)
                for dx in (-512,0,512):
                    for dy in (-512,0,512):
                        if -160<cx+dx<672 and -160<cy+dy<672:
                            parts.append(f'<g transform="translate({cx+dx:.2f} {cy+dy:.2f}) rotate({angle:.2f}) scale({factor:.5f}) translate({-x-w/2:.2f} {-y-h/2:.2f})"><use href="#source"/></g>')
        path=c['id']+'-surface.svg';svg(c['id']+'-surface',''.join(parts),512,512)
        c['accent_variant']=dict(asset=c['asset'],placement=c['placement'],seamless=c['seamless'],coverage='accent',description=c['description'])
        c.update(asset=path,placement='repeat',seamless=True,coverage='field',description='Сплошное поле по всей поверхности: '+c['description']+' Мотивы перекрываются и меняют направление; исходный локальный вариант доступен отдельно.')

def classify(cards):
    for c in cards:
        c.setdefault('coverage','field' if c['seamless'] or c['tech']=='WebP' and c['placement']=='cover' or c['tech']=='CSS' and c['placement']=='cover' else 'accent')
        if c['id'] in {'plasma-orb','halo-rings','sun-pillars','accretion-disk','light-cone'}:c['coverage']='accent'
        c.setdefault('era','Современное')
        c.setdefault('style','Реалистичный материал' if c['tech']=='WebP' else 'Материальная графика')
        c.setdefault('concept_group',c['id'])
