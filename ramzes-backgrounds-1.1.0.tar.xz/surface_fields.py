"""Connected periodic fields for materials whose structure must span the surface."""
import math
import random

TAU=math.tau

def path(d,w=.7,a=.55,fill='none'):
    return f'<path d="{d}" fill="{fill}" stroke="black" stroke-width="{w}" opacity="{a}" stroke-linecap="round" stroke-linejoin="round"/>'

def circle(x,y,r,a=.6,fill='none'):
    return f'<circle cx="{x:.2f}" cy="{y:.2f}" r="{r:.2f}" stroke="black" stroke-width=".6" fill="{fill}" opacity="{a}"/>'

def polygon(pts,w=.7,a=.55,fill='none'):
    return path('M'+'L'.join(f'{x:.2f} {y:.2f}' for x,y in pts)+'Z',w,a,fill)

def tile(body,w=64,h=64):
    return f'<defs><pattern id="field" width="{w}" height="{h}" patternUnits="userSpaceOnUse">{body}</pattern></defs><path d="M0 0H256V256H0Z" fill="url(#field)"/>'

def wrapped(body):
    return '<defs><g id="field">'+body+'</g></defs>'+''.join(f'<use href="#field" transform="translate({x} {y})"/>' for x in (-256,0,256) for y in (-256,0,256))

def mesh(seed,n=6,triangles=False,filled=False,width=.7):
    rng=random.Random(seed);step=256/n
    jitter={(x,y):(rng.uniform(-.28,.28)*step,rng.uniform(-.28,.28)*step) for y in range(n) for x in range(n)}
    def pt(x,y):
        a,b=jitter[x%n,y%n];return x*step+a,y*step+b
    out=[]
    for y in range(-1,n+1):
        for x in range(-1,n+1):
            a,b,c,d=pt(x,y),pt(x+1,y),pt(x+1,y+1),pt(x,y+1)
            out.append(path(f'M{a[0]:.2f} {a[1]:.2f}L{b[0]:.2f} {b[1]:.2f} M{a[0]:.2f} {a[1]:.2f}L{d[0]:.2f} {d[1]:.2f}',width,.55))
            if triangles:
                out.append(path(f'M{a[0]:.2f} {a[1]:.2f}L{c[0]:.2f} {c[1]:.2f}',width,.45))
                if filled:out.append(polygon([a,b,c],0,.04+.12*((x*7+y*3)%5)/4,'black'))
    return ''.join(out)

def voronoi(seed,n=6,width=.8,grain=False):
    rng=random.Random(seed);step=256/n
    seeds=[((x+.5+rng.uniform(-.35,.35))*step,(y+.5+rng.uniform(-.35,.35))*step) for y in range(n) for x in range(n)]
    out=[]
    for sx,sy in seeds:
        pts=[(-step*2,-step*2),(step*2,-step*2),(step*2,step*2),(-step*2,step*2)]
        for ox,oy in seeds:
            for tx in (-256,0,256):
                for ty in (-256,0,256):
                    dx,dy=ox+tx-sx,oy+ty-sy;limit=(dx*dx+dy*dy)/2
                    if limit<.001:continue
                    clipped=[]
                    for a,b in zip(pts,pts[1:]+pts[:1]):
                        fa=a[0]*dx+a[1]*dy-limit;fb=b[0]*dx+b[1]*dy-limit
                        if fa<=0:clipped.append(a)
                        if (fa<=0)!=(fb<=0):
                            t=fa/(fa-fb);clipped.append((a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1])))
                    pts=clipped
        for tx in (-256,0,256):
            for ty in (-256,0,256):
                points=[(x+sx+tx,y+sy+ty) for x,y in pts]
                if max(x for x,y in points)<-2 or min(x for x,y in points)>258 or max(y for x,y in points)<-2 or min(y for x,y in points)>258:continue
                out.append(polygon(points,width,.5))
                if grain:
                    out.append(path(f'M{sx+tx-4:.2f} {sy+ty-3:.2f}l7 2m-4 4l2 3',.45,.3))
    return ''.join(out)

def draw(motif,seed):
    rng=random.Random(seed)
    if motif in {'clay','craquelure','corkcells','veins','silkmesh','capillarynet'}:
        return voronoi(seed,7 if motif in {'corkcells','craquelure'} else 5,1.7 if motif=='clay' else .5,motif in {'clay','corkcells'})
    if motif in {'triangles','origami','wing'}:
        return mesh(seed,8 if motif=='wing' else 6,motif!='wing',motif=='origami',.45 if motif=='wing' else .7)
    if motif=='basalt':
        out=[];r=64/3
        for y in range(-32,97,32):
            for x in range(-64,129,64):
                for cx,cy in ((x,y),(x+32,y+16)):
                    p=[(cx-r,cy),(cx-r/2,cy-16),(cx+r/2,cy-16),(cx+r,cy),(cx+r/2,cy+16),(cx-r/2,cy+16)]
                    out.append(polygon(p,.9,.6));out.append(polygon([(cx,cy),p[2],p[3],p[4]],0,.10,'black'))
        return tile(''.join(out))
    if motif in {'truchet','pinwheel','rhombi','cubes','asanoha','seigaiha','scallops'}:
        if motif=='truchet':
            out=[]
            for y in range(8):
                for x in range(8):
                    d='M0 16A16 16 0 0 1 16 0 M16 32A16 16 0 0 1 32 16'
                    out.append(f'<g transform="translate({x*32} {y*32}) rotate({rng.choice((0,90,180,270))} 16 16)">'+path(d,2,.5)+'</g>')
            return ''.join(out)
        if motif=='pinwheel':
            return tile(''.join(polygon([(16,16),a,b],0,al,'black') for a,b,al in [((0,0),(32,0),.18),((32,0),(32,32),.5),((32,32),(0,32),.28),((0,32),(0,0),.6)]),32,32)
        if motif in {'rhombi','cubes','asanoha'}:
            out=[]
            for y in (-32,0,32,64,96):
                for x in (-32,0,32,64,96):
                    cx=x+(16 if (y//32)%2 else 0);cy=y
                    a=[(cx,cy-64/3),(cx+16,cy-32/3),(cx,cy),(cx-16,cy-32/3)]
                    b=[(cx,cy),(cx+16,cy-32/3),(cx+16,cy+32/3),(cx,cy+64/3)]
                    c=[(cx,cy),(cx-16,cy-32/3),(cx-16,cy+32/3),(cx,cy+64/3)]
                    if motif=='asanoha':
                        for p in (a,b,c):
                            out.append(polygon(p,.5,.6));out.append(path(f'M{p[0][0]} {p[0][1]}L{p[2][0]} {p[2][1]} M{p[1][0]} {p[1][1]}L{p[3][0]} {p[3][1]}',.4,.45))
                    else:
                        for p,al in ((a,.08),(b,.2),(c,.35)):
                            out.append(polygon(p,.6,.5));
                            if motif=='cubes':out.append(polygon(p,0,al,'black'))
            return tile(''.join(out),64,64)
        out=[]
        for y in (-32,0,32,64,96):
            for x in (-64,0,64,128):
                cx=x+(32 if (y//32)%2 else 0)
                for r in (32,24,16,8):out.append(path(f'M{cx-r} {y}A{r} {r} 0 0 1 {cx+r} {y}',.6,.5))
                if motif=='scallops':
                    for j in range(1,6):
                        a=math.pi*j/6;out.append(path(f'M{cx} {y}l{32*math.cos(a):.2f} {-32*math.sin(a):.2f}',.4,.4))
        return tile(''.join(out))
    if motif in {'fishscales','snakescale','pineapple'}:
        out=[]
        for y in range(-32,97,16):
            for x in range(-64,129,32):
                cx=x+(16 if (y//16)%2 else 0)
                if motif=='fishscales':
                    for k in (0,4,8):out.append(path(f'M{cx-16+k} {y}Q{cx} {y+27-k} {cx+16-k} {y}',.6,.55))
                elif motif=='snakescale':
                    out.append(path(f'M{cx-16} {y}Q{cx-12} {y-14} {cx} {y-16}Q{cx+12} {y-14} {cx+16} {y}L{cx} {y+16}Z',.65,.5))
                    out.append(path(f'M{cx} {y-11}V{y+10} M{cx-4} {y}l4 6l4 -6',.45,.4))
                else:
                    out.append(polygon([(cx,y-16),(cx+16,y),(cx,y+16),(cx-16,y)],.7,.55))
                    out.append(path(f'M{cx-5} {y}L{cx} {y-6}L{cx+5} {y}L{cx} {y+6}Z',.5,.4))
        return tile(''.join(out))
    if motif in {'fishnet','macrame','knurl','expanded'}:
        step=32 if motif!='knurl' else 8;out=[]
        for k in range(-256,513,step):
            out.append(path(f'M{k} 0l256 256 M{k} 0l-256 256',1.4 if motif=='expanded' else .65,.5))
        if motif in {'fishnet','macrame'}:
            for y in range(0,257,step//2):
                for x in range(0,257,step):
                    xx=x+(step//2 if (y//(step//2))%2 else 0)
                    out.append(circle(xx,y,2 if motif=='macrame' else 1,.65,'black'))
        return ''.join(out)
    if motif=='basketwave':
        out=[]
        for y in range(-32,289,32):
            out.append(path(f'M0 {y}Q16 {y-8} 32 {y}T64 {y}T96 {y}T128 {y}T160 {y}T192 {y}T224 {y}T256 {y}',5,.4))
        for x in range(-32,289,32):
            out.append(path(f'M{x} 0Q{x+8} 16 {x} 32T{x} 64T{x} 96T{x} 128T{x} 160T{x} 192T{x} 224T{x} 256',3,.35))
        return ''.join(out)
    if motif in {'twill','jute','wovenleather'}:
        size=8 if motif=='twill' else 16 if motif=='jute' else 32;out=[]
        period=size*(4 if motif=='twill' else 2)
        for y in range(-size,period+size,size):
            for x in range(-size,period+size,size):
                over=((x//size+y//size)%4<2) if motif=='twill' else ((x//size+y//size)%2==0)
                width=2 if motif=='twill' else 3 if motif=='jute' else 12
                out.append(path(f'M{x} {y}h{size} M{x+size/2} {y-size/2}v{size}',.5,.2))
                d=f'M{x+1} {y}h{size-2}' if over else f'M{x+size/2} {y-size/2+1}v{size-2}'
                out.append(path(d,width,.4))
                if motif=='jute':out.append(path(f'M{x+2} {y-2}l-1 -3 M{x+9} {y+2}l3 3',.4,.35))
        return tile(''.join(out),period,period)
    if motif=='rope':
        out=[]
        for base in range(-32,289,32):
            for j in range(7):
                pts=[(base+8*math.sin(y*TAU/64)+(j-3)*1.7,y) for y in range(0,257,4)]
                out.append(path('M'+'L'.join(f'{x:.2f} {y}' for x,y in pts),.55,.5))
            for y in range(-32,289,16):
                out.append(path(f'M{base-11} {y-4}q10 3 22 14',1.1,.6))
        return ''.join(out)
    if motif in {'tow','slub','suede','pastry','bamboo','barrel','rain','icicles','zebra'}:
        out=[]
        if motif in {'tow','slub','suede'}:
            for j in range(54 if motif=='tow' else 35):
                x=rng.uniform(0,256);y=rng.uniform(0,256);length=rng.uniform(18,90) if motif=='suede' else 256
                d=f'M{x:.2f} {y:.2f}q{rng.uniform(-12,12):.2f} {length/2:.2f} {rng.uniform(-8,8):.2f} {length:.2f}'
                out.append(path(d,.45,.4))
                if motif=='slub':out.append(path(f'M{x:.2f} {y+20:.2f}l1 12',1.9,.3))
            return wrapped(''.join(out))
        if motif=='pastry':
            for y in range(-10,270,5):out.append(path(f'M0 {y}Q64 {y-7} 128 {y}T256 {y}',.65,.5))
            return ''.join(out)
        if motif=='barrel':
            for x in range(-32,289,32):
                out.append(path(f'M{x} 0V256',1,.55))
                for offset in (9,16,23):
                    out.append(path(f'M{x+offset} 0q-4 64 0 128t0 128',.4,.35))
            for y in (32,160):out.append(path(f'M0 {y}H256 M0 {y+5}H256',2,.5))
            return ''.join(out)
        if motif=='bamboo':
            for x in range(0,257,32):
                out.append(path(f'M{x} 0q-4 64 0 128t0 128',1,.6))
                for y in range(-64,321,64):
                    yy=y+(32 if x//32%2 else 0)
                    out.append(path(f'M{x} {yy}q16 5 32 0 M{x} {yy+4}q16 5 32 0',.75,.5))
                    out.append(path(f'M{x+11} {yy+13}v34 M{x+21} {yy+17}v27',.35,.3))
            return ''.join(out)
        if motif=='rain':
            for j in range(160):
                x,y=rng.uniform(0,256),rng.uniform(0,256);length=rng.uniform(3,19)
                out.append(path(f'M{x:.2f} {y:.2f}l{-length*.25:.2f} {length:.2f}',.5,.25+rng.random()*.35))
            return wrapped(''.join(out))
        if motif=='icicles':
            for y in range(0,256,64):
                for x in range(0,256,16):
                    h=rng.uniform(22,59);out.append(polygon([(x,y),(x+6,y+h),(x+12,y)],.6,.5))
            # A repeated seed-derived 256-square keeps boundary lengths consistent.
            return wrapped(''.join(out))
        if motif=='zebra':
            for x in range(-32,289,16):
                pts=[(x+7*math.sin(y*TAU/128+(x%256)*TAU/256*3),y) for y in range(0,257,4)]
                out.append(path('M'+'L'.join(f'{xx:.2f} {yy}' for xx,yy in pts),4,.5))
            return ''.join(out)
    if motif in {'champagne','bubbleraft'}:
        out=[]
        if motif=='champagne':
            for j in range(13):
                x=rng.uniform(0,256)
                for k in range(9):
                    y=(k*29+rng.uniform(-5,5))%256;xx=x+3*math.sin(y*TAU/256+j)
                    out.append(circle(xx,y,rng.uniform(.6,3),.25+rng.random()*.4))
        else:
            for y in range(0,256,12):
                for x in range(0,256,12):
                    out.append(circle(x+rng.uniform(-2,2),y+rng.uniform(-2,2),rng.uniform(3,6),.45))
        return wrapped(''.join(out))
    if motif=='winelacing':
        out=[]
        for j in range(4):
            y=32+j*64
            out.append(path(f'M0 {y}Q32 {y-9} 64 {y}T128 {y}T192 {y}T256 {y}',.7,.5))
            for x in range(8,256,32):
                h=20+(x*7+j*13)%35
                out.append(path(f'M{x} {y-2}q-4 {h*.6:.1f} -1 {h}',.6,.5))
        return wrapped(''.join(out))
    return None
