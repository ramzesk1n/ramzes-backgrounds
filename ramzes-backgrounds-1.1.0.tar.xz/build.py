#!/usr/bin/env python3
"""Rebuild the deterministic pilot and its portable gallery. Pillow: raster encoding only."""
from pathlib import Path
import base64, gzip, html, io, json, math, random, re
from scripts.theme import DEFAULTS as TOKEN_DEFAULTS, BINDINGS as TOKEN_BINDINGS, ROLES
import extended
import niches
import optics
import materials
import neon
import expansion
import coverage
import completion

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / 'assets'
ASSETS.mkdir(exist_ok=True)
VERSION = '1.1.0'

def svg(name, body, w=256, h=256):
    text = f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">{body}</svg>'
    (ASSETS / (name+'.svg')).write_text(text)

def speckles(seed, number, color, opacity, radius):
    rng = random.Random(seed)
    s = []
    for _ in range(number):
        x,y,r = rng.random()*256,rng.random()*256,rng.uniform(.25,radius)
        alpha=rng.uniform(opacity*.5,opacity)
        for dx in (-256,0,256):
            for dy in (-256,0,256):
                if -r <= x+dx <= 256+r and -r <= y+dy <= 256+r:
                    s.append(f'<circle cx="{x+dx:.2f}" cy="{y+dy:.2f}" r="{r:.2f}" fill="{color}" opacity="{alpha:.3f}"/>')
    return ''.join(s)

def make_vectors():
    # Periodic curves join at matching positions/slopes; edge dots are wrapped.
    paper = speckles(32,360,'#000',.15,.8)+speckles(47,160,'#fff',.3,.6)
    svg('paper',paper)
    concrete = speckles(81,200,'#000',.09,4)+speckles(82,160,'#fff',.22,2)+speckles(83,220,'#000',.12,.65)
    svg('microcement',concrete)
    linen='''<defs><pattern id="weave" width="16" height="16" patternUnits="userSpaceOnUse"><path d="M4 0V16 M12 0V16 M0 4H16 M0 12H16" stroke="black" stroke-opacity=".12"/><path d="M5 0V16 M13 0V16 M0 5H16 M0 13H16" stroke="white" stroke-opacity=".5"/><path d="M6 2v5 M14 10v5" stroke="black" stroke-opacity=".12" stroke-width="2"/></pattern></defs><path d="M0 0H256V256H0z" fill="url(#weave)"/>'''
    svg('linen',linen)
    # Crop a periodic stripe field; y repeat is explicitly 256 and j phase repeats 32.
    wood=[]
    for j in range(-2,35):
        phase=2*math.pi*(j%32)/32
        k=math.tau/256
        f=lambda x:j*8+3*math.sin(x*k+phase)+1.8*math.sin(x*k*2+phase*2)
        df=lambda x:3*k*math.cos(x*k+phase)+3.6*k*math.cos(x*k*2+phase*2)
        d=f'M0 {f(0):.2f}'
        for x in range(0,256,32):
            end=x+32
            d+=f'C{x+32/3:.2f} {f(x)+df(x)*32/3:.2f} {end-32/3:.2f} {f(end)-df(end)*32/3:.2f} {end} {f(end):.2f}'
        wood.append(f'<path d="{d}" fill="none" stroke="#000" stroke-opacity=".22" stroke-width=".7"/>')
    svg('wood-grain',''.join(wood))
    topo=[]
    for cx,cy in [(0,230),(780,570)]:
        for r in range(60,420,23):
            pts=[]
            for n in range(32):
                t=n/32*math.tau
                rr=r*(1+.12*math.sin(t*3)+.05*math.cos(t*5+r/160))
                pts.append((cx+rr*math.cos(t),cy+rr*.72*math.sin(t)))
            d=f'M{pts[0][0]:.1f} {pts[0][1]:.1f}'
            for n in range(32):
                p0,p1,p2,p3=[pts[k%32] for k in (n-1,n,n+1,n+2)]
                d+=f'C{p1[0]+(p2[0]-p0[0])/6:.1f} {p1[1]+(p2[1]-p0[1])/6:.1f} {p2[0]-(p3[0]-p1[0])/6:.1f} {p2[1]-(p3[1]-p1[1])/6:.1f} {p2[0]:.1f} {p2[1]:.1f}'
            topo.append(f'<path d="{d}Z" fill="none" stroke="black" stroke-width="1.2"/>')
    svg('topography',''.join(topo),960,640)
    blueprint='''<g stroke="black" fill="none" stroke-width="1"><path d="M60 150H550V540H60z M90 180H520V510H90z M90 380H310V510 M310 180V350H520 M90 350H270 M340 380H520 M60 120H550 M30 150V540 M580 150V540"/><path d="M55 113l10 14m480-14l10 14M23 145l14 10m-14 380l14 10 M270 350a40 40 0 0 1 40 40"/><circle cx="740" cy="220" r="115"/><circle cx="740" cy="220" r="90"/><path d="M600 220H880 M740 80V360 M650 490h200 M750 400v180 M630 450l220 100"/></g>'''
    svg('architectural',blueprint,960,640)
    leaves=['<defs><radialGradient id="leaf"><stop stop-color="black" stop-opacity=".65"/><stop offset=".6" stop-color="black" stop-opacity=".3"/><stop offset="1" stop-color="black" stop-opacity="0"/></radialGradient></defs>']
    for j in range(9):
        x=640+j*29;y=50+j*57
        leaves.append(f'<ellipse cx="{x}" cy="{y}" rx="120" ry="37" transform="rotate(-34 {x} {y})" fill="url(#leaf)"/>')
        leaves.append(f'<ellipse cx="{x-120}" cy="{y+60}" rx="105" ry="35" transform="rotate(35 {x-120} {y+60})" fill="url(#leaf)"/>')
    svg('botanical-shadow',''.join(leaves),960,640)
    rays=['<defs><linearGradient id="fade"><stop stop-color="white" stop-opacity="0"/><stop offset=".5" stop-color="white"/><stop offset="1" stop-color="white" stop-opacity="0"/></linearGradient></defs>']
    for j in range(-3,12):
        f=lambda x:j*86+46*math.sin(x/170+j*.8)+22*math.sin(x/77+j)
        df=lambda x:46/170*math.cos(x/170+j*.8)+22/77*math.cos(x/77+j)
        d=f'M0 {f(0):.1f}'
        for x in range(0,960,60):
            end=x+60
            d+=f'C{x+20} {f(x)+df(x)*20:.1f} {end-20} {f(end)-df(end)*20:.1f} {end} {f(end):.1f}'
        rays.append(f'<defs><path id="wave{j+3}" d="{d}"/></defs>')
        for width,op in [(16,.04),(7,.08),(2,.4)]:
            rays.append(f'<use href="#wave{j+3}" fill="none" stroke="url(#fade)" stroke-width="{width}" opacity="{op}"/>')
    svg('caustic-lines',''.join(rays),960,640)
    extended.vectors(svg,speckles)
    optics.vectors(svg)
    materials.vectors(svg,speckles)
    expansion.vectors(svg)
    completion.vectors(svg)

def encode_rasters():
    """Non-destructive delivery resizing/encoding; never modify uploaded originals."""
    from PIL import Image
    import shutil
    source=ROOT.parent/'upload'
    masters=ROOT/'masters'
    masters.mkdir(exist_ok=True)
    for stem,fragment in [('marble','49 PM-3'),('prism','51 PM-5')]:
        master=masters/(stem+'.png')
        if not master.exists():
            matches=list(source.glob('*'+fragment+'*.png'))
            if matches: shutil.copy2(matches[0],master)
        matches=[master] if master.exists() else []
        if not matches:
            if not (ASSETS/(stem+'.webp')).exists():
                raise FileNotFoundError('Copy supplied raster source to upload/ before rebuilding raster assets')
            continue
        for suffix,width in [('',1440),('-mobile',800)]:
            im=Image.open(matches[0]); im.thumbnail((width,width),Image.Resampling.LANCZOS)
            if stem=='marble': im=im.convert('RGB')
            target=ASSETS/(stem+suffix+'.webp');temporary=target.with_suffix('.tmp.webp')
            im.save(temporary,quality=76,method=6);temporary.replace(target)
    for stem in extended.RASTER_IDS+materials.RASTER_IDS+expansion.RASTER_IDS+completion.RASTER_IDS:
        master=masters/(stem+'.png')
        if not master.exists():raise FileNotFoundError('Missing generated master: '+str(master))
        for suffix,width in [('',1440),('-mobile',800)]:
            target=ASSETS/(stem+suffix+'.webp')
            if target.exists() and target.stat().st_size>0 and target.stat().st_mtime>=master.stat().st_mtime:continue
            im=Image.open(master).convert('RGB');im.thumbnail((width,width),Image.Resampling.LANCZOS)
            temporary=target.with_suffix('.tmp.webp')
            if stem in completion.RASTER_IDS:
                budget=225280 if not suffix else 114688
                for quality in (64,56,48,40,34):
                    encoded=io.BytesIO();im.save(encoded,format='WEBP',quality=quality,method=6)
                    if encoded.tell()<=budget:break
                temporary.write_bytes(encoded.getvalue())
            else:
                im.save(temporary,quality=materials.RASTER_QUALITY.get(stem,68 if stem in expansion.RASTER_IDS else 74),method=6)
            temporary.replace(target)

def item(id,name,family,tech,placement,asset,desc,niches,rationale,avoid,companions,bg,ink,accent,intensity,scale=256):
    return dict(id=id,name=name,family=family,tech=tech,placement=placement,asset=asset,description=desc,
        niches=niches,rationale=rationale,avoid=avoid,companions=companions,
        defaults=dict(bg=bg,ink=ink,accent=accent,intensity=intensity,scale=scale),
        colorability=('palette' if tech=='CSS' else 'tint-mask' if tech=='SVG' else 'fixed-palette'),
        seamless=placement=='repeat',version=VERSION,status='implemented',client_js_bytes=0)

def catalog():
    return [
      item('technical-grid','Техническая сетка','Геометрия','CSS','repeat',None,'Тонкая ортогональная сетка с регулируемым шагом. Структура без декоративного шума.',['IT и SaaS','Строительство и ремонт','Образование','Производство'],'Передаёт точность и порядок; подходит для схем, расчётов и технических предложений.','Не накладывать на насыщенные фотографии и мелкие таблицы.',['paper-fiber','soft-vignette'],'#ece9e1','#233b3b','#a36945',.13,40),
      item('quiet-dots','Ритм точек','Геометрия','CSS','repeat',None,'Редкая точечная разметка. Лёгкая альтернатива сетке для больших спокойных секций.',['IT и SaaS','Образование','Юристы и B2B','HR и консалтинг'],'Даёт ритм и ощущение системы, сохраняя свободную поверхность.','Слишком мелкий шаг может создавать муар; проверить на мобильном.',['light-cone'],'#f3eee5','#3d4944','#a36945',.25,24),
      item('contour-map','Контурный рельеф','Геометрия','SVG','cover','topography.svg','Изолинии по краям композиции с более свободным центром.',['Туризм и отели','Недвижимость и интерьер','Ландшафт и экология','Образование'],'Поддерживает темы места, маршрута и развития; центр оставлен под текст.','Это декоративная карта; не выдавать за географические данные.',['paper-fiber','soft-vignette'],'#e9e8df','#3e5950','#9c683e',.25),
      item('architectural-plan','Архитектурный чертёж','Геометрия','SVG','cover','architectural.svg','Абстрактный план, сечения и размерные линии. Без фиктивных технических подписей.',['Строительство и ремонт','Кухни и мебель','Производство','Недвижимость и интерьер'],'Связывает фон с проектированием и устройством продукта.','Не использовать вместо реального плана или рабочей документации.',['microcement'],'#18272c','#d0dbd4','#c88e5a',.23),
      item('quiet-aurora','Тихая аврора','Свет','CSS','cover',None,'Три мягких цветовых поля. Статичные radial-gradient без filter: blur().',['IT и SaaS','Beauty и wellness','Образование','Креативные услуги'],'Создаёт глубину через свет; палитра полностью меняется под бренд.','Не делать универсальным фоном всех IT-проектов; избегать пёстрой палитры.',['glass-surface'],'#111b29','#587f8c','#9b78a0',.8),
      item('light-cone','Свет из окна','Свет','CSS','overlay',None,'Широкий диагональный световой переход. Без отрисовки сцены или окна.',['Образование','HR и консалтинг','Недвижимость и интерьер','Beauty и wellness'],'Метафора ясности и спокойствия для нематериальных услуг.','Не ставить яркую часть прямо под светлым текстом.',['paper-fiber','linen-weave'],'#eae5da','#fffaf0','#c1a178',.65),
      item('soft-vignette','Мягкая виньетка','Свет','CSS','overlay',None,'Спокойное затемнение краёв. Помогает собрать композицию без рамки.',['Ювелирка и fashion','Недвижимость и интерьер','Авто и логистика','Юристы и B2B'],'Направляет внимание к центральной области и объединяет крупный фон.','Не считать заменой проверки контраста текста по всей его области.',['marble-noir'],'#e7e2d8','#111820','#a36945',.3),
      item('glass-surface','Молочное стекло','Поверхности','CSS','cover',None,'Адаптивная стеклянная поверхность: полупрозрачная заливка, один край и мягкая внутренняя тень. Без backdrop-filter.',['Медицина и стоматология','Beauty и wellness','IT и SaaS','Ювелирка и fashion'],'Придаёт поверхности глубину; размеры и радиус не зависят от изображения.','Это имитация стекла, не реальное преломление. Не использовать десять стеклянных слоёв.',['quiet-aurora','prismatic-light'],'#dfe9e9','#ffffff','#89b9b6',.7),
      item('paper-fiber','Волокно бумаги','Материалы','SVG','repeat','paper.svg','Процедурная микрофактура без SVG-фильтров. Плитка 256×256, мелкие элементы завёрнуты через границы.',['Юристы и B2B','Образование','HR и консалтинг','Рестораны и продукты'],'Тактильная, нейтральная основа для длинного чтения и доверительного тона.','На маленьком превью фактура может быть почти незаметной — не усиливать автоматически.',['light-cone','technical-grid'],'#f2ece0','#6b6255','#a36945',.35),
      item('microcement','Микроцемент','Материалы','SVG','repeat','microcement.svg','Сдержанные минеральные вкрапления. Стилизованная кодовая фактура, не фотография бетона.',['Строительство и ремонт','Недвижимость и интерьер','Кухни и мебель','Производство'],'Добавляет ощущение реального материала без крупных пятен и прожилок.','Для макросъёмки материала нужна отдельная растровая версия.',['architectural-plan','botanical-shadows'],'#d8d5cb','#504b43','#a36945',.7),
      item('linen-weave','Льняное плетение','Материалы','SVG','repeat','linen.svg','Ровное микроплетение с чередованием нитей. Периодическая геометрия, без размытия.',['Рестораны и продукты','Beauty и wellness','Кухни и мебель','Туризм и отели'],'Поддерживает темы натуральности, ремесла и домашнего комфорта.','Мелкое плетение проверять на муар; не делать контрастным.',['botanical-shadows','light-cone'],'#e5dbc9','#7c6b54','#9c7445',.4),
      item('wood-grain','Ритм древесных волокон','Материалы','SVG','repeat','wood-grain.svg','Условная древесная структура из периодических линий. Перекрашиваемый орнамент, не фотореалистичный шпон.',['Кухни и мебель','Рестораны и продукты','Ландшафт и экология','Туризм и отели'],'Даёт направление и материальную ассоциацию без тяжёлой фотографии.','Для демонстрации конкретной породы использовать фотографии; при большом масштабе условность заметна.',['light-cone'],'#ccad7f','#533823','#a36945',.55),
      item('marble-noir','Тёмный мрамор','Материалы','WebP','cover','marble.webp','Фотореалистичный тёмный камень с золотистыми прожилками. Варианты 1440 и 800 px.',['Ювелирка и fashion','Недвижимость и интерьер','Туризм и отели'],'Уместен, когда сам бренд связан с камнем, интерьером или выразительной предметной подачей.','Не использовать как автоматический знак премиальности. Прожилки могут мешать тексту. Не повторять плиткой.',['soft-vignette'],'#171715','#ffffff','#bf995d',.8),
      item('botanical-shadows','Ботаническая тень','Прозрачные слои','SVG','overlay','botanical-shadow.svg','Мягкие растительные силуэты из градиентных эллипсов. Свободная левая область под текст.',['Beauty и wellness','Ландшафт и экология','Туризм и отели','Недвижимость и интерьер'],'Создаёт ощущение дневного света и живой среды; цвет тени можно менять.','Не подходит как точная ботаническая иллюстрация. Не повторять по всей странице.',['microcement','linen-weave'],'#eae5d8','#25382c','#7b8652',.55),
      item('water-caustics','Световой рисунок воды','Прозрачные слои','SVG','cover','caustic-lines.svg','Стилизованные световые волны без фильтров. Это графическая интерпретация каустики.',['Медицина и стоматология','Beauty и wellness','Туризм и отели','Клининг и окна'],'Ассоциации с водой, чистотой и отражением; геометрия легче сложного живого эффекта.','Для реалистичной воды потребуется отдельный растровый актив. Не смешивать с несколькими другими бликами.',['glass-surface'],'#2e7279','#d8fbef','#86c8bf',.7),
      item('prismatic-light','Призматический блик','Прозрачные слои','WebP','overlay','prism.webp','Настоящий полупрозрачный растровый световой слой. Сохраняет цветные переливы и мягкие края.',['Ювелирка и fashion','Beauty и wellness','Креативные услуги','Образование'],'Поддерживает темы оптики, материала и творческого преобразования.','Цветная оптика не перекрашивается одним CSS-цветом. Не накладывать на мелкий текст.',['glass-surface'],'#e9e5df','#6c7781','#b68ba0',.8),
    ]

def recipe(c):
    d=c['defaults']; id=c['id']; path=c['asset']; intensity=d['intensity']
    base=f'''/* Ramzes Backgrounds {VERSION} / {id}. Decorative layer only; no client JS. */
.rb-surface {{
  position: relative; isolation: isolate; overflow: hidden;
  background-color: var(--rb-bg, var(--background, {d['bg']}));
}}
.rb-surface::before {{
  content: ""; position: absolute; inset: 0; z-index: -1; pointer-events: none;
  opacity: var(--rb-intensity, {intensity});
'''
    ink_role=c.get('token_roles',ROLES)['ink']
    ink=f"var(--rb-ink, var(--{ink_role}, {d['ink']}))"; accent=f"var(--rb-accent, var(--accent, {d['accent']}))"
    secondary=f"var(--rb-secondary, var(--secondary, {d['ink']}))"
    if c.get('css_body'):
        body=c['css_body']
        for key,value in {'$INK':ink,'$ACCENT':accent,'$SECONDARY':secondary,'$HIGHLIGHT':'var(--rb-highlight, var(--highlight, #ffffff))'}.items():body=body.replace(key,value)
    elif id=='technical-grid':
        body=f'background-image: linear-gradient({ink} 1px, transparent 1px), linear-gradient(90deg, {ink} 1px, transparent 1px); background-size: var(--rb-scale, 40px) var(--rb-scale, 40px);'
    elif id=='quiet-dots': body=f'background-image: radial-gradient(circle, {ink} 1px, transparent 1.5px); background-size: var(--rb-scale, 24px) var(--rb-scale, 24px);'
    elif id=='quiet-aurora': body=f'background-image: radial-gradient(ellipse at 5% 15%, {accent}, transparent 55%), radial-gradient(ellipse at 95% 80%, {ink}, transparent 55%), radial-gradient(ellipse at 70% 0%, {secondary}, transparent 50%);'
    elif id=='light-cone': body=f'background-image: linear-gradient(124deg, transparent 20%, {ink} 40%, transparent 65%), radial-gradient(ellipse at 80% 0%, {accent}, transparent 65%);'
    elif id=='soft-vignette': body=f'background-image: radial-gradient(ellipse at center, transparent 25%, {ink} 100%);'
    elif id=='glass-surface': body=f'background-image: linear-gradient(135deg, var(--rb-surface-color, var(--surface, {d["ink"]})), transparent 70%), linear-gradient(25deg, transparent 50%, {accent}); border: 1px solid var(--rb-border, var(--border, #c1c9b8)); border-radius: inherit; box-shadow: inset 0 1px 1px var(--rb-highlight, var(--highlight, #ffffff));'
    elif c['tech']=='SVG':
        size='var(--rb-scale, 256px) var(--rb-scale, 256px)' if c['seamless'] else 'cover'
        repeat='repeat' if c['seamless'] else 'no-repeat'
        body=f'background-color: {ink}; mask-image: url("assets/{path}"); mask-mode: alpha; mask-size: {size}; mask-position: var(--rb-position, center); mask-repeat: {repeat};'
    else:
        body=f'background-image: url("assets/{path}"); background-size: cover; background-position: var(--rb-position, center); background-repeat: no-repeat;'
    css=base+'  '+body+'\n}\n'
    if c['tech']=='WebP':
        mobile=path.replace('.webp','-mobile.webp')
        css+=f'@media (max-width: 48rem) {{ .rb-surface::before {{ background-image: url("assets/{mobile}"); }} }}\n'
    return css

def main():
    make_vectors();encode_rasters(); cards=catalog()+extended.catalog(item)+optics.catalog(item)+materials.catalog(item)+expansion.catalog(item)+completion.catalog(item)
    coverage.prepare(cards,ASSETS,svg)
    coverage.classify(cards)
    (ROOT/'recipes').mkdir(exist_ok=True)
    for c in cards:
        c['token_roles']=ROLES.copy()
        if c.get('ink_role'):c['token_roles']['ink']=c['ink_role']
        if c['id'] in ('paper-fiber','microcement','linen-weave','wood-grain','botanical-shadows','soft-vignette'):c['token_roles']['ink']='secondary'
        if c['id']=='water-caustics':c['token_roles']['ink']='highlight'
        c['css']=recipe(c)
        if c.get('accent_variant'):
            ac=c['accent_variant'];ac['css']=recipe({**c,**ac})
            ac['asset_bytes']=(ASSETS/ac['asset']).stat().st_size
            ac['css_gzip_bytes']=len(gzip.compress(ac['css'].encode(),mtime=0))
        (ROOT/'recipes'/(c['id']+'.css')).write_text(c['css'])
        c['asset_bytes']=(ASSETS/c['asset']).stat().st_size if c['asset'] else 0
        c['css_gzip_bytes']=len(gzip.compress(c['css'].encode(),mtime=0))
        c['asset_gzip_bytes']=len(gzip.compress((ASSETS/c['asset']).read_bytes(),mtime=0)) if c['asset'] and c['tech']=='SVG' else c['asset_bytes']
        c['origin']=('AI-generated for this project; built-in imagegen; delivery resize/encoding' if c['id'] in extended.RASTER_IDS+materials.RASTER_IDS+expansion.RASTER_IDS+completion.RASTER_IDS else 'user-supplied reference; delivery resize/encoding') if c['tech']=='WebP' else 'original deterministic code'
        c.setdefault('visual_kind','photorealistic' if c['tech']=='WebP' else 'code-stylization')
        c['text_role']='on-image' if c['id'] in ('marble-noir','velvet-photo','lacquer-liquid-photo','crude-oil-photo','red-wine-photo','cinema-bokeh-photo','grilled-meat-photo','marbled-beef-photo','saffiano-leather-photo','garden-soil-photo','permanganate-crystals-photo') else 'text'
        legacy_keywords= {
          'oak-veneer-photo':['дерево','древесина','шпон','wood','oak'],
          'wood-grain':['дерево','древесина','wood'],
          'travertine-surface':['камень','stone','travertine'],
          'brushed-aluminum-photo':['металл','metal','aluminum'],
          'satin-folds-photo':['ткань','шёлк','сатин','silk','satin'],
          'velvet-photo':['ткань','бархат','velvet'],
          'ceramic-glaze-photo':['керамика','глазурь','ceramic'],
          'steam-ribbons':['пар','дым','steam','smoke'],
          'holographic-foil':['голография','фольга','holographic'],
        }.get(c['id'],[])
        c['keywords']=list(dict.fromkeys(c.get('keywords',[])+legacy_keywords))
        c['mobile']='800 px WebP; position adjustable' if c['tech']=='WebP' else 'same static recipe; reduce intensity or simplify on small screens'
        c['opacity_note']='Intensity affects the decorative pseudo-element only, never content.'
        if c['tech']=='WebP':
            from PIL import Image
            with Image.open(ASSETS/c['asset']) as image:c['source_size']=image.size
        else:c['source_size']=None
        c['compositing']='alpha-mask' if c['tech']=='SVG' else 'alpha-overlay' if c['id']=='prismatic-light' else 'opaque-image' if c['tech']=='WebP' else 'css-layers'
        c['opacity_recommendation']=dict(start=c['defaults']['intensity'],scope='decorative layer only',note='Adjust for real content; no universal value')
        c['safe_text_area']='Check with real copy; avoid bright or detailed material areas'
    optics.enrich(cards)
    neon.attach(cards,ASSETS)
    guides=niches.guides()
    (ROOT/'niches.json').write_text(json.dumps(guides,ensure_ascii=False,indent=2)+'\n')
    for c in cards:
        if not c['companions']:
            linked=[id for g in guides if c['id'] in g['recommended'] for id in g['recommended'] if id!=c['id']]
            c['companions']=list(dict.fromkeys(linked or ['paper-fiber','light-cone']))[:2]
    data=dict(version=VERSION,title='Ramzes Backgrounds',niche_guides=guides,token_defaults=TOKEN_DEFAULTS,token_bindings=TOKEN_BINDINGS,license_code=(ROOT/'LICENSE').read_text(),cards=cards)
    (ROOT/'catalog.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    from collections import Counter
    counts=Counter(c['tech'] for c in cards)
    template=(ROOT/'gallery.template.html').read_text()
    for key,value in {'__TOTAL__':len(cards),'__CSS__':counts['CSS'],'__SVG__':counts['SVG'],'__WEBP__':counts['WebP'],'__VERSION__':VERSION}.items():template=template.replace(key,str(value))
    assets={p.name:'data:'+('image/svg+xml' if p.suffix=='.svg' else 'image/webp')+';base64,'+base64.b64encode(p.read_bytes()).decode() for p in ASSETS.iterdir() if p.suffix in ('.svg','.webp') and '.tmp.' not in p.name}
    content=template.replace('/*__CATALOG__*/',json.dumps(data,ensure_ascii=False).replace('</','<\\/')).replace('/*__ASSETS__*/',json.dumps(assets))
    (ROOT/'index.html').write_text(content)
    print(f'Built {len(cards)} cards; {len(assets)} assets; portable gallery {len(content.encode()):,} bytes')

if __name__=='__main__': main()
