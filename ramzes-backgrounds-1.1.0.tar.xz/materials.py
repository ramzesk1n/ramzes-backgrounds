"""Beauty, coatings, metal finishes and fluid surfaces. Static original artwork."""
import math
import random

RASTER_IDS=['lacquer-liquid-photo','makeup-skin-photo','cream-swirl-photo','berry-smoothie-photo','green-smoothie-photo','oil-water-suspension-photo','microfoam-photo','spray-paint-photo','liquid-chrome-photo','copper-patina-photo']
RASTER_QUALITY={'spray-paint-photo':64,'copper-patina-photo':56}


def vectors(svg,speckles):
    def path(d,width=1,opacity=1,fill='none'):
        return f'<path d="{d}" fill="{fill}" stroke="black" stroke-width="{width}" opacity="{opacity}" stroke-linecap="round" stroke-linejoin="round"/>'
    svg('magnesium-matte',speckles(503,190,'black',.22,1)+speckles(504,100,'black',.1,3))
    svg('iron-oxide',speckles(505,270,'black',.6,2.5)+speckles(506,95,'black',.3,6))
    rng=random.Random(5050)
    def islands(count,seed,vertices=10):
        rand=random.Random(seed);body=[]
        for _ in range(count):
            x,y=rand.uniform(0,256),rand.uniform(0,256);r=rand.uniform(8,24)
            pts=[(math.cos(t)*r*rand.uniform(.5,1),math.sin(t)*r*rand.uniform(.5,1)) for t in [math.tau*n/vertices for n in range(vertices)]]
            alpha=rand.uniform(.18,.55)
            for dx in (-256,0,256):
                for dy in (-256,0,256):
                    if -r<x+dx<256+r and -r<y+dy<256+r:
                        body.append('<polygon points="'+' '.join(f'{x+dx+a:.2f},{y+dy+b:.2f}' for a,b in pts)+f'" opacity="{alpha:.2f}"/>')
        return ''.join(body)
    svg('copper-verdigris',islands(35,5051)+speckles(5052,90,'black',.3,1))
    svg('oxidized-bronze',islands(20,5053,6)+speckles(5054,280,'black',.38,.85))
    foil='<defs><pattern id="foil" width="64" height="64" patternUnits="userSpaceOnUse">'+path('M0 0L26 12L64 0 M0 64L26 42L64 64 M26 12V42 M0 32L26 24L64 32 M26 24L44 16L64 32 M44 16L26 12',.65,.65)+path('M0 0L26 12V24L0 32Z',0,.13,'black')+path('M26 24L64 32V64L26 42Z',0,.06,'black')+'</pattern></defs><path d="M0 0H256V256H0z" fill="url(#foil)"/>'
    svg('gold-leaf',foil)
    zinc='<defs><pattern id="z" width="64" height="64" patternUnits="userSpaceOnUse">'
    for d,a in [('M32 32L0 0H64Z',.2),('M32 32L64 0V64Z',.5),('M32 32L64 64H0Z',.3),('M32 32L0 64V0Z',.1)]:zinc+=path(d,0,a,'black')
    zinc+='</pattern></defs><path d="M0 0H256V256H0z" fill="url(#z)"/>'
    svg('zinc-spangle',zinc)
    tarnish=[]
    for j in range(13):
        x=640+j*20;y=130+j*17
        tarnish.append(f'<ellipse cx="{x}" cy="{y}" rx="{75+j*7}" ry="{33+j*3}" transform="rotate(-20 {x} {y})" fill="none" stroke="black" stroke-width="{2+j%4}" opacity=".18"/>')
    svg('silver-tarnish',''.join(tarnish),960,640)
    svg('makeup-powder',speckles(5060,400,'black',.4,1.2)+speckles(5061,40,'black',.15,3))
    skin=[]
    for y in range(0,256,32):
        for x in range(0,256,32):
            skin.append(path(f'M{x+3} {y+17}Q{x+10} {y+12} {x+15} {y+18} M{x+19} {y+27}q5 -6 10 -2',.5,.22))
            skin.append(f'<ellipse cx="{x+18}" cy="{y+8}" rx=".7" ry="1.1" opacity=".4"/>')
    svg('skin-microrelief',''.join(skin))
    svg('spray-stipple',speckles(5062,520,'black',.6,1.7))
    graphite=[]
    for _ in range(100):
        x,y=rng.uniform(0,256),rng.uniform(0,256);length=rng.uniform(3,13);width=rng.uniform(.3,1)
        for dx in (-256,0,256):
            for dy in (-256,0,256):
                if -15<x+dx<271 and -4<y+dy<260:graphite.append(path(f'M{x+dx:.1f} {y+dy:.1f}l{length:.1f} -2',width,.3))
    svg('graphite-rubbing',''.join(graphite))
    foundation=[]
    for j in range(42):
        x=590+j*5
        foundation.append(path(f'M{x} 135Q{x-45} 270 {x+30} {440+(j%6)*5}',2.8,.2+.5*math.sin(j/42*math.pi)))
    svg('foundation-swipe',''.join(foundation),960,640)
    lipstick=[]
    for j in range(3):
        x=600+j*90;y=140+j*20
        lipstick.append(path(f'M{x} {y}l100 115',28,.55))
        for n in range(4):lipstick.append(path(f'M{x+n*6-8} {y+5}l100 115',.7,.25))
    svg('lipstick-strokes',''.join(lipstick),960,640)
    spray=[];rng=random.Random(5063)
    for _ in range(330):
        x,y=rng.gauss(780,105),rng.gauss(315,120)
        if 0<x<960 and 0<y<640:spray.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{rng.uniform(.5,3.5):.1f}" opacity="{rng.uniform(.1,.65):.2f}"/>')
    svg('spray-plume',''.join(spray),960,640)
    brush=[]
    for j in range(50):
        y=280+j*3
        brush.append(path(f'M490 {y}Q700 {y-140} {900+(j%4)*7} {y-25}',1.8,.3+(j%5)*.1))
    svg('brush-paint',''.join(brush),960,640)
    drips=[]
    for j in range(10):
        x=550+j*37;h=90+(j*79)%250
        drips.append(path(f'M{x} -10Q{x+8} 80 {x} {h}',7+(j%3)*2,.65))
        drips.append(f'<ellipse cx="{x}" cy="{h}" rx="{4+j%3}" ry="8" opacity=".65"/>')
    svg('graffiti-drips',''.join(drips),960,640)
    marbling=[]
    for j in range(18):
        x=600+j*13
        marbling.append(path(f'M{x} -20C{x-170} 150 {x+210} 220 {x+25} 365S{x-90} 550 {x+80} 660',1+j%3,.38))
    svg('ink-marbling',''.join(marbling),960,640)
    splat=[];rng=random.Random(5064)
    for _ in range(90):
        x,y=rng.gauss(800,85),rng.gauss(350,125);r=rng.uniform(1,8)
        splat.append(f'<ellipse cx="{x:.1f}" cy="{y:.1f}" rx="{r:.1f}" ry="{r*rng.uniform(.7,1.5):.1f}" opacity="{rng.uniform(.2,.8):.2f}"/>')
    svg('paint-splatter',''.join(splat),960,640)
    drops=[]
    for x,y,r in [(35,30,15),(100,100,23),(193,55,19),(210,190,27),(50,210,17)]:
        drops.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="black" opacity=".13"/><circle cx="{x}" cy="{y}" r="{r}" fill="none" stroke="black" stroke-width="1.1" opacity=".6"/>'+path(f'M{x-r*.5:.1f} {y-r*.45:.1f}q{r*.3:.1f} {-r*.35:.1f} {r*.65:.1f} {-r*.2:.1f}',1,.8))
    svg('oil-suspension',''.join(drops))
    # Periodic Voronoi cells, built by half-plane clipping using only the stdlib.
    # Round the corners slightly; the web page loads just the resulting SVG.
    rng=random.Random(5066);seeds=[((x+.5+rng.uniform(-.32,.32))*256/6,(y+.5+rng.uniform(-.32,.32))*256/6) for y in range(6) for x in range(6)]
    cells=[]
    for sx,sy in seeds:
        poly=[(-120,-120),(120,-120),(120,120),(-120,120)]
        for ox,oy in seeds:
            for tx in (-256,0,256):
                for ty in (-256,0,256):
                    dx,dy=ox+tx-sx,oy+ty-sy
                    if dx*dx+dy*dy<.01:continue
                    limit=(dx*dx+dy*dy)/2;clipped=[]
                    for a,b in zip(poly,poly[1:]+poly[:1]):
                        fa=a[0]*dx+a[1]*dy-limit;fb=b[0]*dx+b[1]*dy-limit
                        if fa<=0:clipped.append(a)
                        if (fa<=0)!=(fb<=0):
                            t=fa/(fa-fb);clipped.append((a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1])))
                    poly=clipped
        for tx in (-256,0,256):
            for ty in (-256,0,256):
                points=[(x+sx+tx,y+sy+ty) for x,y in poly]
                if max(x for x,y in points)<-1 or min(x for x,y in points)>257 or max(y for x,y in points)<-1 or min(y for x,y in points)>257:continue
                d=''
                for j,p in enumerate(points):
                    prev,nxt=points[j-1],points[(j+1)%len(points)]
                    a=(p[0]+(prev[0]-p[0])*.14,p[1]+(prev[1]-p[1])*.14);b=(p[0]+(nxt[0]-p[0])*.14,p[1]+(nxt[1]-p[1])*.14)
                    d+=f'{"M" if j==0 else "L"}{a[0]:.2f} {a[1]:.2f}Q{p[0]:.2f} {p[1]:.2f} {b[0]:.2f} {b[1]:.2f}'
                cells.append(path(d+'Z',.65,.55))
    svg('foam-cells',''.join(cells))
    bubbles=[]
    for x,y,r in [(730,170,70),(840,350,90),(620,440,36),(900,90,28)]:
        bubbles.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="none" stroke="black" stroke-width=".9" opacity=".35"/>'+path(f'M{x-r*.65:.1f} {y-r*.45:.1f}A{r*.8} {r*.8} 0 0 1 {x+r*.3:.1f} {y-r*.82:.1f}',2,.85))
    svg('soap-bubbles',''.join(bubbles),960,640)
    fizz=[];rng=random.Random(5065)
    for j in range(65):
        y=rng.uniform(20,650);x=770+35*math.sin(y/90)+rng.gauss(0,22);r=rng.uniform(1,5)
        fizz.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{r:.1f}" fill="none" stroke="black" opacity=".5"/>')
    svg('carbonated-stream',''.join(fizz),960,640)


def catalog(item):
    result=[]
    ns_metal=['Производство','Ювелирка и fashion','Авто и логистика']
    ns_beauty=['Beauty и wellness','Косметика и уход','Ювелирка и fashion']
    ns_paint=['Краски и покрытия','Креативные услуги','Строительство и ремонт']
    ns_liquid=['Рестораны и продукты','Косметика и уход','Клининг и окна']
    def add(id,name,family,tech,placement,description,ns,why,avoid,role='primary',intensity=.4,body=None,keywords=()):
        c=item(id,name,family,tech,placement,id+('.svg' if tech=='SVG' else '.webp') if tech!='CSS' else None,description,ns,why,avoid,[], '#f2ece0','#75816c','#a36945',intensity)
        c.update(ink_role=role,keywords=list(keywords),fidelity='Фотореалистичная сгенерированная поверхность; не образец конкретного продукта.' if tech=='WebP' else 'Художественная стилизация; не микрофотография или физическая симуляция.',alpha_note='Непрозрачный WebP; opacity смешивает фотографию с фоном, но не вырезает объект.' if tech=='WebP' else 'Рисунок имеет прозрачные промежутки; фон секции задаётся отдельно.')
        if body:c['css_body']=body
        if family=='Металлы и патина' and tech!='WebP':c['appearance_note']='При брендовой перекраске сохраняется геометрия бликов/фактуры, а не натуральный цвет металла. Не подтверждает химический состав.'
        result.append(c)
    metallic=[
      ('chrome-ribbon','Хром: зеркальные полосы','Сильный световой край, тёмное отражение и широкая серебристая плоскость.','Отражающие поверхности техники и предметов.','Не отражает окружение сайта в реальном времени.','background-image:linear-gradient(110deg,$SECONDARY 0%, $HIGHLIGHT 22%, $INK 28%, $HIGHLIGHT 31%, $SECONDARY 52%, $HIGHLIGHT 75%, $INK 87%);',['хром','Cr','chrome']),
      ('gold-brushed','Золото Au: сатинированный блик','Широкая металлическая светотень и очень тонкое направленное зерно.','Ювелирная и предметная подача через светотень.','Для точного золотого оттенка использовать подходящие существующие токены.','background-image:repeating-linear-gradient(0deg,transparent 0 3px,$HIGHLIGHT 3px 3.4px),linear-gradient(115deg,$INK,$ACCENT 28%,$HIGHLIGHT 46%,$ACCENT 62%,$INK);',['золото','Au','gold']),
      ('silver-satin','Серебро Ag: мягкий сатин','Спокойные широкие светлые полосы, менее контрастные, чем у хрома.','Фон для серебряных украшений и лаконичных изделий.','Это брендовая стилизация сатина, не идентификация сплава.','background-image:linear-gradient(105deg,$SECONDARY,$HIGHLIGHT 35%,$SECONDARY 58%,$HIGHLIGHT 75%,$INK);',['серебро','Ag','silver']),
      ('copper-brushed','Медь Cu: направленный блик','Несколько широких косых переломов с тонкой линейной структурой.','Цветной металл и ремесленные предметы.','Медный оттенок определяется палитрой сайта, а не названием рецепта.','background-image:repeating-linear-gradient(90deg,transparent 0 4px,$INK 4px 4.4px),linear-gradient(130deg,$ACCENT,$HIGHLIGHT 38%,$INK 43%,$ACCENT 65%,$SECONDARY);',['медь','Cu','copper']),
      ('titanium-anodized','Титан Ti: анодированный перелив','Разнесённые цветовые полосы с двумя узкими яркими отражениями.','Оптика тонких покрытий для предметного дизайна.','Не задаёт толщину покрытия и не вычисляет интерференционный спектр.','background-image:linear-gradient(115deg,$INK 5%,$SECONDARY 28%,$HIGHLIGHT 32%,$ACCENT 42%,$SECONDARY 58%,$HIGHLIGHT 62%,$INK 85%);',['титан','Ti','анодирование','titanium']),
    ]
    for id,name,desc,why,avoid,body,keywords in metallic:add(id,name,'Металлы и патина','CSS','cover',desc,ns_metal,why,avoid,intensity=.65,body=body,keywords=keywords)
    for id,name,placement,desc,keywords in [
      ('magnesium-matte','Магний Mg: матовая поверхность','repeat','Тонкий сухой крап без ярких зеркальных отражений.',['магний','Mg','magnesium']),
      ('iron-oxide','Железо Fe: зерно ржавчины','repeat','Мелкая неоднородная коррозионная зернистость.',['железо','Fe','оксид','ржавчина','rust']),
      ('copper-verdigris','Медь Cu: островки патины','repeat','Неровные пятна патины и мелкое минеральное зерно.',['медь','Cu','патина','окислы','verdigris']),
      ('silver-tarnish','Серебро Ag: пятна потемнения','cover','Нерегулярные вложенные границы потемнения в правой части.',['серебро','Ag','потемнение','tarnish']),
      ('gold-leaf','Золотая поталь: грани листа','repeat','Ломаные края тонкой фольги и небольшие перепады плотности.',['золото','Au','поталь','сусальное']),
      ('zinc-spangle','Цинк Zn: кристаллический узор','repeat','Условные разнонаправленные кристаллические грани оцинковки.',['цинк','Zn','оцинковка','zinc']),
      ('oxidized-bronze','Бронза: зернистая патина','repeat','Крупные островки старения с более частым мелким зерном.',['бронза','патина','окислы','bronze']),
    ]:add(id,name,'Металлы и патина','SVG',placement,desc,ns_metal,'Материальная ассоциация для оборудования, покрытий и изделий.','Стилизованная маска; не показывает реальный состав сплава или соединения. Поталь не обязательно является золотом, потемнение серебра не обозначается как оксид.',role='secondary',keywords=keywords)
    add('lacquer-pools','Лак: глянцевый изгиб','Beauty и косметика','CSS','cover','Плавная плотная заливка с двумя узкими вытянутыми бликами.',ns_beauty,'Лаковый характер без фото и тяжёлого живого эффекта.','Не моделирует вязкость; для реалистичного лака выбрать lacquer-liquid-photo.',intensity=.62,body='background-image:radial-gradient(ellipse 4% 25% at 74% 43%,$HIGHLIGHT,transparent 90%),radial-gradient(ellipse 8% 36% at 80% 50%,$ACCENT,transparent 95%),linear-gradient(130deg,$INK 35%,$SECONDARY 70%,$INK);',keywords=['лак','маникюр','nail polish'])
    for id,name,placement,desc,ns,role,keywords in [
      ('makeup-powder','Рассыпчатая пудра','repeat','Мелкий нерегулярный пигмент с редкими более крупными частицами.',ns_beauty,'accent',['пудра','макияж','powder']),
      ('foundation-swipe','Мазок тонального средства','overlay','Плотные параллельные следы нанесения с мягким изменением альфы.',ns_beauty,'accent',['тональный','мейкап','makeup','foundation']),
      ('lipstick-strokes','Мазки помады','overlay','Три коротких плотных диагональных следа с тонкой внутренней штриховкой.',ns_beauty,'accent',['помада','lipstick']),
      ('skin-microrelief','Микрорельеф кожи','repeat','Условные короткие складочки и поры; деликатная неконтрастная сетка.',ns_beauty,'secondary',['кожа','телесность','skin','поры']),
      ('spray-stipple','Спрей: мелкий пигмент','repeat','Мелкое аэрозольное зерно с равномерной плотностью.',ns_paint,'accent',['краска','пульверизатор','спрей','spray']),
      ('spray-plume','Спрей: облако распыления','overlay','Плотное облако справа плавно разрежается к краям.',ns_paint,'accent',['аэрограф','пульверизатор','спрей','spray']),
      ('brush-paint','Краска: след широкой кисти','cover','Десятки близких изогнутых линий передают направление щетины.',ns_paint,'accent',['краска','кисть','мазок','paint']),
      ('graffiti-drips','Граффити: потёки краски','overlay','Десять разных по длине вертикальных потёков справа, без надписей.',ns_paint,'accent',['граффити','потёки','graffiti']),
      ('graphite-rubbing','Графитовая растирка','repeat','Короткие наклонные штрихи с неоднородной толщиной и плотностью.',ns_paint,'secondary',['графит','карандаш','graphite']),
    ]:add(id,name,'Beauty и косметика' if ns is ns_beauty else 'Краски и нанесение','SVG',placement,desc,ns,'Поверхность и способ нанесения связаны с самим продуктом или услугой.','Условная графическая фактура; не заменяет макросъёмку средства или кожи.',role=role,intensity=.28 if id=='skin-microrelief' else .42,keywords=keywords)
    for id,name,placement,desc,keywords in [
      ('ink-marbling','Жидкая тушь: мраморирование','cover','Вложенные текучие контуры, вытянутые в правой части.',['тушь','чернила','краска','жидкость','ink']),
      ('paint-splatter','Брызги краски','overlay','Нерегулярное пятно из разных по размеру капель справа.',['краска','брызги','splatter']),
      ('oil-suspension','Взвесь: линзы масла','repeat','Разреженные округлые включения с прозрачным центром и дугой блика.',['взвесь','эмульсия','масло','жидкость','suspension']),
      ('foam-cells','Пена: ячеистая сетка','repeat','Округлые ячейки разных размеров с прозрачными внутренними областями.',['пена','пенка','foam']),
      ('soap-bubbles','Мыльные пузыри','overlay','Четыре крупные сферы справа с тонким контуром и локальным бликом.',['пузыри','мыло','bubbles']),
      ('carbonated-stream','Газированные пузырьки','overlay','Узкая вертикальная группа мелких круглых пузырьков.',['газировка','пузыри','напитки','carbonated']),
    ]:add(id,name,'Краски и нанесение' if id=='paint-splatter' else 'Жидкости и пена','SVG',placement,desc,ns_paint if id=='paint-splatter' else ns_liquid,'Лёгкая метафора состава, текучести или очищения.','Статичная стилизация; не физика течения и не изображение реальной рецептуры.',role='accent' if id in ['paint-splatter','ink-marbling','oil-suspension'] else 'highlight',intensity=.45,keywords=keywords)
    add('milk-folds','Молочная складка','Жидкости и пена','CSS','cover','Две широкие светлые складки с мягкой полутенью.',ns_liquid,'Спокойный кремовый характер для молочных продуктов и ухода.','Условный CSS-образ; для пищевого реализма выбрать cream-swirl-photo.',role='secondary',body='background-image:radial-gradient(ellipse 50% 15% at 72% 45%,$HIGHLIGHT 20%,transparent 85%),radial-gradient(ellipse 43% 13% at 75% 60%,$SECONDARY,transparent 90%),radial-gradient(ellipse 40% 13% at 68% 68%,$HIGHLIGHT,transparent 90%);',keywords=['молоко','сметана','крем','milk'])
    add('gel-ripple','Гель: прозрачная рябь','Жидкости и пена','CSS','cover','Широкие смещённые кольца с тонким светлым мениском.',ns_liquid,'Тактильный жидкий слой для гелей, ухода и воды.','Нет реального преломления, искажения текста или расчёта вязкости.',intensity=.35,body='background-image:radial-gradient(ellipse at 78% 50%,transparent 28%,$HIGHLIGHT 29%,transparent 31%,$SECONDARY 34%,transparent 40%,$HIGHLIGHT 41%,transparent 43%,$INK 48%,transparent 55%);',keywords=['гель','рябь','gel','жидкость'])
    photos=[
      ('lacquer-liquid-photo','Лак: густая глянцевая поверхность','Beauty и косметика',ns_beauty,'Плотная бордовая поверхность с широким мениском и студийным бликом.',['лак','маникюр','nail polish']),
      ('makeup-skin-photo','Кожа: сатиновый макияж','Beauty и косметика',ns_beauty,'Макрофрагмент взрослой щеки с тонким тональным средством, порами и мягким сиянием.',['кожа','телесность','мейкап','макияж','skin','makeup']),
      ('cream-swirl-photo','Сметана: густой сливочный завиток','Жидкости и пена',ns_liquid,'Фотореалистичная густая сметана с широкой мягкой складкой.',['сметана','сливки','крем','cream']),
      ('berry-smoothie-photo','Смузи: ягодная мякоть','Жидкости и пена',ns_liquid,'Плотный розовый смузи с мелкими семенами и влажной поверхностью.',['ягоды','смузи','мякоть','smoothie']),
      ('green-smoothie-photo','Смузи: зелёная взвесь','Жидкости и пена',ns_liquid,'Светло-зелёная густая взвесь с мелкими волокнами.',['зелёный','смузи','авокадо','smoothie']),
      ('oil-water-suspension-photo','Масло в воде: прозрачные линзы','Жидкости и пена',ns_liquid,'Прозрачные янтарные линзы разного размера с мягкими рефракционными границами.',['масло','вода','взвесь','эмульсия','suspension']),
      ('microfoam-photo','Пена: влажная микрофактура','Жидкости и пена',ns_liquid,'Плотная белая мелкопузырчатая пена с несколькими крупными ячейками.',['пена','пенка','пузыри','foam']),
      ('spray-paint-photo','Спрей: облако пигмента','Краски и нанесение',ns_paint,'Терракотовое аэрозольное облако с мелким сухим крапом и свободной левой областью.',['спрей','краска','пульверизатор','аэрограф','spray']),
      ('liquid-chrome-photo','Хром: зеркальная складка','Металлы и патина',ns_metal,'Зеркальный серебристый металл с широкой изогнутой складкой.',['хром','Cr','chrome','металл']),
      ('copper-patina-photo','Медь: бирюзовая патина','Металлы и патина',ns_metal,'Бирюзовые минеральные островки на красновато-медной основе.',['медь','Cu','окислы','патина','copper']),
    ]
    for id,name,family,ns,desc,keywords in photos:add(id,name,family,'WebP','cover',desc,ns,'Реалистичная материальная поверхность, когда условной графики недостаточно.','Композиция без гарантии бесшовности. Цветные пиксели не перекрашиваются токенами; меняются интенсивность и кадрирование.',intensity=.75,keywords=keywords)
    assert len(result)==40
    return result
