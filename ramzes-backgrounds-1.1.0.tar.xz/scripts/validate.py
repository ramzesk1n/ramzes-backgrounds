#!/usr/bin/env python3
"""Meaningful release checks: all exports, isolation, metadata and overwrite protection."""
import gzip, hashlib, json, re, subprocess, sys, tempfile
from collections import Counter
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]

def run():
    data=json.loads((ROOT/'catalog.json').read_text());cards=data['cards']
    assert len(cards)==500 and len({c['id'] for c in cards})==500
    assert Counter(c['tech'] for c in cards)=={'CSS':61,'SVG':381,'WebP':58}
    assert sum(c['seamless'] for c in cards)==372
    ids={c['id'] for c in cards}
    assert len(data['niche_guides'])==107
    assert Counter(c['coverage'] for c in cards)=={'field':466,'accent':34}
    assert sum(bool(c.get('accent_variant')) for c in cards)==12
    assert all(c['coverage']=='field' and c['style'] and c['era'] for c in cards[120:])
    # Exact geometry duplicates must not inflate the new collection's counter.
    new_vectors=[hashlib.sha256((ROOT/'assets'/c['asset']).read_bytes()).hexdigest() for c in cards[120:] if c['tech']=='SVG']
    assert len(set(new_vectors))==len(new_vectors)
    assert sum(bool(c.get('neon')) for c in cards)==16
    crosswalk=json.loads((ROOT/'docs/PDF_CROSSWALK.json').read_text())
    assert len(crosswalk['ideas'])==52
    assert {s['id']:s['pages'] for s in crosswalk['sources']}=={'M':13,'L':4}
    for idea in crosswalk['ideas']:
        assert set(idea['recipes'])<=ids and idea['status'] in {'new','existing','adaptation','deferred'}
    for c in cards[60:80]:
        assert c['mechanism'] and c['fidelity'] and c['pdf_refs'] and c['alpha_note']
        assert c['asset_bytes']<40000 and c['tech']!='WebP'
    for c in cards[80:]:
        assert c['fidelity'] and c['alpha_note'] and c['keywords']
    for guide in data['niche_guides']:
        assert len(set(guide['recommended']))==3 and set(guide['recommended'])<=ids
    for c in cards:
        assert c['seamless']==(c['placement']=='repeat')
        assert c['client_js_bytes']==0
        assert len(c['niches'])>=3 and c['rationale'] and c['avoid']
        assert c['css']==(ROOT/'recipes'/(c['id']+'.css')).read_text()
        assert '$' not in c['css']
        assert not any(s in c['css'] for s in ['backdrop-filter','filter:','@import','animation:','http://','https://'])
        if c['asset']:
            f=ROOT/'assets'/c['asset'];assert f.stat().st_size==c['asset_bytes']
            if c['tech']=='WebP':
                from PIL import Image
                with Image.open(f) as im:im.verify()
                with Image.open(f.with_name(f.stem+'-mobile.webp')) as im:im.verify()
            if f.suffix=='.svg':
                tree=ET.fromstring(f.read_text())
                assert tree.tag.endswith('svg')
                assert not any(x.tag.split('}')[-1] in ['script','filter','image','foreignObject'] for x in tree.iter())
        if c.get('neon'):
            n=c['neon'];assert '::after' in n['css'] and '--rb-neon-intensity' in n['css'] and '--rb-neon-color' in n['css']
            assert '$' not in n['css'] and not any(x in n['css'] for x in ['filter:','animation:','@import'])
            if n['asset']:
                tree=ET.fromstring((ROOT/'assets'/n['asset']).read_text())
                assert not any(x.tag.split('}')[-1] in ['script','filter','image','foreignObject'] for x in tree.iter())
    with tempfile.TemporaryDirectory(prefix='rb-validate-') as temp:
        base=Path(temp)
        for c in cards:
            out=base/c['id']
            cmd=[sys.executable,str(ROOT/'scripts/backgrounds.py'),'export',c['id'],'--out',str(out)]
            subprocess.run(cmd,check=True,capture_output=True,text=True)
            css=(out/'background.css').read_text()
            assert (out/'LICENSE').is_file()
            references=set(re.findall(r'url\("assets/([^"\)]+)"\)',css))
            actual={f.name for f in (out/'assets').iterdir()} if (out/'assets').exists() else set()
            assert actual==references
            assert not list(out.rglob('*.js')) and '<script' not in (out/'example.html').read_text()
            lock=json.loads((out/'background.lock.json').read_text())
            assert lock['id']==c['id'] and lock['version']==data['version']
            assert lock['composition']=='surface' and lock['coverage']==c['coverage']
            for name,sha in lock['files'].items():assert hashlib.sha256((out/name).read_bytes()).hexdigest()==sha
            before={p.name:p.read_bytes() for p in out.iterdir() if p.is_file()}
            denied=subprocess.run(cmd,capture_output=True)
            assert denied.returncode!=0
            assert before=={p.name:p.read_bytes() for p in out.iterdir() if p.is_file()}
        for c in cards:
            if not c.get('accent_variant'):continue
            out=base/('accent-'+c['id'])
            subprocess.run([sys.executable,str(ROOT/'scripts/backgrounds.py'),'export',c['id'],'--out',str(out),'--composition','accent'],check=True,capture_output=True)
            variant=c['accent_variant'];css=(out/'background.css').read_text()
            assert variant['asset'] in css and c['asset'] not in css
            lock=json.loads((out/'background.lock.json').read_text())
            assert lock['composition']=='accent' and lock['coverage']=='accent' and lock['placement']==variant['placement']
            for name,sha in lock['files'].items():assert hashlib.sha256((out/name).read_bytes()).hexdigest()==sha
        denied_out=base/'unsupported-composition'
        denied=subprocess.run([sys.executable,str(ROOT/'scripts/backgrounds.py'),'export','technical-grid','--out',str(denied_out),'--composition','accent'],capture_output=True)
        assert denied.returncode!=0 and not denied_out.exists()
        for options,expected in [(['--coverage','field'],466),(['--coverage','accent'],34),(['--era','1950'],3),(['--style','Комиксы'],12)]:
            answer=subprocess.run([sys.executable,str(ROOT/'scripts/backgrounds.py'),'list',*options],check=True,capture_output=True,text=True)
            assert len(answer.stdout.strip().splitlines())==expected,(options,answer.stdout)
        custom=base/'custom'
        cmd=[sys.executable,str(ROOT/'scripts/backgrounds.py'),'export','technical-grid','--out',str(custom),'--bg','#123456','--ink','#abcdef','--intensity','0.2','--scale','64']
        subprocess.run(cmd,check=True,capture_output=True)
        css=(custom/'background.css').read_text();assert '--rb-bg:#123456;' in css and '--rb-scale:64.0px;' in css
        invalid=subprocess.run(cmd[:-2]+['--scale','0'],capture_output=True);assert invalid.returncode!=0
        # Every supported neon mode exports exactly its own optional dependency.
        for c in cards:
            if not c.get('neon'):continue
            out=base/('neon-'+c['id'])
            subprocess.run([sys.executable,str(ROOT/'scripts/backgrounds.py'),'export',c['id'],'--out',str(out),'--neon','--neon-intensity','0.7'],check=True,capture_output=True)
            css=(out/'background.css').read_text();assert '::after' in css and '--rb-neon-intensity:0.7;' in css
            assert '--rb-accent:var(--accent,' in css and '--rb-neon-color:#' not in css
            files=set(re.findall(r'url\("assets/([^"\)]+)"\)',css))
            actual={p.name for p in (out/'assets').iterdir()} if (out/'assets').exists() else set()
            assert files==actual
            if c['neon']['asset']:assert c['neon']['asset'] in actual
            plain=base/c['id'];assert '::after' not in (plain/'background.css').read_text()
            if (plain/'assets').exists():assert not any('neon' in p.name for p in (plain/'assets').iterdir())
            lock=json.loads((out/'background.lock.json').read_text());assert lock['neon']=={'enabled':True,'settings':{'intensity':.7}}
            for name,sha in lock['files'].items():assert hashlib.sha256((out/name).read_bytes()).hexdigest()==sha
        unsupported=base/'unsupported-neon'
        result=subprocess.run([sys.executable,str(ROOT/'scripts/backgrounds.py'),'export','paper-fiber','--out',str(unsupported),'--neon'],capture_output=True)
        assert result.returncode!=0 and not unsupported.exists()
        if (ROOT/'integration/ramzes-backgrounds/SKILL.md').exists():
            project=base/'project'
            subprocess.run([sys.executable,str(ROOT/'scripts/install_skill.py'),'--target','codex','--project',str(project)],check=True,capture_output=True)
            installed=project/'.agents/skills/ramzes-backgrounds'
            answer=subprocess.run([sys.executable,str(installed/'scripts/backgrounds.py'),'list','--seamless'],check=True,capture_output=True,text=True)
            assert len(answer.stdout.strip().splitlines())==372
        legal=subprocess.run([sys.executable,str(ROOT/'scripts/backgrounds.py'),'list','--niche','юридическая фирма'],check=True,capture_output=True,text=True)
        assert 'paper-fiber' in legal.stdout
        theme=base/'theme.json'
        theme.write_text(json.dumps({'tokens':{'primary':'#113355','secondary':'oklch(60% 0.1 160)','background':'#faf8f1'},'bindings':{'primary':'--brand-main','background':'--page-bg'}}))
        themed=base/'themed'
        subprocess.run([sys.executable,str(ROOT/'scripts/backgrounds.py'),'export','quiet-aurora','--out',str(themed),'--tokens',str(theme)],check=True,capture_output=True)
        css=(themed/'background.css').read_text()
        assert '--rb-ink:var(--brand-main, #113355);' in css
        assert '--rb-bg:var(--page-bg, #faf8f1);' in css
        assert '--rb-ink:#113355;' not in css
        assert ':root' not in css
        assert 'oklch(60% 0.1 160)' in (themed/'theme-example.css').read_text()
        lock=json.loads((themed/'background.lock.json').read_text())
        assert lock['bindings']['primary']=='--brand-main' and not lock['overrides']
        neon_out=base/'bound-neon'
        subprocess.run([sys.executable,str(ROOT/'scripts/backgrounds.py'),'export','branch-lightning','--out',str(neon_out),'--neon','--neon-color','#55ccff','--neon-core','#eeeeff','--tokens',str(theme)],check=True,capture_output=True)
        neon_css=(neon_out/'background.css').read_text()
        assert '--rb-neon-color:#55ccff;' in neon_css and '--rb-neon-core:#eeeeff;' in neon_css
        assert '--rb-bg:var(--page-bg, #faf8f1);' in neon_css
        role_out=base/'role-neon'
        subprocess.run([sys.executable,str(ROOT/'scripts/backgrounds.py'),'export','branch-lightning','--out',str(role_out),'--neon','--neon-color-role','primary','--tokens',str(theme)],check=True,capture_output=True)
        assert '--rb-neon-color:var(--brand-main, #113355);' in (role_out/'background.css').read_text()
        # Different semantic slots must survive export on both a mono mask and a multicolor field.
        for id,slots in [('branch-lightning',{'ink':'accent'}),('frost-dendrites',{'ink':'highlight'}),('quantum-dot-emission',{'ink':'primary','accent':'accent','secondary':'secondary'})]:
            out=base/('tokens-'+id)
            subprocess.run([sys.executable,str(ROOT/'scripts/backgrounds.py'),'export',id,'--out',str(out),'--tokens',str(theme)],check=True,capture_output=True)
            css=(out/'background.css').read_text()
            for slot,role in slots.items():
                binding='--brand-main' if role=='primary' else '--'+role
                assert '--rb-'+slot+':var('+binding+',' in css
        for card in cards:
            assert set(card['token_roles'].values())<=set(data['token_defaults'])
            assert '--background' in card['css']
        bad=base/'bad-theme.json';bad.write_text(json.dumps({'bindings':{'primary':'--brand;display:none'}}))
        rejected=subprocess.run([sys.executable,str(ROOT/'scripts/backgrounds.py'),'export','quiet-aurora','--out',str(base/'bad'),'--tokens',str(bad)],capture_output=True)
        assert rejected.returncode!=0 and not (base/'bad').exists()
    text=(ROOT/'index.html').read_text()
    assert '/*__CATALOG__*/' not in text and '/*__ASSETS__*/' not in text
    js=re.search(r'<script>\n(.*?)</script>',text,re.S).group(1)
    assert 'data-palette=' not in text and 'data-token=' in text and 'applyTokenJSON' in js
    with tempfile.NamedTemporaryFile(suffix='.js',mode='w') as f:
        f.write(js);f.flush();subprocess.run(['node','--check',f.name],check=True,capture_output=True)
    # Exercise the pure preview/export binding functions without pretending to be a browser.
    prefix=js.split('function render(){')[0]
    assertions="""
const card=cards.find(c=>c.id==='quiet-aurora');
state.tokens.primary='#102030';state.bindings.primary='--brand-main';
if(!vars(card,true).includes('--rb-ink:var(--brand-main, #102030)'))throw Error('Live binding lost');
state.tokens.primary='#fedcba';
if(effective(card).ink!=='#fedcba'||!vars(card).includes('#fedcba'))throw Error('Preview token change failed');
if(!vars(card,true).includes('var(--brand-main,'))throw Error('Binding frozen');
if(selectCards({repeat:true}).some(c=>!c.seamless))throw Error('Non-repeat card in tile mode');
if(selectCards({tech:'WebP'}).length!==58)throw Error('Raster filter failed');
if(selectCards({newOnly:true}).length!==100)throw Error('New collection filter failed');
if(selectCards({newOnly:true,search:'паутинка'}).length!==2)throw Error('New spider web fields missing');
if(selectCards({coverage:'field'}).length!==466)throw Error('Full surface filter failed');
if(selectCards({style:'Комиксы'}).length!==12)throw Error('Style filter failed');
if(selectCards({era:'1950-е'}).length!==3)throw Error('Era filter failed');
const paint=cards.find(c=>c.id==='brush-paint');
if(paint.coverage!=='field'||!paint.seamless)throw Error('Paint is not a full field');
if(cardView(paint,'accent').coverage!=='accent'||cardView(paint,'accent').asset===paint.asset)throw Error('Accent view lost');
if(!selectCards({composition:'accent',coverage:'accent'}).some(c=>c.id==='brush-paint'))throw Error('Accent filter failed');
if(!selectCards({search:'шампан'}).some(c=>c.id==='champagne-photo'))throw Error('Champagne missing');
if(selectCards({search:'шампан'}).length!==3)throw Error('Champagne code variants missing');
if(!selectCards({search:'вино'}).some(c=>c.id==='red-wine-photo'))throw Error('Wine missing');
if(!selectCards({search:'ДЕРЕВО'}).some(c=>c.id==='oak-veneer-photo'))throw Error('Search keywords failed');
if(selectCards({niche:'@windows'}).length!==3)throw Error('Niche guide failed');
if(selectCards({family:'Наноматериалы'}).length!==8)throw Error('Material family missing');
if(selectCards({family:'Энергия и оптика'}).length!==12)throw Error('Light family missing');
if(!selectCards({search:'флуоресценция'}).some(c=>c.id==='quantum-dot-emission'))throw Error('Mechanism search failed');
if(selectCards({neonOnly:true}).length!==16)throw Error('Neon filter failed');
const bolt=cards.find(c=>c.id==='branch-lightning');
if(activeCSS(bolt).includes('::after'))throw Error('Neon enabled by default');
state.neon.enabled=true;state.tokens.accent='#552244';state.bindings.accent='--studio-neon';
if(!activeCSS(bolt).includes('::after')||!vars(bolt,true).includes('--rb-neon-color:var(--studio-neon, #552244)'))throw Error('Live neon binding missing');
state.tokens.accent='#aabbcc';if(!neonVars(bolt).includes('#aabbcc'))throw Error('Neon palette frozen');
state.neon.colorRole='custom';state.neon.color='#1122ff';if(!neonVars(bolt,true).includes('--rb-neon-color:#1122ff;'))throw Error('Custom neon failed');
if(activeCSS(cards.find(c=>c.id==='paper-fiber')).includes('::after'))throw Error('Unsupported neon leaked');
if(!selectCards({search:'магний'}).some(c=>c.id==='magnesium-matte'))throw Error('Metal keyword missing');
if(!selectCards({search:'смузи'}).some(c=>c.id==='berry-smoothie-photo'))throw Error('Fluid keyword missing');
"""
    with tempfile.NamedTemporaryFile(suffix='.js',mode='w') as f:
        f.write(prefix+assertions);f.flush();subprocess.run(['node',f.name],check=True,capture_output=True)
    summary=dict(cards=len(cards),exports=len(cards),accent_exports=sum(bool(c.get('accent_variant')) for c in cards),neon_exports=sum(bool(c.get('neon')) for c in cards),niche_guides=len(data['niche_guides']),seamless=sum(c['seamless'] for c in cards),coverage=dict(Counter(c['coverage'] for c in cards)),css_gzip_bytes=sum(c['css_gzip_bytes'] for c in cards),
                 asset_bytes=sum(c['asset_bytes'] for c in cards),browser_qa='not covered by automated checks; see docs/QA.md',
                 js_syntax='passed',export_isolation='passed',overwrite_protection='passed',semantic_tokens='passed',live_css_bindings='passed')
    (ROOT/'docs').mkdir(exist_ok=True)
    (ROOT/'docs/validation.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=='__main__':run()
