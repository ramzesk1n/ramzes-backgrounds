#!/usr/bin/env python3
"""Build the offline catalog from existing assets using only Python's standard library."""
import base64
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    data = json.loads((ROOT / 'catalog.json').read_text(encoding='utf-8'))
    counts = Counter(card['tech'] for card in data['cards'])
    template = (ROOT / 'gallery.template.html').read_text(encoding='utf-8')
    values = {
        '__TOTAL__': len(data['cards']),
        '__CSS__': counts['CSS'],
        '__SVG__': counts['SVG'],
        '__WEBP__': counts['WebP'],
        '__VERSION__': data['version'],
    }
    for key, value in values.items():
        template = template.replace(key, str(value))
    assets = {}
    for path in sorted((ROOT / 'assets').iterdir()):
        if path.suffix not in ('.svg', '.webp') or '.tmp.' in path.name:
            continue
        mime = 'image/svg+xml' if path.suffix == '.svg' else 'image/webp'
        assets[path.name] = 'data:' + mime + ';base64,' + base64.b64encode(path.read_bytes()).decode('ascii')
    catalog_json = json.dumps(data, ensure_ascii=False).replace('</', '<\\/')
    html = template.replace('/*__CATALOG__*/', catalog_json).replace('/*__ASSETS__*/', json.dumps(assets))
    (ROOT / 'index.html').write_text(html, encoding='utf-8')
    print(f"Built {len(data['cards'])} cards, {len(assets)} assets; offline catalog: {ROOT / 'index.html'}")


if __name__ == '__main__':
    main()
