#!/usr/bin/env python3
"""Install the bundled skill for Codex or Claude Code without overwriting existing files."""
import argparse, shutil
from pathlib import Path

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--target',choices=['codex','claude'],required=True)
    g=p.add_mutually_exclusive_group(required=True);g.add_argument('--project',type=Path);g.add_argument('--user',action='store_true')
    a=p.parse_args();root=Path(__file__).resolve().parents[1]
    base=Path.home() if a.user else a.project.expanduser().resolve()
    destination=base/('.agents' if a.target=='codex' else '.claude')/'skills'/'ramzes-backgrounds'
    if destination.exists():p.error('Skill already exists; choose another project or review the existing installation')
    source=root/'integration'/'ramzes-backgrounds'
    if not (source/'SKILL.md').is_file():p.error('Bundled skill missing; use the complete release')
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copytree(source,destination)
    print(f'Installed {a.target} skill: {destination}')

if __name__=='__main__':main()
