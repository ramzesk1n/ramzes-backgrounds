"""Opt-in neon: broadened vector strokes or static gradients, never blur/filter/JS."""
from copy import deepcopy
from pathlib import Path
import gzip
from xml.etree import ElementTree as ET

SVG_IDS={'branch-lightning','corona-streamers','ion-tracks','magma-channels','meteor-streaks','bioluminescent-wake','spark-scatter','water-caustics','orbital-paths','soap-bubbles','carbonated-stream'}
CSS_IDS={'plasma-orb','halo-rings','sun-pillars','accretion-disk','quantum-dot-emission'}
ET.register_namespace('','http://www.w3.org/2000/svg')


def glow_svg(source,target):
    tree=ET.fromstring(source.read_text());out=ET.Element(tree.tag,dict(tree.attrib))
    for child in tree:
        if child.tag.rsplit('}',1)[-1]=='defs':out.append(deepcopy(child))
    def walk(node,opacity=1,transforms=''):
        tag=node.tag.rsplit('}',1)[-1]
        if tag=='defs':return
        alpha=opacity*float(node.get('opacity','1'))
        transforms=(transforms+' '+node.get('transform','')).strip()
        if tag in {'path','use','circle','ellipse','polyline','polygon','line'}:
            # The source may already contain halo strokes; use its brighter core only.
            if alpha<.08:return
            for extra,weight in [(18,.025),(10,.06),(4,.16)]:
                el=deepcopy(node);el.set('opacity',f'{min(alpha,1)*weight:.4f}')
                if transforms:el.set('transform',transforms)
                outlined=node.get('fill')=='none'
                if tag=='circle' and not outlined:el.set('r',str(float(node.get('r','1'))+extra/2))
                elif tag=='ellipse' and not outlined:
                    for key in ('rx','ry'):el.set(key,str(float(node.get(key,'1'))+extra/2))
                else:
                    el.set('stroke',node.get('stroke','black'));el.set('stroke-width',str(min(float(node.get('stroke-width','1')),4)+extra));el.set('stroke-linecap','round');el.set('stroke-linejoin','round')
                out.append(el)
            return
        for child in node:walk(child,alpha,transforms)
    for child in tree:walk(child)
    target.write_text(ET.tostring(out,encoding='unicode'))


def attach(cards,assets):
    for c in cards:
        if c['id'] not in SVG_IDS|CSS_IDS:continue
        head='''/* Optional neon layer. Requires an unused ::after; static, no filter. */
.rb-surface::after { content:""; position:absolute; inset:0; z-index:-2; pointer-events:none;
  opacity:var(--rb-neon-intensity,0.55);
'''
        color='var(--rb-neon-color,var(--rb-accent,var(--accent,#a36945)))'
        core='var(--rb-neon-core,var(--rb-highlight,var(--highlight,#ffffff)))'
        if c['tech']=='SVG':
            asset=c['id']+'-neon.svg';glow_svg(assets/c['asset'],assets/asset)
            body=f'background-color:{color};mask-image:url("assets/{asset}");mask-mode:alpha;mask-size:cover;mask-position:var(--rb-position,center);mask-repeat:no-repeat;'
            css=head+body+'\n}\n'+f'.rb-surface::before {{ background-color:{core}; }}\n'
        else:
            asset=None;body=c['css_body']
            for key in ['$HIGHLIGHT','$SECONDARY','$ACCENT','$INK']:body=body.replace(key,color)
            css=head+body+'\n}\n'
        c['neon']=dict(css=css,asset=asset,color_role='accent',core_role='highlight',default_intensity=.55,asset_bytes=(assets/asset).stat().st_size if asset else 0,css_gzip_bytes=len(gzip.compress(css.encode(),mtime=0)),note='Включается отдельно; цвет ореола → accent, ядра SVG → highlight. Без анимации и фильтров. Использует ::after.')
